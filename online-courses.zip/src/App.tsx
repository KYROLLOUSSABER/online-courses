import React, { useState, useEffect } from 'react';
import { AcademicYearId, CategoryId, ContentItem, UserAccount, MaintenanceConfig, NotificationItem } from './types';
import { StorageService } from './services/storage';
import { ThemeService, ThemeMode } from './services/theme';
import { OfflineStorageService } from './services/offlineStorage';
import { Navbar } from './components/Navbar';
import { HomeView } from './components/HomeView';
import { YearView } from './components/YearView';
import { ContentViewModal } from './components/ContentViewModal';
import { AdminLoginModal } from './components/AdminLoginModal';
import { AdminDashboard } from './components/AdminDashboard';
import { EditContentModal } from './components/EditContentModal';
import { MaintenanceScreen } from './components/MaintenanceScreen';
import { NotificationCenter } from './components/NotificationCenter';
import { ShieldCheck, LogIn, WifiOff, Wrench } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(null);
  const [contentList, setContentList] = useState<ContentItem[]>([]);
  const [currentView, setCurrentView] = useState<'home' | AcademicYearId | 'admin'>('home');
  const [selectedContentItem, setSelectedContentItem] = useState<ContentItem | null>(null);
  const [editingContentItem, setEditingContentItem] = useState<ContentItem | null>(null);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [currentTheme, setCurrentTheme] = useState<ThemeMode>('light');
  const [offlineCount, setOfflineCount] = useState(0);
  const [isOnline, setIsOnline] = useState(true);

  // Maintenance & Notifications state
  const [maintenanceConfig, setMaintenanceConfig] = useState<MaintenanceConfig>(() => StorageService.getMaintenanceMode());
  const [notifications, setNotifications] = useState<NotificationItem[]>(() => StorageService.getNotifications());
  
  // Quick pre-selection when clicking "إضافة محتوى" from YearView
  const [preselectedYear, setPreselectedYear] = useState<AcademicYearId | undefined>(undefined);
  const [preselectedCategory, setPreselectedCategory] = useState<CategoryId | undefined>(undefined);

  // Initialize Storage, Theme & Connectivity
  useEffect(() => {
    StorageService.initStorage();
    const loadedTheme = ThemeService.initTheme();
    setCurrentTheme(loadedTheme);

    const loadedUser = StorageService.getCurrentUser();
    setCurrentUser(loadedUser);
    setContentList(StorageService.getContent());
    setOfflineCount(OfflineStorageService.getCount());
    setMaintenanceConfig(StorageService.getMaintenanceMode());
    setNotifications(StorageService.getNotifications());

    // Online / Offline listeners
    setIsOnline(navigator.onLine);
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Path parsing (/admin or /year-1 etc)
    const handleUrlRouting = () => {
      const path = window.location.pathname.toLowerCase();
      const hash = window.location.hash.toLowerCase();

      if (path.includes('/admin') || hash === '#admin') {
        setCurrentView('admin');
        const user = StorageService.getCurrentUser();
        if (!user) {
          setIsLoginModalOpen(true);
        }
      } else if (path.includes('/year-1') || hash === '#year-1') {
        setCurrentView('year-1');
      } else if (path.includes('/year-2') || hash === '#year-2') {
        setCurrentView('year-2');
      } else if (path.includes('/year-3') || hash === '#year-3') {
        setCurrentView('year-3');
      } else if (path.includes('/year-4') || hash === '#year-4') {
        setCurrentView('year-4');
      } else {
        setCurrentView('home');
      }
    };

    const handleDataChange = () => {
      setContentList(StorageService.getContent());
      setCurrentUser(StorageService.getCurrentUser());
      setOfflineCount(OfflineStorageService.getCount());
      setMaintenanceConfig(StorageService.getMaintenanceMode());
      setNotifications(StorageService.getNotifications());
    };
    window.addEventListener('online_courses_data_changed', handleDataChange);

    handleUrlRouting();
    window.addEventListener('popstate', handleUrlRouting);
    return () => {
      window.removeEventListener('popstate', handleUrlRouting);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('online_courses_data_changed', handleDataChange);
    };
  }, []);

  const refreshData = () => {
    setContentList(StorageService.getContent());
    setCurrentUser(StorageService.getCurrentUser());
    setOfflineCount(OfflineStorageService.getCount());
    setMaintenanceConfig(StorageService.getMaintenanceMode());
    setNotifications(StorageService.getNotifications());
  };

  const handleToggleTheme = () => {
    const nextTheme = ThemeService.toggleTheme();
    setCurrentTheme(nextTheme);
  };

  // Navigation handlers with URL history sync
  const navigateToHome = () => {
    setCurrentView('home');
    window.history.pushState(null, '', '/');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navigateToYear = (yearId: AcademicYearId) => {
    setCurrentView(yearId);
    window.history.pushState(null, '', `/#${yearId}`);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navigateToAdmin = () => {
    setCurrentView('admin');
    window.history.pushState(null, '', '/admin');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (!currentUser) {
      setIsLoginModalOpen(true);
    }
  };

  const handleLogout = () => {
    StorageService.logout();
    setCurrentUser(null);
    if (currentView === 'admin') {
      navigateToHome();
    }
  };

  const handleOpenContent = (item: ContentItem) => {
    StorageService.incrementView(item.id);
    setSelectedContentItem(item);
  };

  const handleDownload = (item: ContentItem) => {
    StorageService.incrementDownload(item.id);
    refreshData();
  };

  const handleAddNewContent = (yearId: AcademicYearId, categoryId: CategoryId) => {
    setPreselectedYear(yearId);
    setPreselectedCategory(categoryId);
    navigateToAdmin();
  };

  // IF MAINTENANCE MODE IS ACTIVE AND USER IS NOT ADMIN -> SHOW MAINTENANCE SCREEN!
  if (maintenanceConfig.isEnabled && currentUser?.role !== 'admin') {
    return (
      <>
        <MaintenanceScreen
          config={maintenanceConfig}
          onOpenLogin={() => setIsLoginModalOpen(true)}
          onRefresh={refreshData}
        />
        <AdminLoginModal
          isOpen={isLoginModalOpen}
          onClose={() => setIsLoginModalOpen(false)}
          onLoginSuccess={(user) => {
            setCurrentUser(user);
            refreshData();
          }}
        />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors duration-200" dir="rtl">
      
      {/* Maintenance Mode Emergency Alert for Admin */}
      {maintenanceConfig.isEnabled && currentUser?.role === 'admin' && (
        <div className="bg-amber-500 text-slate-950 font-black text-xs py-2.5 px-4 flex items-center justify-between shadow-md z-50">
          <div className="flex items-center gap-2">
            <Wrench className="w-4 h-4 animate-spin-slow" />
            <span>⚠️ تنبيه: وضع الصيانة مفعل حالياً (الموقع محجوب عن الطلاب). أنت تتصفح بصفتك المدير العام.</span>
          </div>
          <button
            onClick={() => {
              StorageService.setMaintenanceMode({ isEnabled: false });
              refreshData();
            }}
            className="px-3 py-1 bg-white text-slate-950 rounded-lg text-xs font-black hover:bg-slate-100 cursor-pointer shadow-xs"
          >
            تعطيل وضع الصيانة الآن ✅
          </button>
        </div>
      )}

      {/* Top Student Notification Banner (نظام الإشعارات أعلى الشاشة) */}
      <NotificationCenter
        notifications={notifications}
        activeYear={typeof currentView === 'string' && currentView.startsWith('year-') ? currentView as AcademicYearId : undefined}
        onOpenContent={(contentId) => {
          const target = contentList.find(c => c.id === contentId);
          if (target) handleOpenContent(target);
        }}
        onMarkAsRead={(id) => {
          StorageService.markNotificationRead(id);
          refreshData();
        }}
        onClearAll={() => {
          StorageService.clearNotifications();
          refreshData();
        }}
      />

      {/* Offline Mode Banner when disconnected */}
      {!isOnline && (
        <div className="bg-amber-600 text-white text-xs font-bold py-2 px-4 text-center flex items-center justify-center gap-2 shadow-md z-50">
          <WifiOff className="w-4 h-4 animate-pulse" />
          <span>أنت الآن في وضع عدم الاتصال (Offline) - يمكنك تشغيل وتصفح المواد المحفوظة بدون إنترنت بكل سلاسة!</span>
        </div>
      )}

      {/* Navigation Top Bar */}
      <Navbar
        currentView={currentView}
        currentUser={currentUser}
        currentTheme={currentTheme}
        offlineCount={offlineCount}
        onToggleTheme={handleToggleTheme}
        onNavigateHome={navigateToHome}
        onNavigateYear={navigateToYear}
        onNavigateAdmin={navigateToAdmin}
        onOpenLoginModal={() => setIsLoginModalOpen(true)}
        onLogout={handleLogout}
      />

      {/* Main View Router */}
      <main className="flex-1">
        
        {/* VIEW 1: HOME */}
        {currentView === 'home' && (
          <HomeView
            contentList={contentList}
            onSelectYear={navigateToYear}
            onOpenContent={handleOpenContent}
            onNavigateAdmin={navigateToAdmin}
          />
        )}

        {/* VIEW 2: SPECIFIC ACADEMIC YEAR (1, 2, 3, 4) */}
        {(currentView === 'year-1' || currentView === 'year-2' || currentView === 'year-3' || currentView === 'year-4') && (
          <YearView
            yearId={currentView}
            contentList={contentList}
            currentUser={currentUser}
            onBackToHome={navigateToHome}
            onSwitchYear={navigateToYear}
            onOpenContent={handleOpenContent}
            onAddNewContent={handleAddNewContent}
            onEditContent={(item) => setEditingContentItem(item)}
            onDeleteContent={(_id, _title) => {
              refreshData();
            }}
          />
        )}

        {/* VIEW 3: ADMIN DASHBOARD (/admin) */}
        {currentView === 'admin' && (
          <>
            {currentUser ? (
              <AdminDashboard
                currentUser={currentUser}
                contentList={contentList}
                onRefreshData={refreshData}
                onBackToSite={navigateToHome}
                onOpenContent={handleOpenContent}
                preselectedYear={preselectedYear}
                preselectedCategory={preselectedCategory}
              />
            ) : (
              <div className="min-h-[80vh] flex items-center justify-center p-4">
                <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl max-w-md w-full text-center">
                  <div className="w-16 h-16 rounded-2xl bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-400 flex items-center justify-center mx-auto mb-4">
                    <ShieldCheck className="w-8 h-8" />
                  </div>
                  <h2 className="text-xl font-black text-slate-900 dark:text-white mb-2">
                    تسجيل الدخول إلى لوحة الإدارة
                  </h2>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mb-6 leading-relaxed">
                    هذه الصفحة مخصصة لمدير المنصة والمشرفين المعتمدين لرفع المحتوى وإدارة الملفات.
                  </p>
                  <button
                    onClick={() => setIsLoginModalOpen(true)}
                    className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    <LogIn className="w-4 h-4" />
                    <span>تسجيل الدخول الآن</span>
                  </button>
                  <button
                    onClick={navigateToHome}
                    className="mt-3 text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
                  >
                    العودة للصفحة الرئيسية
                  </button>
                </div>
              </div>
            )}
          </>
        )}

      </main>

      {/* Universal Footer with Storage & Platform Info */}
      <footer className="mt-auto border-t border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 py-6 text-center text-xs text-slate-500 dark:text-slate-400">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-700 dark:text-slate-300">منصة Online Courses الجامعية</span>
            <span>•</span>
            <span>بإشراف كيرلس صابر (المدير العام)</span>
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <span>النظام متصل ونشط</span>
            </span>
            <span>•</span>
            <span>سعة التخزين: متاح رفع غير محدود عبر الروابط ويوتيوب</span>
          </div>
        </div>
      </footer>

      {/* Content Viewer Modal (Video / PDF / Link) */}
      <ContentViewModal
        item={selectedContentItem}
        currentUser={currentUser}
        onClose={() => {
          setSelectedContentItem(null);
          refreshData();
        }}
        onDownload={handleDownload}
        onDelete={(_id, _title) => {
          setSelectedContentItem(null);
          refreshData();
        }}
      />

      {/* Admin / Supervisor Login Modal */}
      <AdminLoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        onLoginSuccess={(user) => {
          setCurrentUser(user);
          refreshData();
        }}
      />

      {/* Edit Content Modal */}
      <EditContentModal
        item={editingContentItem}
        isOpen={!!editingContentItem}
        onClose={() => setEditingContentItem(null)}
        onSaveSuccess={refreshData}
      />

    </div>
  );
}
