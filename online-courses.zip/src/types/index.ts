export type AcademicYearId = 'year-1' | 'year-2' | 'year-3' | 'year-4';

export type DepartmentId = 'cs' | 'ai' | 'cyber' | 'all';
export type SemesterId = 'sem-1' | 'sem-2' | 'all';

export interface DepartmentInfo {
  id: DepartmentId;
  name: string;
  shortName: string;
  description: string;
  iconName: string;
  badgeColor: string;
  gradient: string;
}

export interface SemesterInfo {
  id: SemesterId;
  name: string;
  shortName: string;
  description: string;
}

export interface MaintenanceConfig {
  isEnabled: boolean;
  message?: string;
  reason?: string;
  estimatedEndTime?: string;
  activatedAt?: string;
}

export interface NotificationItem {
  id: string;
  type: 'new_content' | 'deadline_updated' | 'announcement';
  yearId: AcademicYearId;
  departmentId?: DepartmentId;
  title: string;
  message: string;
  contentId?: string;
  subject?: string;
  dueDate?: string;
  createdAt: string;
  isRead?: boolean;
}

export type CategoryId = string;

export type ContentType = 'file' | 'youtube' | 'link';

export type UserRole = 'admin' | 'supervisor';

export interface CategoryDefinition {
  id: string;
  title: string;       // e.g. "المحاضرات", "التكليفات", "شيتات وتمارين"
  singular: string;    // e.g. "محاضرة", "تكليف", "شيت"
  description: string;
  iconName: string;
  badgeColor?: string;
}

export interface SubjectItem {
  id: string;
  name: string;
  yearId: AcademicYearId;
  departmentId?: DepartmentId;
  semesterId?: SemesterId;
  description?: string;
}

export interface SupervisorPermissions {
  canUpload: boolean;
  canEdit: boolean;
  canDelete: boolean;
  canManageSubjects: boolean;
}

export interface AcademicYearInfo {
  id: AcademicYearId;
  title: string;
  shortTitle: string;
  orderNumber: number;
  description: string;
  iconName: string;
  badgeColor: string;
  accentBg: string;
  defaultSubjects?: string[];
}

export interface ContentItem {
  id: string;
  yearId: AcademicYearId;
  departmentId?: DepartmentId;
  semesterId?: SemesterId;
  categoryId: CategoryId;
  subject: string;
  title: string;
  description: string;
  contentType: ContentType;
  
  // YouTube details
  youtubeUrl?: string;
  youtubeVideoId?: string;

  // File upload details (PDF, docs, presentations)
  fileName?: string;
  fileSize?: string;
  fileType?: string;
  fileData?: string; // base64 or object URL or simulated sample PDF
  
  // External link
  externalUrl?: string;
  externalUrlTitle?: string;

  // Assignments extra fields & Deadlines
  dueDate?: string;
  deadlineNote?: string;
  isCompleted?: boolean;

  // Metadata
  uploaderName: string;
  uploaderEmail: string;
  uploaderRole: UserRole;
  createdAt: string;
  views: number;
  downloads: number;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
}

export interface AIQuizResult {
  title: string;
  questions: QuizQuestion[];
}

export interface AIPromptTemplate {
  id: string;
  title: string;
  description: string;
  prompt: string;
}

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  password: string;
  role: UserRole;
  isActive: boolean;
  assignedYears: AcademicYearId[]; // which years they are allowed to upload to
  permissions: SupervisorPermissions; // detailed permissions (upload, edit, delete, subjects)
  createdAt: string;
  lastLogin?: string;
  phone?: string;
}

export interface SiteStats {
  totalContent: number;
  totalLectures: number;
  totalSections: number;
  totalAssignments: number;
  totalSummaries: number;
  totalSupervisors: number;
}

export type ActivityActionType = 
  | 'upload_content'
  | 'edit_content'
  | 'delete_content'
  | 'add_subject'
  | 'edit_subject'
  | 'delete_subject'
  | 'add_category'
  | 'delete_category'
  | 'add_supervisor'
  | 'delete_supervisor'
  | 'maintenance_mode'
  | 'clean_slate_reset'
  | 'backup_export'
  | 'backup_restore';

export interface ActivityLogItem {
  id: string;
  action: ActivityActionType;
  userName: string;
  userEmail: string;
  userRole: UserRole;
  targetTitle: string;
  targetType?: string; // 'محتوى' | 'مادة' | 'قسم' | 'مشرف' | 'نسخة احتياطية'
  details?: string;
  yearId?: AcademicYearId;
  departmentId?: DepartmentId;
  semesterId?: SemesterId;
  timestamp: string; // ISO string
}

export interface PlatformBackupData {
  version: string;
  exportedAt: string;
  exportedBy: {
    name: string;
    email: string;
    role: UserRole;
  };
  content: ContentItem[];
  subjects: SubjectItem[];
  categories: CategoryDefinition[];
  notifications: NotificationItem[];
  maintenance: MaintenanceConfig;
  activityLogs: ActivityLogItem[];
  stats: {
    totalContent: number;
    totalSubjects: number;
    totalCategories: number;
  };
}
