import React, { useState, useEffect } from 'react';
import { ContentItem, QuizQuestion } from '../types';
import { AIService, AISummaryResult, AIAskResponse } from '../services/aiService';
import { ACADEMIC_YEARS } from '../data/mockData';
import { 
  Sparkles, 
  X, 
  FileText, 
  HelpCircle, 
  MessageSquare, 
  ExternalLink, 
  Copy, 
  Check, 
  Send, 
  RotateCcw, 
  Award, 
  Lightbulb, 
  BookOpen, 
  CheckCircle2, 
  AlertCircle,
  BrainCircuit,
  Bot
} from 'lucide-react';

interface AIStudyAssistantModalProps {
  item: ContentItem | null;
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'summary' | 'quiz' | 'ask' | 'external';
}

export const AIStudyAssistantModal: React.FC<AIStudyAssistantModalProps> = ({
  item,
  isOpen,
  onClose,
  initialTab = 'summary'
}) => {
  if (!isOpen || !item) return null;

  const yearTitle = ACADEMIC_YEARS.find(y => y.id === item.yearId)?.title || item.yearId;

  // Active Tab
  const [activeTab, setActiveTab] = useState<'summary' | 'quiz' | 'ask' | 'external'>(initialTab);

  // 1. Summary State
  const [summaryStyle, setSummaryStyle] = useState<'detailed' | 'brief' | 'keypoints'>('detailed');
  const [summaryResult, setSummaryResult] = useState<AISummaryResult | null>(null);
  const [isSummarizing, setIsSummarizing] = useState(false);

  // 2. Quiz State
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>([]);
  const [userAnswers, setUserAnswers] = useState<{ [qId: string]: number }>({});
  const [isGeneratingQuiz, setIsGeneratingQuiz] = useState(false);
  const [quizSubmitted, setQuizSubmitted] = useState(false);

  // 3. Ask State
  const [userQuestion, setUserQuestion] = useState('');
  const [chatHistory, setChatHistory] = useState<Array<{ q: string; a: string }>>([]);
  const [isAsking, setIsAsking] = useState(false);

  // 4. External AI Prompt State
  const [promptGoal, setPromptGoal] = useState<'summary' | 'exam' | 'explain' | 'assignment'>('summary');
  const [copiedPrompt, setCopiedPrompt] = useState(false);

  // Auto trigger summary on initial load
  useEffect(() => {
    if (isOpen && item && !summaryResult && activeTab === 'summary') {
      handleGenerateSummary(summaryStyle);
    }
  }, [isOpen, item]);

  // Handle Summary Generation
  const handleGenerateSummary = async (style: 'detailed' | 'brief' | 'keypoints') => {
    setIsSummarizing(true);
    try {
      const res = await AIService.summarizeLecture(item, style);
      setSummaryResult(res);
    } finally {
      setIsSummarizing(false);
    }
  };

  // Handle Quiz Generation
  const handleGenerateQuiz = async () => {
    setIsGeneratingQuiz(true);
    setUserAnswers({});
    setQuizSubmitted(false);
    try {
      const res = await AIService.generateQuiz(item, 5);
      setQuizQuestions(res.questions);
    } finally {
      setIsGeneratingQuiz(false);
    }
  };

  // Handle Ask Question
  const handleSendQuestion = async (customQ?: string) => {
    const qToSend = (customQ || userQuestion).trim();
    if (!qToSend) return;

    setIsAsking(true);
    try {
      const res = await AIService.askQuestion(item, qToSend);
      setChatHistory(prev => [...prev, { q: qToSend, a: res.answer }]);
      setUserQuestion('');
    } finally {
      setIsAsking(false);
    }
  };

  // Answer Quiz Option
  const handleSelectAnswer = (qId: string, optionIndex: number) => {
    if (quizSubmitted) return;
    setUserAnswers(prev => ({ ...prev, [qId]: optionIndex }));
  };

  // Calculate Quiz Score
  const calculateScore = () => {
    let correct = 0;
    quizQuestions.forEach(q => {
      if (userAnswers[q.id] === q.correctAnswerIndex) {
        correct++;
      }
    });
    return {
      correct,
      total: quizQuestions.length,
      percentage: Math.round((correct / quizQuestions.length) * 100)
    };
  };

  // External prompt details
  const externalData = AIService.buildExternalPrompt(item, promptGoal);

  const handleCopyPrompt = () => {
    navigator.clipboard.writeText(externalData.prompt);
    setCopiedPrompt(true);
    setTimeout(() => setCopiedPrompt(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 text-right">
      <div 
        className="relative bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-4xl overflow-hidden my-6 flex flex-col max-h-[92vh] animate-in zoom-in-95"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-blue-700 via-indigo-700 to-slate-900 text-white flex items-center justify-between border-b border-white/10 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center shadow-inner">
              <Sparkles className="w-5 h-5 text-amber-300 animate-pulse" />
            </div>
            <div>
              <h3 className="text-base font-black flex items-center gap-2 text-white">
                <span>المساعد الذكي للمحاضرة</span>
                <span className="px-2 py-0.5 text-[10px] bg-blue-500/30 border border-blue-400/30 rounded-md font-bold text-blue-200">
                  Gemini AI
                </span>
              </h3>
              <p className="text-xs text-blue-100 truncate max-w-sm sm:max-w-md">
                {item.title} ({item.subject})
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-white/80 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="px-6 bg-slate-100 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 flex items-center gap-2 sm:gap-4 overflow-x-auto py-2 shrink-0">
          <button
            onClick={() => {
              setActiveTab('summary');
              if (!summaryResult) handleGenerateSummary(summaryStyle);
            }}
            className={`flex items-center gap-2 px-3.5 py-2 text-xs font-bold rounded-xl transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'summary'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700/50'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>تلخيص المحاضرة</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('quiz');
              if (quizQuestions.length === 0) handleGenerateQuiz();
            }}
            className={`flex items-center gap-2 px-3.5 py-2 text-xs font-bold rounded-xl transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'quiz'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700/50'
            }`}
          >
            <HelpCircle className="w-4 h-4" />
            <span>امتحان تفاعلي (Quiz)</span>
          </button>

          <button
            onClick={() => setActiveTab('ask')}
            className={`flex items-center gap-2 px-3.5 py-2 text-xs font-bold rounded-xl transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'ask'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700/50'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>اسأل في المحاضرة</span>
          </button>

          <button
            onClick={() => setActiveTab('external')}
            className={`flex items-center gap-2 px-3.5 py-2 text-xs font-bold rounded-xl transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'external'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'text-purple-600 dark:text-purple-400 hover:bg-purple-50 dark:hover:bg-purple-950/30'
            }`}
          >
            <Bot className="w-4 h-4" />
            <span>فتح في ChatGPT أو Gemini 🚀</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-6 overflow-y-auto flex-1">
          
          {/* =========================================================================
              TAB 1: LECTURE SUMMARY
             ========================================================================= */}
          {activeTab === 'summary' && (
            <div>
              <div className="flex flex-wrap items-center justify-between gap-3 mb-6 pb-4 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-500 dark:text-slate-400">نوع التلخيص:</span>
                  <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
                    <button
                      onClick={() => {
                        setSummaryStyle('detailed');
                        handleGenerateSummary('detailed');
                      }}
                      className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                        summaryStyle === 'detailed'
                          ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-300 shadow-xs'
                          : 'text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      أكاديمي مفصل
                    </button>
                    <button
                      onClick={() => {
                        setSummaryStyle('brief');
                        handleGenerateSummary('brief');
                      }}
                      className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                        summaryStyle === 'brief'
                          ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-300 shadow-xs'
                          : 'text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      موجز وسريع
                    </button>
                    <button
                      onClick={() => {
                        setSummaryStyle('keypoints');
                        handleGenerateSummary('keypoints');
                      }}
                      className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                        summaryStyle === 'keypoints'
                          ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-300 shadow-xs'
                          : 'text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      أهم النقاط والقوانين
                    </button>
                  </div>
                </div>

                <button
                  onClick={() => handleGenerateSummary(summaryStyle)}
                  disabled={isSummarizing}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold rounded-xl transition-colors cursor-pointer"
                >
                  <RotateCcw className={`w-3.5 h-3.5 ${isSummarizing ? 'animate-spin' : ''}`} />
                  <span>إعادة التوليد</span>
                </button>
              </div>

              {isSummarizing ? (
                <div className="py-16 text-center">
                  <div className="w-12 h-12 rounded-2xl bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto mb-3 animate-spin">
                    <BrainCircuit className="w-6 h-6" />
                  </div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">جاري تحليل المحتوى وتوليد التلخيص الذكي...</h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">يتم استخراج أهم النقاط والقوانين والتعريفات الأكاديمية</p>
                </div>
              ) : summaryResult ? (
                <div className="space-y-6">
                  {/* Summary Text Box */}
                  <div className="p-5 rounded-2xl bg-blue-50/60 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900/40">
                    <h4 className="text-xs font-black text-blue-700 dark:text-blue-300 uppercase mb-2 flex items-center gap-1.5">
                      <BookOpen className="w-4 h-4" />
                      <span>النظرة الشاملة للمحاضرة</span>
                    </h4>
                    <p className="text-xs sm:text-sm text-slate-800 dark:text-slate-200 leading-relaxed">
                      {summaryResult.summaryText}
                    </p>
                  </div>

                  {/* Key Points */}
                  <div>
                    <h4 className="text-xs font-black text-slate-900 dark:text-white uppercase mb-3 flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>النقاط الرئيسية المستفادة:</span>
                    </h4>
                    <div className="grid gap-2 sm:grid-cols-2">
                      {summaryResult.keyPoints.map((pt, idx) => (
                        <div 
                          key={idx} 
                          className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 text-xs text-slate-700 dark:text-slate-200 flex items-start gap-2.5"
                        >
                          <span className="w-5 h-5 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300 font-bold flex items-center justify-center shrink-0 text-[10px]">
                            {idx + 1}
                          </span>
                          <span className="leading-relaxed">{pt}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Formulas / Definitions */}
                  {summaryResult.importantFormulasOrDefinitions?.length > 0 && (
                    <div className="p-4 rounded-2xl bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40">
                      <h4 className="text-xs font-black text-amber-800 dark:text-amber-300 uppercase mb-2 flex items-center gap-1.5">
                        <Lightbulb className="w-4 h-4 text-amber-600" />
                        <span>أهم القوانين والتعريفات:</span>
                      </h4>
                      <ul className="space-y-1.5 text-xs text-slate-800 dark:text-slate-200 list-disc list-inside">
                        {summaryResult.importantFormulasOrDefinitions.map((itemStr, idx) => (
                          <li key={idx} className="leading-relaxed">{itemStr}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Exam Advice */}
                  {summaryResult.examAdvice && (
                    <div className="p-4 rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/40 flex items-start gap-3">
                      <Award className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
                      <div>
                        <h5 className="text-xs font-bold text-emerald-800 dark:text-emerald-300 mb-0.5">
                          نصيحة الامتحان:
                        </h5>
                        <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                          {summaryResult.examAdvice}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              ) : null}
            </div>
          )}

          {/* =========================================================================
              TAB 2: INTERACTIVE QUIZ
             ========================================================================= */}
          {activeTab === 'quiz' && (
            <div>
              <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <h4 className="text-sm font-black text-slate-900 dark:text-white">
                    امتحان تدريبي تفاعلي على المحاضرة
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    اختبر استيعابك للمفاهيم الأساسية مع تصحيح فوري وشرح للإجابة النموذجية
                  </p>
                </div>

                <button
                  onClick={handleGenerateQuiz}
                  disabled={isGeneratingQuiz}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-all cursor-pointer shadow-xs"
                >
                  <RotateCcw className={`w-3.5 h-3.5 ${isGeneratingQuiz ? 'animate-spin' : ''}`} />
                  <span>توليد أسئلة جديدة</span>
                </button>
              </div>

              {isGeneratingQuiz ? (
                <div className="py-16 text-center">
                  <div className="w-12 h-12 rounded-2xl bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto mb-3 animate-spin">
                    <BrainCircuit className="w-6 h-6" />
                  </div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">جاري إعداد بنك الأسئلة والخيارات التفاعلية...</h4>
                </div>
              ) : quizQuestions.length > 0 ? (
                <div className="space-y-6">
                  {/* Result Header if submitted */}
                  {quizSubmitted && (
                    <div className="p-5 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-700 text-white flex items-center justify-between shadow-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center font-black text-xl">
                          {calculateScore().percentage}%
                        </div>
                        <div>
                          <h4 className="text-sm font-bold">
                            {calculateScore().percentage >= 70 ? 'أحسنت! نتيجة ممتازة 🎓' : 'جيد، راجع النقاط الخاطئة أدناه'}
                          </h4>
                          <p className="text-xs text-blue-100 mt-0.5">
                            أجبت على {calculateScore().correct} من أصل {calculateScore().total} أسئلة بشكل صحيح.
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={handleGenerateQuiz}
                        className="px-4 py-2 bg-white text-blue-700 text-xs font-bold rounded-xl hover:bg-blue-50 transition cursor-pointer"
                      >
                        إعادة الامتحان
                      </button>
                    </div>
                  )}

                  {/* Question Cards */}
                  <div className="space-y-4">
                    {quizQuestions.map((q, qIndex) => {
                      const selectedOpt = userAnswers[q.id];
                      const isAnswered = selectedOpt !== undefined;

                      return (
                        <div
                          key={q.id}
                          className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60 text-right"
                        >
                          <div className="flex items-start justify-between gap-3 mb-4">
                            <span className="text-xs font-black text-blue-600 dark:text-blue-400 bg-blue-100 dark:bg-blue-950/60 px-2.5 py-1 rounded-lg">
                              السؤال {qIndex + 1}
                            </span>
                            {quizSubmitted && (
                              <span className={`text-xs font-bold px-2 py-0.5 rounded-md ${
                                selectedOpt === q.correctAnswerIndex
                                  ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
                                  : 'bg-red-100 dark:bg-red-950/60 text-red-700 dark:text-red-300'
                              }`}>
                                {selectedOpt === q.correctAnswerIndex ? 'إجابة صحيحة ✓' : 'إجابة خاطئة ✗'}
                              </span>
                            )}
                          </div>

                          <h5 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white mb-4 leading-snug">
                            {q.question}
                          </h5>

                          {/* Options */}
                          <div className="grid gap-2">
                            {q.options.map((opt, optIdx) => {
                              const isSelected = selectedOpt === optIdx;
                              const isCorrect = optIdx === q.correctAnswerIndex;

                              let optClass = 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-blue-300';
                              if (quizSubmitted) {
                                if (isCorrect) {
                                  optClass = 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-900 dark:text-emerald-200 font-bold';
                                } else if (isSelected && !isCorrect) {
                                  optClass = 'bg-red-50 dark:bg-red-950/40 border-red-500 text-red-900 dark:text-red-200';
                                }
                              } else if (isSelected) {
                                optClass = 'bg-blue-50 dark:bg-blue-950/40 border-blue-600 text-blue-900 dark:text-blue-200 font-bold';
                              }

                              return (
                                <button
                                  key={optIdx}
                                  onClick={() => handleSelectAnswer(q.id, optIdx)}
                                  className={`p-3 rounded-xl border text-xs text-right transition-all flex items-center justify-between gap-3 cursor-pointer ${optClass}`}
                                >
                                  <span>{opt}</span>
                                  <span className="w-5 h-5 rounded-full border border-slate-300 dark:border-slate-600 flex items-center justify-center shrink-0 text-[10px]">
                                    {isSelected ? '●' : String.fromCharCode(65 + optIdx)}
                                  </span>
                                </button>
                              );
                            })}
                          </div>

                          {/* Explanation if submitted */}
                          {quizSubmitted && q.explanation && (
                            <div className="mt-3 p-3 rounded-xl bg-slate-100 dark:bg-slate-700/40 border border-slate-200 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-300">
                              <strong className="text-slate-900 dark:text-white">التفسير: </strong>
                              {q.explanation}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {!quizSubmitted && (
                    <button
                      onClick={() => setQuizSubmitted(true)}
                      disabled={Object.keys(userAnswers).length === 0}
                      className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer disabled:opacity-50"
                    >
                      تسليم الإجابات وعرض النتيجة
                    </button>
                  )}
                </div>
              ) : null}
            </div>
          )}

          {/* =========================================================================
              TAB 3: ASK IN LECTURE (Q&A TUTOR)
             ========================================================================= */}
          {activeTab === 'ask' && (
            <div className="flex flex-col h-full">
              <div className="mb-4">
                <h4 className="text-sm font-black text-slate-900 dark:text-white">
                  المعلم الذكي: اسأل أي سؤال في محتوى المحاضرة
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  احصل على إجابات فورية ومبسطة لأي جزئية لم تفهمها في الشرح أو التمارين
                </p>
              </div>

              {/* Quick Prompt Ideas */}
              <div className="flex flex-wrap gap-1.5 mb-4">
                <button
                  onClick={() => handleSendQuestion('ما هي أهم النقاط التي ستركز عليها أسئلة الامتحان الفصلي والنهائي؟')}
                  className="px-3 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-blue-50 dark:hover:bg-blue-950/40 text-[11px] font-semibold text-slate-700 dark:text-slate-300 rounded-lg transition border border-slate-200 dark:border-slate-700 cursor-pointer"
                >
                  🎯 أهم أسئلة الامتحان؟
                </button>
                <button
                  onClick={() => handleSendQuestion('اشرح لي الفكرة الرئيسية للمحاضرة بمثال عملي بسيط من الواقع')}
                  className="px-3 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-blue-50 dark:hover:bg-blue-950/40 text-[11px] font-semibold text-slate-700 dark:text-slate-300 rounded-lg transition border border-slate-200 dark:border-slate-700 cursor-pointer"
                >
                  💡 شرح بمثال واقعي بسيط
                </button>
                <button
                  onClick={() => handleSendQuestion('كيف أحل المسائل والتكليفات المرتبطة بهذا الدرس خطوة بخطوة؟')}
                  className="px-3 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-blue-50 dark:hover:bg-blue-950/40 text-[11px] font-semibold text-slate-700 dark:text-slate-300 rounded-lg transition border border-slate-200 dark:border-slate-700 cursor-pointer"
                >
                  🛠️ خطوات حل التكليفات والمسائل
                </button>
              </div>

              {/* Chat Thread */}
              <div className="space-y-4 mb-4 flex-1">
                {chatHistory.length === 0 ? (
                  <div className="p-8 text-center border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl text-slate-400 dark:text-slate-500">
                    <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-60" />
                    <p className="text-xs">اكتب سؤالك في الحقل أدناه أو اختر أحد الأسئلة المقترحة في الأعلى للبدء فوراً.</p>
                  </div>
                ) : (
                  chatHistory.map((item, idx) => (
                    <div key={idx} className="space-y-2">
                      {/* User Question */}
                      <div className="p-3 bg-blue-600 text-white rounded-2xl rounded-tr-xs text-xs font-semibold max-w-[85%] mr-auto">
                        {item.q}
                      </div>
                      {/* AI Answer */}
                      <div className="p-4 bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-2xl rounded-tl-xs text-xs leading-relaxed max-w-[95%] border border-slate-200 dark:border-slate-700">
                        {item.a}
                      </div>
                    </div>
                  ))
                )}

                {isAsking && (
                  <div className="p-4 bg-slate-100 dark:bg-slate-800 rounded-2xl text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2">
                    <BrainCircuit className="w-4 h-4 animate-spin text-blue-600" />
                    <span>المساعد الذكي يفكر ويصيغ الإجابة النموذجية...</span>
                  </div>
                )}
              </div>

              {/* Input Box */}
              <form 
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSendQuestion();
                }}
                className="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800"
              >
                <input
                  type="text"
                  value={userQuestion}
                  onChange={(e) => setUserQuestion(e.target.value)}
                  placeholder="اكتب سؤالك هنا بخصوص المحاضرة..."
                  className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button
                  type="submit"
                  disabled={!userQuestion.trim() || isAsking}
                  className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-all disabled:opacity-50 cursor-pointer flex items-center gap-1.5 shrink-0"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>إرسال</span>
                </button>
              </form>
            </div>
          )}

          {/* =========================================================================
              TAB 4: EXTERNAL AI PROMPTS (ChatGPT / Gemini / Claude)
             ========================================================================= */}
          {activeTab === 'external' && (
            <div className="space-y-6">
              <div>
                <h4 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <Bot className="w-4 h-4 text-purple-600" />
                  <span>فتح في أي منصة ذكاء اصطناعي (ChatGPT أو Gemini أو Claude)</span>
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                  قامت المنصة بصياغة برومبت ذكي مخصص يحتوي على كافة بيانات المحاضرة والمقرر، يمكنك نسخه بضغطة زر أو فتح المنصة المفضلة لديك مباشرة لمتابعة المذاكرة.
                </p>
              </div>

              {/* Goal Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                  اختر الغرض الذي تريد من الذكاء الاصطناعي تنفيذه:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    onClick={() => setPromptGoal('summary')}
                    className={`p-3 rounded-xl border text-xs font-bold text-center transition cursor-pointer ${
                      promptGoal === 'summary'
                        ? 'bg-purple-50 dark:bg-purple-950/40 border-purple-600 text-purple-700 dark:text-purple-300'
                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    📝 تلخيص أكاديمي
                  </button>
                  <button
                    onClick={() => setPromptGoal('exam')}
                    className={`p-3 rounded-xl border text-xs font-bold text-center transition cursor-pointer ${
                      promptGoal === 'exam'
                        ? 'bg-purple-50 dark:bg-purple-950/40 border-purple-600 text-purple-700 dark:text-purple-300'
                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    🎓 امتحان وبنك أسئلة
                  </button>
                  <button
                    onClick={() => setPromptGoal('explain')}
                    className={`p-3 rounded-xl border text-xs font-bold text-center transition cursor-pointer ${
                      promptGoal === 'explain'
                        ? 'bg-purple-50 dark:bg-purple-950/40 border-purple-600 text-purple-700 dark:text-purple-300'
                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    💡 شرح وتوضيح بأمثلة
                  </button>
                  <button
                    onClick={() => setPromptGoal('assignment')}
                    className={`p-3 rounded-xl border text-xs font-bold text-center transition cursor-pointer ${
                      promptGoal === 'assignment'
                        ? 'bg-purple-50 dark:bg-purple-950/40 border-purple-600 text-purple-700 dark:text-purple-300'
                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    🛠️ حل التكليفات والتمارين
                  </button>
                </div>
              </div>

              {/* Ready Formulated Prompt Preview */}
              <div className="relative">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                    البرومبت الأكاديمي الجاهز للنسخ:
                  </span>
                  <button
                    onClick={handleCopyPrompt}
                    className="flex items-center gap-1.5 px-3 py-1 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-lg transition cursor-pointer shadow-xs"
                  >
                    {copiedPrompt ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-300" />
                        <span>تم النسخ بنجاح!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>نسخ البرومبت</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900 text-slate-200 text-xs font-mono whitespace-pre-wrap max-h-48 overflow-y-auto border border-slate-800 dir-ltr text-right">
                  {externalData.prompt}
                </div>
              </div>

              {/* Direct Open Buttons */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-3">
                  الانتقال المباشر لأشهر منصات الذكاء الاصطناعي:
                </label>
                <div className="grid sm:grid-cols-2 gap-3">
                  <a
                    href={externalData.geminiUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={handleCopyPrompt}
                    className="p-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center justify-between transition shadow-sm cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-blue-200" />
                      <span>فتح Google Gemini (مع نسخ البرومبت)</span>
                    </div>
                    <ExternalLink className="w-4 h-4" />
                  </a>

                  <a
                    href={externalData.chatGptUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={handleCopyPrompt}
                    className="p-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-between transition shadow-sm cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <Bot className="w-4 h-4 text-emerald-200" />
                      <span>فتح ChatGPT مباشرة</span>
                    </div>
                    <ExternalLink className="w-4 h-4" />
                  </a>

                  <a
                    href={externalData.claudeUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={handleCopyPrompt}
                    className="p-3.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold flex items-center justify-between transition shadow-sm cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <Bot className="w-4 h-4 text-amber-200" />
                      <span>فتح Claude AI (مع نسخ البرومبت)</span>
                    </div>
                    <ExternalLink className="w-4 h-4" />
                  </a>

                  <a
                    href={externalData.copilotUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={handleCopyPrompt}
                    className="p-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold flex items-center justify-between transition shadow-sm cursor-pointer border border-slate-700"
                  >
                    <div className="flex items-center gap-2">
                      <Bot className="w-4 h-4 text-cyan-300" />
                      <span>فتح Microsoft Copilot</span>
                    </div>
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-slate-50 dark:bg-slate-900/90 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
            <Sparkles className="w-3.5 h-3.5 text-blue-500" />
            <span>مدعوم بالذكاء الاصطناعي الأكاديمي لمنصة Online Courses</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold rounded-xl transition cursor-pointer"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
};
