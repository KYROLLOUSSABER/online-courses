import React, { useState } from 'react';
import { 
  Bell, 
  X, 
  Clock, 
  Sparkles, 
  Check, 
  AlertCircle, 
  ChevronDown, 
  ExternalLink,
  BookOpen
} from 'lucide-react';
import { NotificationItem, ContentItem, AcademicYearId } from '../types';
import { ACADEMIC_YEARS } from '../data/mockData';

interface NotificationCenterProps {
  notifications: NotificationItem[];
  activeYear?: AcademicYearId;
  onOpenContent?: (contentId: string) => void;
  onMarkAsRead?: (id: string) => void;
  onClearAll?: () => void;
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({
  notifications,
  activeYear,
  onOpenContent,
  onMarkAsRead,
  onClearAll
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [dismissedTopBanner, setDismissedTopBanner] = useState(false);

  // Filter relevant notifications (if activeYear is given, show that year's or all)
  const relevantNotifications = notifications.filter(n => !activeYear || n.yearId === activeYear);
  const unreadCount = relevantNotifications.filter(n => !n.isRead).length;

  // Latest unread notification for the top floating ticker
  const latestAlert = relevantNotifications.find(n => !n.isRead);

  return (
    <>
      {/* 1. TOP TICKER BANNER (يظهر في أعلى الشاشة للطلاب عند إضافة مادة جديدة أو تحديث ديدلاين) */}
      {!dismissedTopBanner && latestAlert && (
        <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 text-white text-xs font-semibold py-2.5 px-4 shadow-md border-b border-blue-500/30 transition-all animate-in slide-in-from-top duration-300">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
            
            <div className="flex items-center gap-2.5 flex-1 min-w-0">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping shrink-0" />
              
              <div className="p-1 rounded-md bg-white/10 shrink-0">
                {latestAlert.type === 'deadline_updated' ? (
                  <Clock className="w-3.5 h-3.5 text-amber-300" />
                ) : (
                  <Sparkles className="w-3.5 h-3.5 text-blue-200" />
                )}
              </div>

              <div className="flex items-center gap-2 truncate">
                <span className="font-bold text-amber-300 shrink-0">
                  [{ACADEMIC_YEARS.find(y => y.id === latestAlert.yearId)?.shortTitle || 'تنبيه'}]
                </span>
                <span className="font-bold shrink-0">{latestAlert.title}:</span>
                <span className="text-blue-100 truncate">{latestAlert.message}</span>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {latestAlert.contentId && onOpenContent && (
                <button
                  onClick={() => {
                    onOpenContent(latestAlert.contentId!);
                    if (onMarkAsRead) onMarkAsRead(latestAlert.id);
                  }}
                  className="px-2.5 py-1 rounded-lg bg-white/20 hover:bg-white/30 text-white font-bold text-[11px] transition-colors cursor-pointer flex items-center gap-1"
                >
                  <span>عرض المادة</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              )}

              <button
                onClick={() => {
                  setDismissedTopBanner(true);
                  if (onMarkAsRead) onMarkAsRead(latestAlert.id);
                }}
                className="p-1 text-blue-200 hover:text-white rounded hover:bg-white/10 transition-colors"
                title="إغلاق التنبيه"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

          </div>
        </div>
      )}

      {/* 2. NOTIFICATION BELL & DROPDOWN DRAWER */}
      <div className="relative">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="relative p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          title="الإشعارات والتنبيهات الدراسية"
        >
          <Bell className="w-5 h-5" />
          {unreadCount > 0 && (
            <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-red-600 text-white text-[10px] font-black flex items-center justify-center animate-bounce">
              {unreadCount > 9 ? '+9' : unreadCount}
            </span>
          )}
        </button>

        {/* Dropdown Panel */}
        {isOpen && (
          <div 
            className="absolute left-0 mt-2 w-80 sm:w-96 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 z-50 overflow-hidden text-right animate-in fade-in zoom-in-95"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="p-4 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <h4 className="text-xs font-black text-slate-900 dark:text-white">
                  التنبيهات والإشعارات الأكاديمية
                </h4>
              </div>

              {relevantNotifications.length > 0 && onClearAll && (
                <button
                  onClick={onClearAll}
                  className="text-[11px] text-slate-500 hover:text-red-600 dark:text-slate-400 dark:hover:text-red-400 transition-colors"
                >
                  مسح الكل
                </button>
              )}
            </div>

            {/* List */}
            <div className="max-h-80 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
              {relevantNotifications.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-xs">
                  <Bell className="w-8 h-8 mx-auto mb-2 opacity-40" />
                  <p>لا توجد إشعارات جديدة حالياً</p>
                  <span className="text-[10px] text-slate-500">ستظهر هنا التنبيهات عند إضافة مواد أو تحديث مواعيد التسليم</span>
                </div>
              ) : (
                relevantNotifications.map((notif) => {
                  const yearName = ACADEMIC_YEARS.find(y => y.id === notif.yearId)?.shortTitle || notif.yearId;
                  return (
                    <div
                      key={notif.id}
                      onClick={() => {
                        if (notif.contentId && onOpenContent) {
                          onOpenContent(notif.contentId);
                          setIsOpen(false);
                        }
                        if (onMarkAsRead) onMarkAsRead(notif.id);
                      }}
                      className={`p-3.5 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors cursor-pointer ${
                        !notif.isRead ? 'bg-blue-50/60 dark:bg-blue-950/20' : ''
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300">
                            {yearName}
                          </span>
                          {notif.type === 'deadline_updated' ? (
                            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-100 dark:bg-amber-900/50 text-amber-700 dark:text-amber-300 flex items-center gap-1">
                              <Clock className="w-2.5 h-2.5" />
                              ديدلاين
                            </span>
                          ) : (
                            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-300">
                              مادة جديدة
                            </span>
                          )}
                        </div>

                        <span className="text-[10px] text-slate-400 font-mono">
                          {new Date(notif.createdAt).toLocaleDateString('ar-EG')}
                        </span>
                      </div>

                      <h5 className="text-xs font-bold text-slate-900 dark:text-white mb-0.5">
                        {notif.title}
                      </h5>
                      <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-snug">
                        {notif.message}
                      </p>

                      {notif.dueDate && (
                        <div className="mt-2 text-[10px] font-bold text-amber-600 dark:text-amber-400 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span>تاريخ التسليم: {notif.dueDate}</span>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>

            {/* Footer */}
            <div className="p-2.5 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-200 dark:border-slate-700 text-center text-[10px] text-slate-500">
              يتم إشعارك فوراً بأي محتوى جديد أو تحديث لمواعيد الفرقة الدراسية
            </div>

          </div>
        )}
      </div>
    </>
  );
};
