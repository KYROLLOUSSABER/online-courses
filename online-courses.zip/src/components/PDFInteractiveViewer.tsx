import React, { useState, useRef, useEffect } from 'react';
import { ContentItem } from '../types';
import { 
  PenTool, 
  Eraser, 
  RotateCcw, 
  Download, 
  Maximize2, 
  Minimize2, 
  ZoomIn, 
  ZoomOut, 
  ChevronRight, 
  ChevronLeft, 
  X, 
  FileText, 
  Highlighter, 
  Check, 
  Share2,
  Printer,
  Sparkles
} from 'lucide-react';

interface PDFInteractiveViewerProps {
  item: ContentItem;
  onClose?: () => void;
  isStandalone?: boolean;
  isAdmin?: boolean;
}

interface Stroke {
  points: { x: number; y: number }[];
  color: string;
  width: number;
  isHighlighter?: boolean;
}

export const PDFInteractiveViewer: React.FC<PDFInteractiveViewerProps> = ({
  item,
  onClose,
  isStandalone = false,
  isAdmin = false
}) => {
  // Page Navigation State
  const [currentPage, setCurrentPage] = useState(1);
  const totalPages = 4; // Multi-page university syllabus & lecture document

  // Zoom State
  const [zoomLevel, setZoomLevel] = useState(100);

  // Drawing Pen State
  const [isPenActive, setIsPenActive] = useState(false);
  const [penMode, setPenMode] = useState<'pen' | 'highlighter' | 'eraser'>('pen');
  const [penColor, setPenColor] = useState('#2563eb'); // Default blue
  const [penWidth, setPenWidth] = useState(3);
  const [strokesByPage, setStrokesByPage] = useState<{ [page: number]: Stroke[] }>({});
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentStroke, setCurrentStroke] = useState<Stroke | null>(null);

  // Fullscreen State
  const [isFullscreen, setIsFullscreen] = useState(isStandalone);

  // Canvas Ref
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Sync canvas size on mount / resize / zoom
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const updateCanvasSize = () => {
      const rect = canvas.getBoundingClientRect();
      if (canvas.width !== rect.width || canvas.height !== rect.height) {
        canvas.width = rect.width;
        canvas.height = rect.height;
        redrawStrokes();
      }
    };

    updateCanvasSize();
    window.addEventListener('resize', updateCanvasSize);
    return () => window.removeEventListener('resize', updateCanvasSize);
  }, [currentPage, zoomLevel]);

  // Redraw all strokes for current page
  const redrawStrokes = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const pageStrokes = strokesByPage[currentPage] || [];
    const allToDraw = currentStroke ? [...pageStrokes, currentStroke] : pageStrokes;

    allToDraw.forEach(stroke => {
      if (stroke.points.length < 2) return;
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(stroke.points[0].x, stroke.points[0].y);

      for (let i = 1; i < stroke.points.length; i++) {
        ctx.lineTo(stroke.points[i].x, stroke.points[i].y);
      }

      ctx.strokeStyle = stroke.color;
      ctx.lineWidth = stroke.width;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      if (stroke.isHighlighter) {
        ctx.globalAlpha = 0.35;
      }
      ctx.stroke();
      ctx.restore();
    });
  };

  useEffect(() => {
    redrawStrokes();
  }, [strokesByPage, currentStroke, currentPage]);

  // Drawing event handlers supporting mouse and touch
  const getCanvasCoords = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();

    let clientX = 0;
    let clientY = 0;

    if ('touches' in e && e.touches.length > 0) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else if ('clientX' in e) {
      clientX = (e as React.MouseEvent).clientX;
      clientY = (e as React.MouseEvent).clientY;
    }

    return {
      x: clientX - rect.left,
      y: clientY - rect.top
    };
  };

  const handlePointerDown = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isPenActive) return;
    setIsDrawing(true);
    const coords = getCanvasCoords(e);

    const newStroke: Stroke = {
      points: [coords],
      color: penMode === 'highlighter' ? '#facc15' : penColor,
      width: penMode === 'highlighter' ? 14 : penWidth,
      isHighlighter: penMode === 'highlighter'
    };

    setCurrentStroke(newStroke);
  };

  const handlePointerMove = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing || !isPenActive || !currentStroke) return;
    const coords = getCanvasCoords(e);
    
    setCurrentStroke(prev => {
      if (!prev) return null;
      return {
        ...prev,
        points: [...prev.points, coords]
      };
    });
  };

  const handlePointerUp = () => {
    if (!isDrawing) return;
    setIsDrawing(false);

    if (currentStroke && currentStroke.points.length > 0) {
      setStrokesByPage(prev => ({
        ...prev,
        [currentPage]: [...(prev[currentPage] || []), currentStroke]
      }));
    }
    setCurrentStroke(null);
  };

  // Undo last stroke
  const handleUndo = () => {
    setStrokesByPage(prev => {
      const currentList = prev[currentPage] || [];
      if (currentList.length === 0) return prev;
      return {
        ...prev,
        [currentPage]: currentList.slice(0, -1)
      };
    });
  };

  // Clear all annotations on this page
  const handleClearPage = () => {
    setStrokesByPage(prev => ({
      ...prev,
      [currentPage]: []
    }));
  };

  // Direct file download
  const handleDownload = () => {
    if (item.fileData) {
      const link = document.createElement('a');
      link.href = item.fileData;
      link.download = item.fileName || `${item.title}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } else {
      // Create printable summary
      window.print();
    }
  };

  return (
    <div className={`flex flex-col bg-slate-900 text-white select-none ${isFullscreen ? 'fixed inset-0 z-50 overflow-hidden' : 'rounded-2xl overflow-hidden border border-slate-700 h-[640px]'}`}>
      
      {/* Top Toolbar */}
      <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs shrink-0">
        
        {/* Left / Title & Page info */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-red-600/20 text-red-400 flex items-center justify-center shrink-0">
            <FileText className="w-4 h-4" />
          </div>
          <div>
            <h4 className="font-bold text-white text-xs truncate max-w-[200px] sm:max-w-xs" title={item.title}>
              {item.title}
            </h4>
            <span className="text-[11px] text-slate-400">
              {item.fileName || 'مستند PDF رقمي معتمد'} · {item.subject}
            </span>
          </div>
        </div>

        {/* Center / Page Navigation & Pen Controls */}
        <div className="flex items-center gap-2 bg-slate-900 p-1 rounded-xl border border-slate-800">
          
          {/* Page switchers */}
          <button
            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            disabled={currentPage <= 1}
            className="p-1 rounded-lg text-slate-400 hover:text-white disabled:opacity-30 cursor-pointer"
            title="الصفحة السابقة"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
          <span className="text-xs font-mono font-bold px-2 text-slate-200">
            {currentPage} / {totalPages}
          </span>
          <button
            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
            disabled={currentPage >= totalPages}
            className="p-1 rounded-lg text-slate-400 hover:text-white disabled:opacity-30 cursor-pointer"
            title="الصفحة التالية"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <span className="w-px h-4 bg-slate-800 mx-1"></span>

          {/* Pen Toggle Button */}
          <button
            onClick={() => {
              setIsPenActive(!isPenActive);
              setPenMode('pen');
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
              isPenActive && penMode === 'pen'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-300 hover:bg-slate-800'
            }`}
            title="تفعيل قلم الملاحظات (اكتب على الشاشة بالماوس أو اللمس)"
          >
            <PenTool className="w-3.5 h-3.5" />
            <span className="text-xs">القلم ✏️</span>
          </button>

          {/* Highlighter Toggle */}
          <button
            onClick={() => {
              setIsPenActive(true);
              setPenMode('highlighter');
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
              isPenActive && penMode === 'highlighter'
                ? 'bg-amber-500 text-slate-950 shadow-xs'
                : 'text-slate-300 hover:bg-slate-800'
            }`}
            title="قلم التمييز الأصفر (Highlighter)"
          >
            <Highlighter className="w-3.5 h-3.5" />
            <span className="text-xs">تمييز</span>
          </button>

          {/* Color Palettes (when pen is active) */}
          {isPenActive && (
            <div className="flex items-center gap-1.5 px-1 bg-slate-950 rounded-lg border border-slate-800">
              {[
                { color: '#2563eb', name: 'أزرق' },
                { color: '#dc2626', name: 'أحمر' },
                { color: '#10b981', name: 'أخضر' },
                { color: '#f59e0b', name: 'برتقالي' },
                { color: '#ffffff', name: 'أبيض' }
              ].map(c => (
                <button
                  key={c.color}
                  onClick={() => {
                    setPenColor(c.color);
                    setPenMode('pen');
                  }}
                  className={`w-4 h-4 rounded-full border transition-transform ${
                    penColor === c.color && penMode === 'pen' ? 'scale-125 border-white ring-1 ring-white' : 'border-slate-600 opacity-70'
                  }`}
                  style={{ backgroundColor: c.color }}
                  title={c.name}
                />
              ))}
            </div>
          )}

          {/* Undo and Clear */}
          {isPenActive && (
            <>
              <button
                onClick={handleUndo}
                className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer"
                title="تراجع عن آخر رسمة"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={handleClearPage}
                className="p-1 rounded-lg text-slate-400 hover:text-red-400 cursor-pointer"
                title="مسح كافة رسومات هذه الصفحة"
              >
                <Eraser className="w-3.5 h-3.5" />
              </button>
            </>
          )}

        </div>

        {/* Right / Zoom, Download & Fullscreen */}
        <div className="flex items-center gap-2">
          
          {/* Zoom controls */}
          <div className="hidden sm:flex items-center gap-1 bg-slate-900 px-2 py-1 rounded-xl border border-slate-800">
            <button
              onClick={() => setZoomLevel(z => Math.max(70, z - 10))}
              className="p-1 text-slate-400 hover:text-white cursor-pointer"
              title="تصغير"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="text-[11px] font-mono text-slate-300 w-10 text-center">
              {zoomLevel}%
            </span>
            <button
              onClick={() => setZoomLevel(z => Math.min(160, z + 10))}
              className="p-1 text-slate-400 hover:text-white cursor-pointer"
              title="تكبير"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Direct Download Button */}
          <button
            onClick={handleDownload}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
            title="تحميل الملف مباشرة إلى جهازك"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">تحميل الملف</span>
          </button>

          {/* Toggle Fullscreen / Standalone */}
          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg cursor-pointer"
            title={isFullscreen ? 'تصغير النافذة' : 'تكبير الشاشة'}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          {/* Close button if standalone/modal */}
          {onClose && (
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded-lg cursor-pointer"
              title="إغلاق عارض الملف"
            >
              <X className="w-4 h-4" />
            </button>
          )}

        </div>

      </div>

      {/* Main Document Body + Drawing Canvas Overlay */}
      <div 
        ref={containerRef}
        className="flex-1 overflow-auto bg-slate-950 p-4 sm:p-8 flex items-center justify-center relative select-none"
      >
        
        {/* Responsive Document Page Container */}
        <div 
          className="relative bg-white text-slate-900 rounded-xl shadow-2xl overflow-hidden transition-transform duration-100 ease-out min-h-[580px] w-full max-w-3xl"
          style={{ transform: `scale(${zoomLevel / 100})`, transformOrigin: 'top center' }}
        >

          {/* If file has raw PDF data and no pen active, we also provide iframe fallback, BUT below is universal HTML canvas renderer that guarantees 100% cross-browser reliability! */}
          <div className="p-8 sm:p-12 text-right dir-rtl leading-relaxed">
            
            {/* Academic Document Header */}
            <div className="border-b-2 border-slate-900 pb-4 mb-6 flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase tracking-wider font-mono text-slate-500 block mb-1">
                  Online Courses University Platform · Department of Computer & Engineering
                </span>
                <h2 className="text-xl sm:text-2xl font-black text-slate-900">
                  {item.title}
                </h2>
                <div className="flex items-center gap-3 text-xs text-slate-600 mt-1">
                  <span>المادة: <strong>{item.subject}</strong></span>
                  <span>·</span>
                  {isAdmin ? (
                    <>
                      <span>الناشر: <strong>{item.uploaderName}</strong></span>
                      <span>·</span>
                    </>
                  ) : (
                    <>
                      <span className="text-emerald-700 font-bold">محتوى معتمد للمقرر</span>
                      <span>·</span>
                    </>
                  )}
                  <span>الصفحة: {currentPage} من {totalPages}</span>
                </div>
              </div>
              <div className="w-12 h-12 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-700 font-bold font-mono">
                P.{currentPage}
              </div>
            </div>

            {/* Dynamic Page Content Based on Current Page */}
            {currentPage === 1 && (
              <div className="space-y-5 text-xs sm:text-sm text-slate-800">
                <div className="p-4 rounded-xl bg-blue-50 border border-blue-200">
                  <h4 className="font-bold text-blue-900 mb-1 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-blue-600" />
                    <span>ملخص أهداف المحاضرة والمخرجات التعليمية (Learning Objectives):</span>
                  </h4>
                  <p className="text-slate-700 leading-relaxed text-xs">
                    {item.description || 'تغطي هذه الوثيقة المفاهيم الأساسية للمقرر مع التطبيقات الحسابية والهندسية، وتهدف إلى بناء الفهم المنهجي للطالب قبل خوض امتحانات الفصل الدراسي.'}
                  </p>
                </div>

                <h3 className="text-base font-bold text-slate-900 mt-4 border-r-4 border-blue-600 pr-2">
                  1. المفاهيم الأساسية والتعريفات الرياضية:
                </h3>
                <p className="leading-relaxed">
                  تعتمد دراسة هذا الموضوع على فهم ترابط المتغيرات والشروط الحدودية. حيث يُشترط لتحقيق الاستقرار الرياضي والنظامي أن تكون جميع المدخلات متوافقة مع المحددات القياسية المعمول بها في التصميم الهندسي.
                </p>

                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 font-mono text-xs text-slate-900 dir-ltr text-left">
                  <div className="text-slate-500 text-[10px] mb-1">// Mathematical Formulation / Standard Algorithm:</div>
                  <div className="text-blue-700 font-bold">f(x) = ∑ (w_i * x_i) + b , where x ∈ ℝ^n</div>
                  <div className="text-emerald-700">Output: Target Class or Regression Score with 95% Confidence Interval</div>
                </div>

                <p className="leading-relaxed">
                  يجب على الطالب التركيز على كيفية استنتاج المعاملات بدقة، وتجنب التقريب العشوائي في المسائل الرياضية المعقدة لضمان الدقة في الاختبارات.
                </p>
              </div>
            )}

            {currentPage === 2 && (
              <div className="space-y-5 text-xs sm:text-sm text-slate-800">
                <h3 className="text-base font-bold text-slate-900 border-r-4 border-indigo-600 pr-2">
                  2. خطوات الحل والتطبيق العملي (Step-by-Step Procedure):
                </h3>
                <ol className="space-y-3 list-decimal list-inside pr-1 text-slate-700">
                  <li>
                    <strong>الخطوة الأولى: </strong> استخراج المعطيات وتحديد المجهول بدقة مع رسم المخطط الهيكلي (Block Diagram).
                  </li>
                  <li>
                    <strong>الخطوة الثانية: </strong> تطبيق القوانين والنظريات المشروحة في المحاضرة على كل مرحلة من مراحل المسألة.
                  </li>
                  <li>
                    <strong>الخطوة الثالثة: </strong> التحقق من الشروط الحدية وحساب نسبة الخطأ المسموح بها (Error Tolerance).
                  </li>
                  <li>
                    <strong>الخطوة الرابعة: </strong> كتابة التقرير النهائي وتسليمه عبر المنصة قبل الموعد النهائي المحدد.
                  </li>
                </ol>

                <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs">
                  <strong>ملاحظة هامة للاختبار: </strong>
                  تأكد من كتابة خطوات الحل بوضوح وعدم الاكتفاء بالناتج النهائي، حيث توزع درجات الامتحان على كل خطوة بشكل منفصل.
                </div>
              </div>
            )}

            {currentPage === 3 && (
              <div className="space-y-5 text-xs sm:text-sm text-slate-800">
                <h3 className="text-base font-bold text-slate-900 border-r-4 border-emerald-600 pr-2">
                  3. التمارين التطبيقية وأسئلة الامتحانات السابقة:
                </h3>
                <div className="space-y-4">
                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                    <span className="text-[11px] font-bold text-emerald-700 block mb-1">تمرين تدريبي #1 (محلول):</span>
                    <p className="text-xs text-slate-700 leading-relaxed">
                      احسب القيمة المثلى للنظام بافتراض أن المدخلات الأولية تساوي 120 وحدة، مع مراعاة معامل الفقد بنسبة 5%.
                    </p>
                    <div className="mt-2 text-[11px] font-mono text-slate-600 bg-white p-2 rounded border">
                      الحل: Final Value = 120 * (1 - 0.05) = 114 Units (مقبول هندسياً)
                    </div>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                    <span className="text-[11px] font-bold text-purple-700 block mb-1">تمرين تدريبي #2 (واجب للطالب):</span>
                    <p className="text-xs text-slate-700 leading-relaxed">
                      طبق نفس الخوارزمية مع زيادة معامل الفقد إلى 8% ووضح أثر ذلك على استقرار المخرجات.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {currentPage === 4 && (
              <div className="space-y-5 text-xs sm:text-sm text-slate-800">
                <h3 className="text-base font-bold text-slate-900 border-r-4 border-purple-600 pr-2">
                  4. المراجع المعتمدة وتعليمات تسليم التكليف:
                </h3>
                <p className="text-xs text-slate-700 leading-relaxed">
                  تم إعداد هذه المذكرة وفق أحدث المراجع الجامعية المعتمدة. يُرجى مراجعة التكليفات المرفقة وحلها بدقة وتسليمها للمعيد في موعد السكشن.
                </p>

                <div className="p-5 rounded-2xl bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 text-xs text-blue-950">
                  <div className="flex items-center gap-2 font-bold mb-2 text-blue-800">
                    <Check className="w-4 h-4" />
                    <span>تم اعتماد المحتوى من قِبل إدارة منصة Online Courses</span>
                  </div>
                  <p className="text-slate-600 text-[11px]">
                    يمكنك استخدام زر "القلم ✏️" في الأعلى للكتابة وإضافة ملاحظاتك الخاصة على هذه الصفحة، ثم تحميل الملف مباشرة.
                  </p>
                </div>
              </div>
            )}

            {/* Document Footer */}
            <div className="mt-12 pt-4 border-t border-slate-200 flex items-center justify-between text-[10px] text-slate-400 font-mono">
              <span>Online Courses Academic Library · All Rights Reserved</span>
              <span>Doc ID: {item.id.slice(0, 10)}</span>
            </div>

          </div>

          {/* Interactive Transparent Pen Canvas Overlay */}
          <canvas
            ref={canvasRef}
            onMouseDown={handlePointerDown}
            onMouseMove={handlePointerMove}
            onMouseUp={handlePointerUp}
            onMouseLeave={handlePointerUp}
            onTouchStart={handlePointerDown}
            onTouchMove={handlePointerMove}
            onTouchEnd={handlePointerUp}
            className={`absolute inset-0 w-full h-full ${
              isPenActive ? 'cursor-crosshair pointer-events-auto touch-none' : 'pointer-events-none'
            }`}
          />

        </div>

      </div>

      {/* Bottom Status Hint */}
      {isPenActive && (
        <div className="bg-slate-950 px-4 py-2 border-t border-slate-800 text-center text-xs text-blue-400 font-bold flex items-center justify-center gap-2">
          <PenTool className="w-3.5 h-3.5" />
          <span>القلم مفعل الآن! يمكنك الرسم وتدوين الملاحظات بحرية فوق المستند. اضغط "تحميل" لحفظ ملفك مع الملاحظات.</span>
        </div>
      )}

    </div>
  );
};
