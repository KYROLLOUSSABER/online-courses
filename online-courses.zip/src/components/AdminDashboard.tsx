import React, { useState, useMemo, useEffect } from 'react';
import { 
  UserAccount, 
  ContentItem, 
  AcademicYearId, 
  CategoryId, 
  ContentType, 
  CategoryDefinition, 
  SubjectItem,
  SupervisorPermissions,
  DepartmentId,
  SemesterId,
  MaintenanceConfig,
  ActivityLogItem
} from '../types';
import { StorageService } from '../services/storage';
import { ACADEMIC_YEARS, DEPARTMENTS, SEMESTERS } from '../data/mockData';
import { 
  ShieldCheck, 
  Users, 
  FilePlus, 
  Settings, 
  Trash2, 
  Mail, 
  UserPlus, 
  Upload, 
  Video, 
  FileText, 
  ExternalLink, 
  Search, 
  Check, 
  AlertCircle, 
  Eye, 
  EyeOff, 
  ArrowRight, 
  BookOpen, 
  Layers, 
  Edit3, 
  FolderPlus, 
  BookMarked,
  LayoutGrid,
  CheckSquare,
  Square,
  Lock,
  Plus,
  Clock,
  Wrench,
  Power,
  HardDrive,
  Sparkles,
  RefreshCw,
  AlertTriangle,
  History,
  FileDown,
  FileUp,
  Download,
  Filter,
  Calendar,
  TrendingUp,
  BarChart3,
  Cloud,
  Database,
  CheckCircle2
} from 'lucide-react';
import { EditContentModal } from './EditContentModal';
import { DeleteConfirmationModal } from './DeleteConfirmationModal';
import { AnalyticsDashboard } from './AnalyticsDashboard';
import { SupabaseStorageService, BUCKET_NAME, SupabaseStorageStats } from '../services/supabase';

interface AdminDashboardProps {
  currentUser: UserAccount;
  contentList: ContentItem[];
  onRefreshData: () => void;
  onBackToSite: () => void;
  onOpenContent: (item: ContentItem) => void;
  preselectedYear?: AcademicYearId;
  preselectedCategory?: CategoryId;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  currentUser,
  contentList,
  onRefreshData,
  onBackToSite,
  onOpenContent,
  preselectedYear,
  preselectedCategory
}) => {
  const isAdmin = currentUser.role === 'admin';

  // Active tab state
  type TabType = 'overview' | 'analytics' | 'add-content' | 'subjects' | 'categories' | 'supervisors' | 'content' | 'profile' | 'maintenance' | 'activity' | 'backup';
  const [activeTab, setActiveTab] = useState<TabType>(
    preselectedCategory ? 'add-content' : 'overview'
  );

  // Edit content item state
  const [editingItem, setEditingItem] = useState<ContentItem | null>(null);

  // In-app Delete Confirmation State
  const [itemToDelete, setItemToDelete] = useState<{ id: string; title: string; type: 'content' | 'subject' | 'category' | 'supervisor' } | null>(null);

  // Dynamic Categories and Subjects from storage
  const [categoriesList, setCategoriesList] = useState<CategoryDefinition[]>(StorageService.getCategories());
  const [subjectsList, setSubjectsList] = useState<SubjectItem[]>(StorageService.getSubjects());
  const [supervisorsList, setSupervisorsList] = useState<UserAccount[]>(StorageService.getSupervisors());

  // Maintenance Mode state
  const [maintenanceConfig, setMaintenanceConfig] = useState<MaintenanceConfig>(() => StorageService.getMaintenanceMode());
  const [maintenanceMessage, setMaintenanceMessage] = useState(maintenanceConfig.message || '');
  const [maintenanceReason, setMaintenanceReason] = useState(maintenanceConfig.reason || '');
  const [maintenanceEndTime, setMaintenanceEndTime] = useState(maintenanceConfig.estimatedEndTime || '');

  const handleSaveMaintenance = (enabled: boolean) => {
    const updated: MaintenanceConfig = {
      isEnabled: enabled,
      message: maintenanceMessage.trim() || undefined,
      reason: maintenanceReason.trim() || undefined,
      estimatedEndTime: maintenanceEndTime.trim() || undefined,
      activatedAt: enabled ? new Date().toISOString() : undefined
    };
    StorageService.setMaintenanceMode(updated);
    setMaintenanceConfig(updated);
    showToast(enabled ? 'تم تفعيل وضع الصيانة بنجاح! الموقع الآن محجوب عن الطلاب والزوار ⚠️' : 'تم تعطيل وضع الصيانة بنجاح! الموقع متاح للجميع الآن ✅');
    onRefreshData();
  };

  // Storage Capacity & Stats (Local & Supabase Cloud)
  const [storageStats, setStorageStats] = useState(() => StorageService.getStorageStats());
  const [supabaseStats, setSupabaseStats] = useState<SupabaseStorageStats | null>(null);

  useEffect(() => {
    SupabaseStorageService.getStorageStats().then(setSupabaseStats).catch(console.error);
  }, []);

  // Upload Progress State
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [uploadStatusText, setUploadStatusText] = useState<string>('');

  // Clean Slate Confirmation Modal State
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);

  // Activity Logs State
  const [activityLogs, setActivityLogs] = useState<ActivityLogItem[]>(() => StorageService.getActivityLogs());
  const [activityActionFilter, setActivityActionFilter] = useState<string>('all');
  const [activitySearchQuery, setActivitySearchQuery] = useState<string>('');

  // Backup Import State
  const [backupToImport, setBackupToImport] = useState<any | null>(null);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);

  const refreshAllState = () => {
    setCategoriesList(StorageService.getCategories());
    setSubjectsList(StorageService.getSubjects());
    setSupervisorsList(StorageService.getSupervisors());
    setMaintenanceConfig(StorageService.getMaintenanceMode());
    setStorageStats(StorageService.getStorageStats());
    setActivityLogs(StorageService.getActivityLogs());
    onRefreshData();
  };

  const handleResetPlatform = () => {
    StorageService.clearAllPlatformData(currentUser);
    setIsResetConfirmOpen(false);
    refreshAllState();
    showToast('تم تفريغ كافة المواد والمحتويات بنجاح! المنصة الآن فارغة وجاهزة لإضافة موادك الخاصة 🧹');
  };

  const handleExportBackup = () => {
    try {
      StorageService.downloadBackupFile(currentUser);
      refreshAllState();
      showToast('تم تصدير وتحميل النسخة الاحتياطية بنجاح بصيغة JSON! احتفظ بالملف بأمان 💾');
    } catch {
      showToast('حدث خطأ أثناء تصدير النسخة الاحتياطية', 'error');
    }
  };

  const handleImportFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(reader.result as string);
        if (!parsed || typeof parsed !== 'object') {
          showToast('الملف المختار غير صالح', 'error');
          return;
        }
        setBackupToImport(parsed);
        setIsImportModalOpen(true);
      } catch {
        showToast('الملف ليس ملف JSON صحيح!', 'error');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleConfirmImport = () => {
    if (!backupToImport) return;
    const res = StorageService.importBackup(backupToImport, currentUser);
    if (res.success) {
      setIsImportModalOpen(false);
      setBackupToImport(null);
      refreshAllState();
      showToast(`تمت استعادة كافة البيانات بنجاح! (${res.restoredCounts?.content || 0} محتوى، ${res.restoredCounts?.subjects || 0} مادة) 🎉`);
    } else {
      showToast(res.error || 'تعذر استيراد النسخة الاحتياطية', 'error');
    }
  };

  const handleClearActivityLogs = () => {
    StorageService.clearActivityLogs();
    refreshAllState();
    showToast('تم مسح سجل الأنشطة بنجاح');
  };

  // Toast Notifications
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);
  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 4000);
  };

  // =========================================================================
  // 1. UPLOAD CONTENT STATE
  // =========================================================================
  const [targetYear, setTargetYear] = useState<AcademicYearId>(preselectedYear || 'year-1');
  const [targetDepartment, setTargetDepartment] = useState<DepartmentId>('cs');
  const [targetSemester, setTargetSemester] = useState<SemesterId>('sem-1');
  const [targetCategory, setTargetCategory] = useState<CategoryId>(preselectedCategory || categoriesList[0]?.id || 'lectures');
  const [contentSubject, setContentSubject] = useState<string>('');
  const [newCustomSubject, setNewCustomSubject] = useState<string>('');
  const [contentTitle, setContentTitle] = useState<string>('');
  const [contentDescription, setContentDescription] = useState<string>('');
  const [contentType, setContentType] = useState<ContentType>('file');
  const [uploadedFile, setUploadedFile] = useState<{ 
    name: string; 
    size: string; 
    type: string; 
    data: string; 
    publicUrl?: string; 
    isCloud?: boolean;
  } | null>(null);
  const [youtubeUrl, setYoutubeUrl] = useState<string>('');
  const [externalUrl, setExternalUrl] = useState<string>('');
  const [externalUrlTitle, setExternalUrlTitle] = useState<string>('');
  const [dueDate, setDueDate] = useState<string>('');
  const [deadlineNote, setDeadlineNote] = useState<string>('');

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const sizeInMb = (file.size / (1024 * 1024)).toFixed(2);

    setIsUploading(true);
    setUploadProgress(15);
    setUploadStatusText(`جاري الاتصال بسحابة Supabase Storage وتجهيز ملف "${file.name}"...`);

    // Stepped progressive feedback
    let prog = 15;
    const progressTimer = setInterval(() => {
      prog = Math.min(85, prog + Math.floor(Math.random() * 15) + 10);
      setUploadProgress(prog);
      setUploadStatusText(`جاري رفع الملف إلى سحابة Supabase Storage (1000MB)... ${prog}%`);
    }, 100);

    try {
      // 1. Attempt upload to Supabase Cloud Storage (1,000 MB Quota)
      const cloudResult = await SupabaseStorageService.uploadFile(file);

      clearInterval(progressTimer);

      if (cloudResult.success && cloudResult.publicUrl) {
        setUploadProgress(100);
        setUploadStatusText('اكتمل الرفع إلى سحابة Supabase بنجاح (سعة 1000MB) ☁️');
        setTimeout(() => {
          setIsUploading(false);
          setUploadedFile({
            name: file.name,
            size: `${sizeInMb} ميجابايت`,
            type: file.type,
            data: cloudResult.publicUrl!,
            publicUrl: cloudResult.publicUrl,
            isCloud: true
          });
          // Refresh Supabase stats
          SupabaseStorageService.getStorageStats().then(setSupabaseStats);
          showToast(`تم رفع "${file.name}" (${sizeInMb} ميجابايت) إلى سحابة Supabase بنجاح! ☁️🎉`);
        }, 300);
        return;
      }

      // 2. If cloud upload returns notice (e.g., bucket 'course-files' not yet created), fallback to local storage
      console.warn('Supabase upload notice:', cloudResult.error);
      const reader = new FileReader();
      reader.onload = () => {
        setUploadProgress(100);
        setUploadStatusText('تم حفظ الملف في الذاكرة المحلية بنجاح');
        setTimeout(() => {
          setIsUploading(false);
          setUploadedFile({
            name: file.name,
            size: `${sizeInMb} ميجابايت`,
            type: file.type,
            data: reader.result as string,
            isCloud: false
          });
          setStorageStats(StorageService.getStorageStats());
          showToast(
            `تم تجهيز الملف محلياً (${sizeInMb} MB). لرفعه سحابياً (1000MB)، تأكد من إنشاء مجلد باسم "${BUCKET_NAME}" في Supabase Storage وجعله Public.`,
            'error'
          );
        }, 300);
      };
      reader.onerror = () => {
        setIsUploading(false);
        setUploadProgress(0);
        showToast('حدث خطأ أثناء قراءة الملف، يرجى المحاولة مرة أخرى', 'error');
      };
      reader.readAsDataURL(file);
    } catch (err: any) {
      clearInterval(progressTimer);
      setIsUploading(false);
      setUploadProgress(0);
      showToast('حدث خطأ أثناء الرفع، يرجى المحاولة مرة أخرى', 'error');
    }
  };

  const handleCreateContent = (e: React.FormEvent) => {
    e.preventDefault();
    const finalSubject = newCustomSubject.trim() || contentSubject;

    if (!finalSubject) {
      showToast('يرجى تحديد أو كتابة اسم المادة!', 'error');
      return;
    }
    if (!contentTitle.trim()) {
      showToast('يرجى كتابة عنوان المحتوى!', 'error');
      return;
    }

    if (contentType === 'file' && !uploadedFile) {
      showToast('يرجى اختيار ملف لرفعه أو اختيار نوع رابط آخر!', 'error');
      return;
    }
    if (contentType === 'youtube' && !youtubeUrl.trim()) {
      showToast('يرجى إدخال رابط فيديو يوتيوب!', 'error');
      return;
    }
    if (contentType === 'link' && !externalUrl.trim()) {
      showToast('يرجى إدخال الرابط الخارجي!', 'error');
      return;
    }

    StorageService.addContentItem({
      yearId: targetYear,
      departmentId: targetDepartment,
      semesterId: targetSemester,
      categoryId: targetCategory,
      subject: finalSubject,
      title: contentTitle.trim(),
      description: contentDescription.trim(),
      contentType,
      youtubeUrl: contentType === 'youtube' ? youtubeUrl.trim() : undefined,
      fileName: contentType === 'file' ? uploadedFile?.name : undefined,
      fileSize: contentType === 'file' ? uploadedFile?.size : undefined,
      fileType: contentType === 'file' ? uploadedFile?.type : undefined,
      fileData: contentType === 'file' ? uploadedFile?.data : undefined,
      externalUrl: contentType === 'link' ? externalUrl.trim() : undefined,
      externalUrlTitle: contentType === 'link' ? externalUrlTitle.trim() : undefined,
      dueDate: dueDate ? dueDate : undefined,
      deadlineNote: deadlineNote.trim() ? deadlineNote.trim() : undefined,
      uploaderName: currentUser.name,
      uploaderEmail: currentUser.email,
      uploaderRole: currentUser.role
    });

    refreshAllState();
    showToast('تم نشر المحتوى بنجاح في المنصة!');

    // Reset Form
    setContentTitle('');
    setContentDescription('');
    setUploadedFile(null);
    setYoutubeUrl('');
    setExternalUrl('');
    setExternalUrlTitle('');
    setNewCustomSubject('');
    setDueDate('');
    setDeadlineNote('');
    setActiveTab('content');
  };

  // =========================================================================
  // 2. SUBJECTS MANAGEMENT (إضافة مواد، تعديل أسماء، حذف)
  // =========================================================================
  const [subjectFilterYear, setSubjectFilterYear] = useState<AcademicYearId>('year-1');
  const [newSubjectName, setNewSubjectName] = useState('');
  const [editingSubject, setEditingSubject] = useState<SubjectItem | null>(null);
  const [editingSubjectName, setEditingSubjectName] = useState('');

  const currentYearSubjects = useMemo(() => {
    return subjectsList.filter(s => s.yearId === subjectFilterYear);
  }, [subjectsList, subjectFilterYear]);

  const handleAddSubject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubjectName.trim()) return;

    const res = StorageService.addSubject(subjectFilterYear, newSubjectName.trim());
    if (res.success) {
      showToast(`تمت إضافة مادة "${newSubjectName.trim()}" بنجاح!`);
      setNewSubjectName('');
      refreshAllState();
    } else {
      showToast(res.error || 'تعذر إضافة المادة', 'error');
    }
  };

  const handleSaveEditSubject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSubject || !editingSubjectName.trim()) return;

    const res = StorageService.updateSubject(editingSubject.id, editingSubjectName.trim());
    if (res.success) {
      showToast(`تم تحديث اسم المادة إلى "${editingSubjectName.trim()}" وتحديث كافة المحتويات التابعة لها!`);
      setEditingSubject(null);
      refreshAllState();
    } else {
      showToast(res.error || 'تعذر تعديل اسم المادة', 'error');
    }
  };

  const handleDeleteSubject = (subj: SubjectItem) => {
    setItemToDelete({ id: subj.id, title: subj.name, type: 'subject' });
  };

  // =========================================================================
  // 3. CATEGORIES MANAGEMENT (تغيير الأقسام: إضافة، تعديل الاسم، حذف)
  // =========================================================================
  const [newCatTitle, setNewCatTitle] = useState('');
  const [newCatSingular, setNewCatSingular] = useState('');
  const [newCatDesc, setNewCatDesc] = useState('');
  const [editingCategory, setEditingCategory] = useState<CategoryDefinition | null>(null);
  const [editCatTitle, setEditCatTitle] = useState('');
  const [editCatSingular, setEditCatSingular] = useState('');
  const [editCatDesc, setEditCatDesc] = useState('');

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatTitle.trim()) {
      showToast('يرجى إدخال اسم القسم!', 'error');
      return;
    }

    const res = StorageService.addCategory({
      title: newCatTitle.trim(),
      singular: newCatSingular.trim() || newCatTitle.trim(),
      description: newCatDesc.trim() || 'قسم أكاديمي مخصص للمقررات'
    });

    if (res.success) {
      showToast(`تمت إضافة قسم "${newCatTitle.trim()}" بنجاح!`);
      setNewCatTitle('');
      setNewCatSingular('');
      setNewCatDesc('');
      refreshAllState();
    } else {
      showToast(res.error || 'تعذر إضافة القسم', 'error');
    }
  };

  const handleSaveEditCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCategory || !editCatTitle.trim()) return;

    const res = StorageService.updateCategory(editingCategory.id, {
      title: editCatTitle.trim(),
      singular: editCatSingular.trim() || editCatTitle.trim(),
      description: editCatDesc.trim()
    });

    if (res.success) {
      showToast(`تم تحديث القسم بنجاح!`);
      setEditingCategory(null);
      refreshAllState();
    } else {
      showToast(res.error || 'تعذر تعديل القسم', 'error');
    }
  };

  const handleDeleteCategory = (cat: CategoryDefinition) => {
    setItemToDelete({ id: cat.id, title: cat.title, type: 'category' });
  };

  // =========================================================================
  // 4. SUPERVISORS & PERMISSIONS MANAGEMENT (تعديل الصلاحيات وسنة كام)
  // =========================================================================
  const [newSupName, setNewSupName] = useState('');
  const [newSupEmail, setNewSupEmail] = useState('');
  const [newSupPassword, setNewSupPassword] = useState('');
  const [newSupPhone, setNewSupPhone] = useState('');
  const [newSupYears, setNewSupYears] = useState<AcademicYearId[]>(['year-1', 'year-2', 'year-3', 'year-4']);
  const [newSupPerms, setNewSupPerms] = useState<SupervisorPermissions>({
    canUpload: true,
    canEdit: true,
    canDelete: false,
    canManageSubjects: false
  });
  const [revealedPasswords, setRevealedPasswords] = useState<Record<string, boolean>>({});

  // Editing Supervisor Modal state
  const [editingSupervisor, setEditingSupervisor] = useState<UserAccount | null>(null);
  const [editSupName, setEditSupName] = useState('');
  const [editSupEmail, setEditSupEmail] = useState('');
  const [editSupPassword, setEditSupPassword] = useState('');
  const [editSupYears, setEditSupYears] = useState<AcademicYearId[]>([]);
  const [editSupPerms, setEditSupPerms] = useState<SupervisorPermissions>({
    canUpload: true,
    canEdit: false,
    canDelete: false,
    canManageSubjects: false
  });

  const togglePasswordVisibility = (id: string) => {
    setRevealedPasswords(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const handleAddSupervisor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSupName.trim() || !newSupEmail.trim() || !newSupPassword.trim()) {
      showToast('يرجى ملء كافة حقول بيانات المشرف!', 'error');
      return;
    }

    const res = StorageService.addSupervisor({
      name: newSupName,
      email: newSupEmail,
      password: newSupPassword,
      assignedYears: newSupYears,
      permissions: newSupPerms,
      phone: newSupPhone
    });

    if (res.success) {
      showToast(`تمت إضافة المشرف "${newSupName}" بنجاح!`);
      setNewSupName('');
      setNewSupEmail('');
      setNewSupPassword('');
      setNewSupPhone('');
      refreshAllState();
    } else {
      showToast(res.error || 'فشلت إضافة المشرف', 'error');
    }
  };

  const handleOpenEditSupervisor = (sup: UserAccount) => {
    setEditingSupervisor(sup);
    setEditSupName(sup.name);
    setEditSupEmail(sup.email);
    setEditSupPassword(sup.password);
    setEditSupYears(sup.assignedYears || []);
    setEditSupPerms(sup.permissions || {
      canUpload: true,
      canEdit: true,
      canDelete: false,
      canManageSubjects: false
    });
  };

  const handleSaveSupervisorChanges = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSupervisor) return;

    const res = StorageService.updateSupervisor(editingSupervisor.id, {
      name: editSupName.trim(),
      email: editSupEmail.trim(),
      password: editSupPassword.trim(),
      assignedYears: editSupYears,
      permissions: editSupPerms
    });

    if (res.success) {
      showToast(`تم تحديث بيانات وصلاحيات المشرف "${editSupName}" بنجاح!`);
      setEditingSupervisor(null);
      refreshAllState();
    } else {
      showToast(res.error || 'تعذر تحديث المشرف', 'error');
    }
  };

  const handleDeleteSupervisor = (id: string, name: string) => {
    setItemToDelete({ id, title: name, type: 'supervisor' });
  };

  // =========================================================================
  // 5. ADMIN PROFILE SETTINGS
  // =========================================================================
  const [adminName, setAdminName] = useState(currentUser.name);
  const [adminEmail, setAdminEmail] = useState(currentUser.email);
  const [adminNewPassword, setAdminNewPassword] = useState('');
  const [adminConfirmPassword, setAdminConfirmPassword] = useState('');
  const [showAdminPassword, setShowAdminPassword] = useState(false);

  const handleUpdateAdminProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminNewPassword && adminNewPassword !== adminConfirmPassword) {
      showToast('كلمة المرور الجديدة غير متطابقة!', 'error');
      return;
    }

    const res = StorageService.updateAdminProfile(
      adminEmail,
      adminNewPassword || undefined,
      adminName
    );

    if (res.success) {
      showToast('تم تحديث بيانات الحساب وكلمة المرور بنجاح!');
      setAdminNewPassword('');
      setAdminConfirmPassword('');
      refreshAllState();
    } else {
      showToast(res.error || 'تعذر تحديث البيانات', 'error');
    }
  };

  // =========================================================================
  // 6. CONTENT FILTERING & DELETION
  // =========================================================================
  const [filterYear, setFilterYear] = useState<string>('all');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterSearch, setFilterSearch] = useState<string>('');

  const filteredContent = useMemo(() => {
    return contentList.filter(item => {
      const matchYear = filterYear === 'all' || item.yearId === filterYear;
      const matchCategory = filterCategory === 'all' || item.categoryId === filterCategory;
      const matchSearch = !filterSearch.trim() || 
        item.title.toLowerCase().includes(filterSearch.toLowerCase()) ||
        item.subject.toLowerCase().includes(filterSearch.toLowerCase());
      
      const canManageItem = isAdmin || currentUser.assignedYears.includes(item.yearId);
      return matchYear && matchCategory && matchSearch && canManageItem;
    });
  }, [contentList, filterYear, filterCategory, filterSearch, isAdmin, currentUser]);

  // Filtered Activity Logs
  const filteredActivities = useMemo(() => {
    return activityLogs.filter(item => {
      if (activityActionFilter === 'upload' && item.action !== 'upload_content') return false;
      if (activityActionFilter === 'delete' && item.action !== 'delete_content' && item.action !== 'delete_subject' && item.action !== 'delete_category' && item.action !== 'delete_supervisor') return false;
      if (activityActionFilter === 'edit' && item.action !== 'edit_content' && item.action !== 'edit_subject') return false;
      if (activityActionFilter === 'system' && item.action !== 'maintenance_mode' && item.action !== 'backup_export' && item.action !== 'backup_restore' && item.action !== 'clean_slate_reset') return false;

      if (activitySearchQuery.trim()) {
        const q = activitySearchQuery.toLowerCase();
        const matchTitle = (item.targetTitle || '').toLowerCase().includes(q);
        const matchUser = (item.userName || '').toLowerCase().includes(q) || (item.userEmail || '').toLowerCase().includes(q);
        const matchDetails = (item.details || '').toLowerCase().includes(q);
        return matchTitle || matchUser || matchDetails;
      }

      return true;
    });
  }, [activityLogs, activityActionFilter, activitySearchQuery]);

  const getActionInfo = (action: string) => {
    switch (action) {
      case 'upload_content':
        return {
          label: 'رفع محتوى جديد',
          icon: Upload,
          badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-200',
          dotColor: 'bg-emerald-500'
        };
      case 'edit_content':
        return {
          label: 'تعديل محتوى',
          icon: Edit3,
          badgeClass: 'bg-blue-100 text-blue-800 border-blue-200',
          dotColor: 'bg-blue-500'
        };
      case 'delete_content':
        return {
          label: 'حذف محتوى',
          icon: Trash2,
          badgeClass: 'bg-red-100 text-red-800 border-red-200',
          dotColor: 'bg-red-500'
        };
      case 'add_subject':
        return {
          label: 'إضافة مادة جديدة',
          icon: BookOpen,
          badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200',
          dotColor: 'bg-indigo-500'
        };
      case 'edit_subject':
        return {
          label: 'تعديل مادة',
          icon: Edit3,
          badgeClass: 'bg-indigo-100 text-indigo-800 border-indigo-200',
          dotColor: 'bg-indigo-500'
        };
      case 'delete_subject':
        return {
          label: 'حذف مادة دراسية',
          icon: Trash2,
          badgeClass: 'bg-rose-100 text-rose-800 border-rose-200',
          dotColor: 'bg-rose-500'
        };
      case 'maintenance_mode':
        return {
          label: 'وضع الصيانة',
          icon: Wrench,
          badgeClass: 'bg-amber-100 text-amber-800 border-amber-200',
          dotColor: 'bg-amber-500'
        };
      case 'clean_slate_reset':
        return {
          label: 'تفريغ المنصة',
          icon: AlertTriangle,
          badgeClass: 'bg-red-100 text-red-900 border-red-300',
          dotColor: 'bg-red-600'
        };
      case 'backup_export':
        return {
          label: 'تصدير نسخة احتياطية',
          icon: FileDown,
          badgeClass: 'bg-purple-100 text-purple-800 border-purple-200',
          dotColor: 'bg-purple-500'
        };
      case 'backup_restore':
        return {
          label: 'استعادة نسخة احتياطية',
          icon: FileUp,
          badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-200',
          dotColor: 'bg-emerald-500'
        };
      default:
        return {
          label: 'إجراء نظام',
          icon: History,
          badgeClass: 'bg-slate-100 text-slate-800 border-slate-200',
          dotColor: 'bg-slate-500'
        };
    }
  };

  const formatArabicDateTime = (isoString: string): string => {
    try {
      const d = new Date(isoString);
      const dateStr = d.toLocaleDateString('ar-EG', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
      const timeStr = d.toLocaleTimeString('ar-EG', {
        hour: '2-digit',
        minute: '2-digit'
      });
      return `${dateStr} - ${timeStr}`;
    } catch {
      return isoString;
    }
  };

  const handleDeleteContent = (id: string, title: string) => {
    setItemToDelete({ id, title, type: 'content' });
  };

  const handleConfirmDelete = () => {
    if (!itemToDelete) return;

    if (itemToDelete.type === 'content') {
      const res = StorageService.deleteContentItem(itemToDelete.id);
      if (res.success) {
        showToast(`تم حذف المحتوى "${itemToDelete.title}" بنجاح!`);
        refreshAllState();
      }
    } else if (itemToDelete.type === 'subject') {
      const res = StorageService.deleteSubject(itemToDelete.id);
      if (res.success) {
        showToast(`تم حذف مادة "${itemToDelete.title}" بنجاح!`);
        refreshAllState();
      }
    } else if (itemToDelete.type === 'category') {
      const res = StorageService.deleteCategory(itemToDelete.id);
      if (res.success) {
        showToast(`تم حذف قسم "${itemToDelete.title}" بنجاح!`);
        refreshAllState();
      } else {
        showToast(res.error || 'تعذر حذف القسم', 'error');
      }
    } else if (itemToDelete.type === 'supervisor') {
      const res = StorageService.deleteSupervisor(itemToDelete.id);
      if (res.success) {
        showToast(`تم حذف المشرف "${itemToDelete.title}" بنجاح!`);
        refreshAllState();
      }
    }

    setItemToDelete(null);
  };

  // Permissions of current logged-in user
  const canUploadPerm = isAdmin || currentUser.permissions?.canUpload !== false;
  const canManageSubjectsPerm = isAdmin || currentUser.permissions?.canManageSubjects === true;

  return (
    <div className="min-h-screen bg-slate-100 pb-20 text-right">
      
      {/* ===================================================================== */}
      {/* TOP HEADER: 2 EXPLICIT BUTTONS (الإدارة كلها + رفع المحتوى)            */}
      {/* ===================================================================== */}
      <div className="bg-slate-900 text-white border-b border-slate-800 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-bold shadow-md shadow-blue-500/20 shrink-0">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-xl font-black text-white">لوحة تحكم المنصة</h1>
                  <span className="px-2.5 py-0.5 rounded text-[11px] font-bold bg-blue-500/20 text-blue-300 border border-blue-400/30">
                    {isAdmin ? 'المدير العام (Admin)' : 'مشرف معتمد'}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  الحساب الحالي: <strong className="text-white">{currentUser.name}</strong> ({currentUser.email})
                </p>
              </div>
            </div>

            {/* THE TWO EXPLICIT REQUIRED BUTTONS: الإدارة كلها + رفع المحتوى */}
            <div className="flex flex-wrap items-center gap-2.5">
              
              {/* BUTTON 1: الإدارة كلها */}
              <button
                onClick={() => setActiveTab('overview')}
                className={`inline-flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer whitespace-nowrap ${
                  activeTab === 'overview'
                    ? 'bg-blue-600 text-white ring-2 ring-blue-400/30'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                }`}
              >
                <LayoutGrid className="w-4 h-4 text-blue-300" />
                <span>🏛️ الإدارة كلها والتحكم الشامل</span>
              </button>

              {/* BUTTON 2: رفع المحتوى */}
              {canUploadPerm && (
                <button
                  onClick={() => setActiveTab('add-content')}
                  className={`inline-flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer whitespace-nowrap ${
                    activeTab === 'add-content'
                      ? 'bg-emerald-600 text-white ring-2 ring-emerald-400/30'
                      : 'bg-blue-600 hover:bg-blue-500 text-white'
                  }`}
                >
                  <Upload className="w-4 h-4" />
                  <span>📤 رفع محتوى جديد</span>
                </button>
              )}

              {/* BUTTON 3: الإحصائيات التفاعلية (Recharts) */}
              <button
                onClick={() => setActiveTab('analytics')}
                className={`inline-flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer whitespace-nowrap ${
                  activeTab === 'analytics'
                    ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white ring-2 ring-indigo-400/30'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                }`}
              >
                <TrendingUp className="w-4 h-4 text-amber-300" />
                <span>📈 الإحصائيات التفاعلية</span>
              </button>

              {/* Back to site */}
              <button
                onClick={onBackToSite}
                className="inline-flex items-center gap-1.5 px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold rounded-xl transition-colors cursor-pointer whitespace-nowrap"
              >
                <ArrowRight className="w-4 h-4" />
                <span>العودة للموقع</span>
              </button>

            </div>

          </div>
        </div>
      </div>

      {/* Toast Notification */}
      {toastMessage && (
        <div className={`fixed top-20 left-1/2 -translate-x-1/2 z-50 px-6 py-3 rounded-xl shadow-2xl text-xs font-bold flex items-center gap-2 border animate-in fade-in slide-in-from-top-4 ${
          toastMessage.type === 'success'
            ? 'bg-emerald-600 text-white border-emerald-500'
            : 'bg-red-600 text-white border-red-500'
        }`}>
          {toastMessage.type === 'success' ? <Check className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Navigation Tabs Bar */}
        <div className="bg-white rounded-2xl border border-slate-200 p-2 mb-8 shadow-sm">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            
            <button
              onClick={() => setActiveTab('overview')}
              className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'overview' ? 'bg-slate-900 text-white shadow' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <LayoutGrid className="w-4 h-4" />
              <span>نظرة عامة والتحكم</span>
            </button>

            {/* Tab: Analytics (الإحصائيات التفاعلية Recharts) */}
            <button
              onClick={() => setActiveTab('analytics')}
              className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'analytics'
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <TrendingUp className="w-4 h-4" />
              <span>الإحصائيات والتفاعل 📈</span>
            </button>

            {canUploadPerm && (
              <button
                onClick={() => setActiveTab('add-content')}
                className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                  activeTab === 'add-content' ? 'bg-blue-600 text-white shadow' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Upload className="w-4 h-4" />
                <span>رفع محتوى جديد</span>
              </button>
            )}

            <button
              onClick={() => setActiveTab('content')}
              className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'content' ? 'bg-slate-900 text-white shadow' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Layers className="w-4 h-4" />
              <span>المحتويات المنشورة ({filteredContent.length})</span>
            </button>

            {canManageSubjectsPerm && (
              <button
                onClick={() => setActiveTab('subjects')}
                className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                  activeTab === 'subjects' ? 'bg-indigo-600 text-white shadow' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <BookOpen className="w-4 h-4" />
                <span>إدارة وتعديل المواد ({subjectsList.length})</span>
              </button>
            )}

            {isAdmin && (
              <button
                onClick={() => setActiveTab('categories')}
                className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                  activeTab === 'categories' ? 'bg-purple-600 text-white shadow' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <FolderPlus className="w-4 h-4" />
                <span>إدارة الأقسام (التكليفات وغيرها) ({categoriesList.length})</span>
              </button>
            )}

            {isAdmin && (
              <button
                onClick={() => setActiveTab('supervisors')}
                className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                  activeTab === 'supervisors' ? 'bg-slate-900 text-white shadow' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Users className="w-4 h-4" />
                <span>المشرفين والصلاحيات ({supervisorsList.length})</span>
              </button>
            )}

            {isAdmin && (
              <button
                onClick={() => setActiveTab('profile')}
                className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                  activeTab === 'profile' ? 'bg-slate-900 text-white shadow' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Settings className="w-4 h-4" />
                <span>إعدادات حساب الأدمن</span>
              </button>
            )}

            {isAdmin && (
              <button
                onClick={() => setActiveTab('maintenance')}
                className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                  activeTab === 'maintenance'
                    ? 'bg-amber-600 text-white shadow'
                    : maintenanceConfig.isEnabled
                    ? 'bg-amber-100 text-amber-900 border border-amber-300 font-black animate-pulse'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Wrench className="w-4 h-4" />
                <span>وضع الصيانة {maintenanceConfig.isEnabled ? '(مفعّل ⚠️)' : ''}</span>
              </button>
            )}

            {/* Tab: Activity Log (سجل الأنشطة والعمليات) */}
            <button
              onClick={() => setActiveTab('activity')}
              className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'activity' ? 'bg-emerald-600 text-white shadow' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <History className="w-4 h-4" />
              <span>سجل الأنشطة ({activityLogs.length})</span>
            </button>

            {/* Tab: Backup & Restore (النسخ الاحتياطي والاستعادة) */}
            {isAdmin && (
              <button
                onClick={() => setActiveTab('backup')}
                className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                  activeTab === 'backup' ? 'bg-purple-600 text-white shadow' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <FileDown className="w-4 h-4" />
                <span>النسخ الاحتياطي والاستعادة</span>
              </button>
            )}

          </div>
        </div>

        {/* ================================================================= */}
        {/* TAB 0: OVERVIEW (الإدارة كلها والتحكم الشامل)                      */}
        {/* ================================================================= */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            
            {/* Quick Action Hub */}
            <div>
              <h2 className="text-xl font-black text-slate-900 mb-1">
                🏛️ بوابة الإدارة الشاملة والتحكم الكامل
              </h2>
              <p className="text-xs text-slate-600 mb-6">
                تحكم في كل أقسام ومواد ومشرفي ومحتويات منصة Online Courses من مكان واحد:
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                {/* Hub Card 1: Upload */}
                <button
                  onClick={() => setActiveTab('add-content')}
                  className="bg-white p-6 rounded-2xl border-2 border-slate-200 hover:border-blue-600 shadow-sm hover:shadow-lg transition-all text-right cursor-pointer flex flex-col justify-between group"
                >
                  <div>
                    <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                      <Upload className="w-6 h-6" />
                    </div>
                    <h3 className="text-base font-black text-slate-900 group-hover:text-blue-600 transition-colors mb-1">
                      📤 رفع محتوى جديد
                    </h3>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      رفع محاضرات أو سكاشن أو تكليفات أو ملخصات بصيغة PDF أو روابط يوتيوب وروابط خارجية.
                    </p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-100 text-xs font-bold text-blue-600 flex items-center gap-1">
                    <span>فتح صفحة الرفع ←</span>
                  </div>
                </button>

                {/* Hub Card 2: Subjects Management */}
                <button
                  onClick={() => setActiveTab('subjects')}
                  className="bg-white p-6 rounded-2xl border-2 border-slate-200 hover:border-indigo-600 shadow-sm hover:shadow-lg transition-all text-right cursor-pointer flex flex-col justify-between group"
                >
                  <div>
                    <div className="w-12 h-12 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                      <BookOpen className="w-6 h-6" />
                    </div>
                    <h3 className="text-base font-black text-slate-900 group-hover:text-indigo-600 transition-colors mb-1">
                      📚 إدارة المواد وتعديل الأسماء
                    </h3>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      إضافة مواد جديدة لكل فرقة، وتعديل أسماء المواد القائمة، وتحديث المحتوى المربوط بها تلقائياً.
                    </p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-100 text-xs font-bold text-indigo-600 flex items-center gap-1">
                    <span>إدارة المواد الدراسية ←</span>
                  </div>
                </button>

                {/* Hub Card 3: Categories Management */}
                {isAdmin && (
                  <button
                    onClick={() => setActiveTab('categories')}
                    className="bg-white p-6 rounded-2xl border-2 border-slate-200 hover:border-purple-600 shadow-sm hover:shadow-lg transition-all text-right cursor-pointer flex flex-col justify-between group"
                  >
                    <div>
                      <div className="w-12 h-12 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                        <FolderPlus className="w-6 h-6" />
                      </div>
                      <h3 className="text-base font-black text-slate-900 group-hover:text-purple-600 transition-colors mb-1">
                        🏷️ تعديل وإضافة الأقسام
                      </h3>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        تعديل أسماء الأقسام الحالية (مثل التكليفات)، مسحها، أو إضافة أقسام جديدة كلياً مثل شيتات أو امتحانات.
                      </p>
                    </div>
                    <div className="mt-4 pt-3 border-t border-slate-100 text-xs font-bold text-purple-600 flex items-center gap-1">
                      <span>التحكم في الأقسام ←</span>
                    </div>
                  </button>
                )}

                {/* Hub Card 4: Supervisors */}
                {isAdmin && (
                  <button
                    onClick={() => setActiveTab('supervisors')}
                    className="bg-white p-6 rounded-2xl border-2 border-slate-200 hover:border-slate-800 shadow-sm hover:shadow-lg transition-all text-right cursor-pointer flex flex-col justify-between group"
                  >
                    <div>
                      <div className="w-12 h-12 rounded-xl bg-slate-100 text-slate-800 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                        <Users className="w-6 h-6" />
                      </div>
                      <h3 className="text-base font-black text-slate-900 group-hover:text-slate-800 transition-colors mb-1">
                        👥 صلاحيات المشرفين وسنة كام
                      </h3>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        تحديد السنة المسموح للمشرف بالرفع لها، وتفعيل أو حظر صلاحية تعديل وحذف وإضافة المواد لكل مشرف.
                      </p>
                    </div>
                    <div className="mt-4 pt-3 border-t border-slate-100 text-xs font-bold text-slate-800 flex items-center gap-1">
                      <span>تعديل صلاحيات المشرفين ←</span>
                    </div>
                  </button>
                )}

                {/* Hub Card 5: Content Table */}
                <button
                  onClick={() => setActiveTab('content')}
                  className="bg-white p-6 rounded-2xl border-2 border-slate-200 hover:border-blue-600 shadow-sm hover:shadow-lg transition-all text-right cursor-pointer flex flex-col justify-between group"
                >
                  <div>
                    <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                      <Layers className="w-6 h-6" />
                    </div>
                    <h3 className="text-base font-black text-slate-900 group-hover:text-blue-600 transition-colors mb-1">
                      📁 المحتويات المنشورة ({contentList.length})
                    </h3>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      عرض جدول كامل بجميع المواد المرفوعة مع أزرار المعاينة، التعديل الكامل، والحذف الفوري.
                    </p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-100 text-xs font-bold text-blue-600 flex items-center gap-1">
                    <span>فتح جدول المحتويات ←</span>
                  </div>
                </button>

                {/* Hub Card 6: Profile */}
                {isAdmin && (
                  <button
                    onClick={() => setActiveTab('profile')}
                    className="bg-white p-6 rounded-2xl border-2 border-slate-200 hover:border-slate-800 shadow-sm hover:shadow-lg transition-all text-right cursor-pointer flex flex-col justify-between group"
                  >
                    <div>
                      <div className="w-12 h-12 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                        <Lock className="w-6 h-6" />
                      </div>
                      <h3 className="text-base font-black text-slate-900 group-hover:text-slate-800 transition-colors mb-1">
                        ⚙️ سرية حساب الأدمن
                      </h3>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        تغيير البريد الإلكتروني وكلمة المرور الخاصة بالمدير العام بكل خصوصية وحماية.
                      </p>
                    </div>
                    <div className="mt-4 pt-3 border-t border-slate-100 text-xs font-bold text-slate-800 flex items-center gap-1">
                      <span>إعدادات الأمان ←</span>
                    </div>
                  </button>
                )}

                {/* Hub Card: Analytics & Interactive Charts (Recharts) */}
                <button
                  onClick={() => setActiveTab('analytics')}
                  className="bg-gradient-to-br from-blue-50/70 to-indigo-50/70 p-6 rounded-2xl border-2 border-blue-200 hover:border-indigo-600 shadow-sm hover:shadow-lg transition-all text-right cursor-pointer flex flex-col justify-between group"
                >
                  <div>
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center mb-4 group-hover:scale-105 transition-transform shadow-md shadow-blue-500/20">
                      <TrendingUp className="w-6 h-6" />
                    </div>
                    <div className="flex items-center gap-1.5 mb-1">
                      <h3 className="text-base font-black text-slate-900 group-hover:text-indigo-600 transition-colors">
                        📈 الإحصائيات التفاعلية
                      </h3>
                      <span className="text-[10px] font-bold px-2 py-0.5 bg-blue-100 text-blue-800 rounded-full">Recharts</span>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      عرض المخططات البيانية التفاعلية لأكثر المواد مشاهدة أو تحميلاً، ونسب التفاعل ومعدل إقبال الطلاب.
                    </p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-blue-100 text-xs font-bold text-indigo-600 flex items-center gap-1">
                    <span>فتح لوحة الإحصائيات (Recharts) ←</span>
                  </div>
                </button>

              </div>
            </div>

            {/* Quick Stats Grid */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
              <h3 className="text-sm font-bold text-slate-900 mb-4">
                📊 إحصائيات عامة للمنصة
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div className="p-4 bg-slate-50 rounded-xl">
                  <span className="text-2xl font-black text-blue-600 font-mono tabular-nums block">{contentList.length}</span>
                  <span className="text-xs text-slate-600">إجمالي المحتويات</span>
                </div>
                <div className="p-4 bg-slate-50 rounded-xl">
                  <span className="text-2xl font-black text-indigo-600 font-mono tabular-nums block">{subjectsList.length}</span>
                  <span className="text-xs text-slate-600">المواد الدراسية</span>
                </div>
                <div className="p-4 bg-slate-50 rounded-xl">
                  <span className="text-2xl font-black text-purple-600 font-mono tabular-nums block">{categoriesList.length}</span>
                  <span className="text-xs text-slate-600">الأقسام المفعلة</span>
                </div>
                <div className="p-4 bg-slate-50 rounded-xl">
                  <span className="text-2xl font-black text-slate-800 font-mono tabular-nums block">{supervisorsList.length}</span>
                  <span className="text-xs text-slate-600">المشرفين المعتمدين</span>
                </div>
              </div>
            </div>

            {/* Storage Quota & Capacity Monitor (سعة التخزين وسحابة Supabase) */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
              
              {/* Supabase Cloud Storage Banner */}
              <div className="bg-gradient-to-br from-emerald-50 via-teal-50 to-blue-50 border-2 border-emerald-300 rounded-2xl p-5 shadow-xs">
                <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-md shadow-emerald-500/20">
                      <Cloud className="w-6 h-6" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-sm font-black text-slate-900">سحابة Supabase Cloud Storage (مفعلة)</h3>
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          <span>متصل بالسحابة 🟢</span>
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 mt-0.5 font-mono">
                        المشروع: qqgynwvqazslfurtajsr.supabase.co | المجلد: course-files
                      </p>
                    </div>
                  </div>

                  <div className="text-left">
                    <span className="text-xs font-mono font-black px-3 py-1.5 bg-emerald-600 text-white rounded-xl shadow-xs inline-block">
                      {supabaseStats ? `${supabaseStats.usedMb} MB / 1,000 MB` : '1,000 MB سعة سحابية مجانية'}
                    </span>
                  </div>
                </div>

                {/* Cloud Progress Bar */}
                <div className="w-full h-3 bg-white/80 rounded-full overflow-hidden p-0.5 border border-emerald-200 shadow-inner mb-3">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-500 to-teal-600 rounded-full transition-all duration-500 shadow"
                    style={{ width: `${supabaseStats ? Math.max(1, supabaseStats.percentUsed) : 1}%` }}
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="bg-white/80 p-3 rounded-xl border border-emerald-200/70">
                    <span className="text-slate-600 block text-[11px]">السعة السحابية الإجمالية:</span>
                    <strong className="text-emerald-700 font-mono text-sm">1,000 ميجابايت (1 GB)</strong>
                  </div>
                  <div className="bg-white/80 p-3 rounded-xl border border-emerald-200/70">
                    <span className="text-slate-600 block text-[11px]">الملفات المرفوعة سحابياً:</span>
                    <strong className="text-slate-900 font-mono text-sm">{supabaseStats?.totalFiles || 0} ملفات</strong>
                  </div>
                  <div className="bg-white/80 p-3 rounded-xl border border-emerald-200/70">
                    <span className="text-slate-600 block text-[11px]">المساحة السحابية المتبقية:</span>
                    <strong className="text-emerald-700 font-mono text-sm">{supabaseStats ? `${supabaseStats.remainingMb} MB` : '1,000 MB'}</strong>
                  </div>
                </div>
              </div>

              {/* Local Browser & External Options Breakdown */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                
                {/* Local Storage fallback */}
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="flex items-center gap-2 mb-2 font-bold text-slate-800">
                    <HardDrive className="w-4 h-4 text-slate-600" />
                    <span>الذاكرة المحلية السريعة (LocalStorage)</span>
                  </div>
                  <p className="text-[11px] text-slate-600 mb-2">
                    مساحة احتياطية على جهازك: {storageStats.usedMb} MB / {storageStats.totalMb} MB
                  </p>
                  <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-600 rounded-full" style={{ width: `${storageStats.percentUsed}%` }} />
                  </div>
                </div>

                {/* Unlimited External option */}
                <div className="p-4 bg-purple-50/70 rounded-xl border border-purple-200">
                  <div className="flex items-center gap-2 mb-1.5 font-bold text-purple-900">
                    <Sparkles className="w-4 h-4 text-purple-600" />
                    <span>الرفع غير المحدود (Unlimited Storage)</span>
                  </div>
                  <p className="text-[11px] text-purple-800 leading-relaxed">
                    لرفع مجلدات ضخمة (10GB أو 50GB)، استخدم خيار <strong>"رابط خارجي"</strong> من Google Drive أو تيليجرام أو YouTube مجاناً وبدون أي استهلاك لأي سعة!
                  </p>
                </div>

              </div>

            </div>

            {/* Clean Slate Reset Hub (تفريغ المنصة والبدء من الصفر) */}
            {isAdmin && (
              <div className="bg-gradient-to-r from-red-50 to-orange-50 border border-red-200 rounded-2xl p-6 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2 text-red-700 font-bold text-sm mb-1">
                      <AlertTriangle className="w-5 h-5 text-red-600" />
                      <span>تفريغ المنصة والبدء من الصفر (Clean Slate)</span>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed max-w-2xl">
                      إذا كنت تريد الدخول والموقع فارغ تماماً بدون أي مواد دراسية قديمة أو محتويات سابقة، يمكنك تفريغ كافة المواد والمحتويات بنقرة واحدة وإضافة موادك الجديدة بنفسك.
                    </p>
                  </div>
                  <button
                    onClick={() => setIsResetConfirmOpen(true)}
                    className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer whitespace-nowrap self-start sm:self-center flex items-center gap-1.5"
                  >
                    <span>تفريغ جميع المواد والمحتوى الآن 🧹</span>
                  </button>
                </div>
              </div>
            )}

          </div>
        )}

        {/* ================================================================= */}
        {/* TAB: ANALYTICS (الإحصائيات التفاعلية ورصد المشاهدات والتحميلات)   */}
        {/* ================================================================= */}
        {activeTab === 'analytics' && (
          <AnalyticsDashboard
            contentList={contentList}
            subjectsList={subjectsList}
            categoriesList={categoriesList}
            onOpenContent={onOpenContent}
            onNavigateToUpload={() => setActiveTab('add-content')}
          />
        )}

        {/* ================================================================= */}
        {/* TAB 1: ADD CONTENT FORM (UPLOAD CONTENT)                          */}
        {/* ================================================================= */}
        {activeTab === 'add-content' && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8">
            
            <div className="max-w-3xl mb-8">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-700 text-xs font-bold rounded-lg mb-2">
                <Upload className="w-3.5 h-3.5" />
                <span>رفع وإضافة محتوى دراسي</span>
              </div>
              <h2 className="text-xl font-black text-slate-900">
                إضافة محتوى أكاديمي جديد
              </h2>
              <p className="text-xs text-slate-600 mt-1">
                ارفع ملف PDF يشتغل ويتم تحميله، أو ضع لينك فيديو يوتيوب يشتغل في الموقع ويحولهم لليوتيوب، أو ضع رابط خارجي.
              </p>
            </div>

            <form onSubmit={handleCreateContent} className="space-y-6">
              
              {/* Year, Department, Semester, and Category */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                
                {/* Year Select */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-2">
                    الفرقة الدراسية المستهدفة *
                  </label>
                  <select
                    value={targetYear}
                    onChange={(e) => setTargetYear(e.target.value as AcademicYearId)}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {ACADEMIC_YEARS.map(y => {
                      const isAllowed = isAdmin || currentUser.assignedYears.includes(y.id);
                      return (
                        <option key={y.id} value={y.id} disabled={!isAllowed}>
                          {y.title} {!isAllowed ? '(غير مصرح)' : ''}
                        </option>
                      );
                    })}
                  </select>
                </div>

                {/* Department Select */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-2">
                    القسم / التخصص الأكاديمي *
                  </label>
                  <select
                    value={targetDepartment}
                    onChange={(e) => setTargetDepartment(e.target.value as DepartmentId)}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="cs">قسم علوم حاسب</option>
                    <option value="ai">قسم ذكاء اصطناعي</option>
                    <option value="cyber">قسم أمن سيبراني</option>
                    <option value="all">عام لجميع الأقسام</option>
                  </select>
                </div>

                {/* Semester Select */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-2">
                    الفصل الدراسي (الترم) *
                  </label>
                  <select
                    value={targetSemester}
                    onChange={(e) => setTargetSemester(e.target.value as SemesterId)}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="sem-1">الترم الأول</option>
                    <option value="sem-2">الترم الثاني</option>
                    <option value="all">كلا الترمين</option>
                  </select>
                </div>

                {/* Dynamic Category Select */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-2">
                    نوع المحتوى (القسم) *
                  </label>
                  <select
                    value={targetCategory}
                    onChange={(e) => setTargetCategory(e.target.value)}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {categoriesList.map(c => (
                      <option key={c.id} value={c.id}>
                        {c.title} ({c.singular})
                      </option>
                    ))}
                  </select>
                </div>

              </div>

              {/* Subject Selection */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-2">
                    اختر من المواد المسجلة للفرقة
                  </label>
                  <select
                    value={contentSubject}
                    onChange={(e) => {
                      setContentSubject(e.target.value);
                      if (e.target.value) setNewCustomSubject('');
                    }}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">-- اختر مادة من القائمة --</option>
                    {subjectsList
                      .filter(s => s.yearId === targetYear && (targetDepartment === 'all' || !s.departmentId || s.departmentId === 'all' || s.departmentId === targetDepartment))
                      .map(sub => (
                        <option key={sub.id} value={sub.name}>
                          {sub.name} {sub.departmentId && sub.departmentId !== 'all' ? `(${sub.departmentId.toUpperCase()})` : ''}
                        </option>
                      ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-2">
                    أو اكتب اسم مادة جديدة (تضاف تلقائياً)
                  </label>
                  <input
                    type="text"
                    value={newCustomSubject}
                    onChange={(e) => {
                      setNewCustomSubject(e.target.value);
                      if (e.target.value) setContentSubject('');
                    }}
                    placeholder="مثال: هندسة النظم، إحصاء تطبيقي..."
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              {/* Title & Description */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-2">
                  عنوان المحتوى *
                </label>
                <input
                  type="text"
                  required
                  value={contentTitle}
                  onChange={(e) => setContentTitle(e.target.value)}
                  placeholder="مثال: المحاضرة 2: المصفوفات وحل المعادلات الخطية"
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-2">
                  الوصف أو الملاحظات
                </label>
                <textarea
                  rows={3}
                  value={contentDescription}
                  onChange={(e) => setContentDescription(e.target.value)}
                  placeholder="اكتب نبذة عن المحتوى أو تعليمات هامة للطلاب..."
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Deadline & Reminder Note for ANY content item */}
              <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/40 p-4 rounded-xl">
                <div className="flex items-center gap-2 mb-2 text-xs font-bold text-amber-900 dark:text-amber-300">
                  <Clock className="w-4 h-4 text-amber-600" />
                  <span>الموعد النهائي وتنبيه الفرقة (Deadline) - اختياري لجميع المحتويات</span>
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      تاريخ الموعد النهائي
                    </label>
                    <input
                      type="date"
                      value={dueDate}
                      onChange={(e) => setDueDate(e.target.value)}
                      className="w-full p-2.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      ملاحظة أو تنبيه الموعد (يظهر لطلاب الفرقة)
                    </label>
                    <input
                      type="text"
                      value={deadlineNote}
                      onChange={(e) => setDeadlineNote(e.target.value)}
                      placeholder="مثال: تسليم الشيت أو التكليف في المعمل قبل نهاية اليوم"
                      className="w-full p-2.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white"
                    />
                  </div>
                </div>
              </div>

              {/* Content Attachment Method */}
              <div className="border border-slate-200 rounded-2xl p-5 bg-slate-50">
                <label className="block text-xs font-bold text-slate-800 mb-3">
                  طريقة إرفاق المحتوى *
                </label>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-5">
                  <button
                    type="button"
                    onClick={() => setContentType('file')}
                    className={`p-3.5 rounded-xl border text-right transition-all cursor-pointer ${
                      contentType === 'file'
                        ? 'bg-white border-blue-600 shadow-md ring-2 ring-blue-500/20'
                        : 'bg-white/60 border-slate-200 hover:bg-white'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <FileText className={`w-4 h-4 ${contentType === 'file' ? 'text-blue-600' : 'text-slate-400'}`} />
                      <span className="text-xs font-bold text-slate-900">رفع ملف (PDF / مستند)</span>
                    </div>
                    <span className="text-[11px] text-slate-500 block">يتم رفعه ويشتغل ويتم تحميله فوراً</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setContentType('youtube')}
                    className={`p-3.5 rounded-xl border text-right transition-all cursor-pointer ${
                      contentType === 'youtube'
                        ? 'bg-white border-red-600 shadow-md ring-2 ring-red-500/20'
                        : 'bg-white/60 border-slate-200 hover:bg-white'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <Video className={`w-4 h-4 ${contentType === 'youtube' ? 'text-red-600' : 'text-slate-400'}`} />
                      <span className="text-xs font-bold text-slate-900">رابط فيديو YouTube</span>
                    </div>
                    <span className="text-[11px] text-slate-500 block">مشغل داخل الموقع مع تحويل للفيديو</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setContentType('link')}
                    className={`p-3.5 rounded-xl border text-right transition-all cursor-pointer ${
                      contentType === 'link'
                        ? 'bg-white border-purple-600 shadow-md ring-2 ring-purple-500/20'
                        : 'bg-white/60 border-slate-200 hover:bg-white'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <ExternalLink className={`w-4 h-4 ${contentType === 'link' ? 'text-purple-600' : 'text-slate-400'}`} />
                      <span className="text-xs font-bold text-slate-900">رابط خارجي (Drive / تيليجرام)</span>
                    </div>
                    <span className="text-[11px] text-slate-500 block">رابط سحابي مباشر</span>
                  </button>
                </div>

                {/* Option 1: File Uploader */}
                {contentType === 'file' && (
                  <div className="space-y-4">
                    
                    {/* Storage Capacity Bar & Quota Explainer */}
                    <div className="bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-300 rounded-xl p-4 text-xs space-y-2.5">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2 font-bold text-emerald-950">
                          <Cloud className="w-4 h-4 text-emerald-600" />
                          <span>الرفع السحابي مفعل عبر Supabase Storage</span>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                            🟢 متصل (1,000 MB)
                          </span>
                        </div>
                        <span className="font-mono text-emerald-800 font-bold text-[11px]">
                          {supabaseStats ? `${supabaseStats.usedMb} MB / 1,000 MB (المتبقي: ${supabaseStats.remainingMb} MB)` : 'سعة سحابية: 1,000 MB'}
                        </span>
                      </div>

                      <div className="w-full h-2 bg-emerald-200/80 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-emerald-500 to-teal-600 rounded-full transition-all duration-300"
                          style={{ width: `${supabaseStats ? Math.max(1, supabaseStats.percentUsed) : 1}%` }}
                        />
                      </div>

                      <div className="text-[11px] text-emerald-900 leading-relaxed bg-white/70 p-2 rounded-lg border border-emerald-200/60">
                        ☁️ <strong>تم ربط مشروعك بنجاح:</strong> سيتم رفع ملفاتك مباشرة إلى سحابة Supabase ومجلد <code>course-files</code> لتحصل على روابط دائمة وسريعة لكافة الطلاب على كل الأجهزة دون استهلاك ذاكرة المتصفح!
                      </div>
                    </div>

                    {/* File Dropzone */}
                    <div className="border-2 border-dashed border-emerald-300 hover:border-emerald-500 rounded-xl p-6 text-center transition-colors bg-white group cursor-pointer">
                      <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto mb-2 group-hover:scale-105 transition-transform">
                        <Cloud className="w-6 h-6" />
                      </div>
                      <label className="cursor-pointer block">
                        <span className="text-xs font-bold text-emerald-700 hover:underline">
                          اضغط هنا لاختيار ملف PDF أو مستند لرفعه إلى سحابة Supabase (1000MB)
                        </span>
                        <input
                          type="file"
                          accept=".pdf,.doc,.docx,.ppt,.pptx,.zip,.txt,image/*"
                          onChange={handleFileChange}
                          className="hidden"
                        />
                      </label>
                      <p className="text-[11px] text-slate-500 mt-1">
                        يدعم ملفات الـ PDF والمذكرات والعروض التقديمية حتى 50 ميجابايت للملف الواحد
                      </p>
                    </div>

                    {/* Visual Progress Bar while Uploading */}
                    {isUploading && (
                      <div className="bg-emerald-50/90 border border-emerald-300 p-4 rounded-xl space-y-2.5 animate-in fade-in">
                        <div className="flex items-center justify-between text-xs">
                          <div className="flex items-center gap-2 font-bold text-emerald-950">
                            <RefreshCw className="w-4 h-4 text-emerald-600 animate-spin" />
                            <span>{uploadStatusText || 'جاري رفع الملف إلى سحابة Supabase...'}</span>
                          </div>
                          <span className="font-mono font-black text-emerald-700 text-sm">
                            {uploadProgress}%
                          </span>
                        </div>

                        {/* Progress Bar Track & Fill */}
                        <div className="w-full h-3 bg-emerald-100 rounded-full overflow-hidden p-0.5 shadow-inner">
                          <div
                            className="h-full bg-gradient-to-r from-emerald-500 via-teal-500 to-blue-600 rounded-full transition-all duration-150 ease-out shadow"
                            style={{ width: `${uploadProgress}%` }}
                          />
                        </div>

                        <div className="flex items-center justify-between text-[11px] text-emerald-800 font-medium">
                          <span>☁️ جاري الحفظ في مجلد course-files السحابي</span>
                          <span>السعة السحابية الإجمالية: 1,000 MB</span>
                        </div>
                      </div>
                    )}

                    {uploadedFile && !isUploading && (
                      <div className="bg-emerald-50 border border-emerald-300 p-4 rounded-xl flex items-center justify-between text-xs text-emerald-950 shadow-xs">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0">
                            {uploadedFile.isCloud ? <Cloud className="w-4 h-4" /> : <Check className="w-4 h-4" />}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-bold truncate max-w-sm">{uploadedFile.name}</span>
                              <span className="text-emerald-700 font-mono text-[11px]">({uploadedFile.size})</span>
                            </div>
                            <span className="text-[10px] text-emerald-700 block mt-0.5">
                              {uploadedFile.isCloud 
                                ? '☁️ تم رفعه وتوليد رابط CDN سحابي دائم على Supabase' 
                                : '💾 تم الحفظ محلياً'}
                            </span>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => setUploadedFile(null)}
                          className="px-2.5 py-1 text-red-600 hover:bg-red-50 rounded-lg text-xs font-bold cursor-pointer transition-colors"
                        >
                          إلغاء الملف
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* Option 2: YouTube */}
                {contentType === 'youtube' && (
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      رابط فيديو يوتيوب (URL)
                    </label>
                    <input
                      type="url"
                      value={youtubeUrl}
                      onChange={(e) => setYoutubeUrl(e.target.value)}
                      placeholder="https://www.youtube.com/watch?v=... أو https://youtu.be/..."
                      dir="ltr"
                      className="w-full p-3 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 font-sans"
                    />
                  </div>
                )}

                {/* Option 3: External Link */}
                {contentType === 'link' && (
                  <div className="space-y-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        الرابط الخارجي (URL)
                      </label>
                      <input
                        type="url"
                        value={externalUrl}
                        onChange={(e) => setExternalUrl(e.target.value)}
                        placeholder="https://drive.google.com/... أو https://t.me/..."
                        dir="ltr"
                        className="w-full p-3 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 font-sans"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        عنوان أو تسمية الرابط
                      </label>
                      <input
                        type="text"
                        value={externalUrlTitle}
                        onChange={(e) => setExternalUrlTitle(e.target.value)}
                        placeholder="مثال: مجلد ملفات Google Drive للفرقة"
                        className="w-full p-3 bg-white border border-slate-200 rounded-xl text-xs text-slate-900"
                      />
                    </div>
                  </div>
                )}

              </div>

              {/* Submit */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setActiveTab('content')}
                  className="px-5 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold rounded-xl transition-colors cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer flex items-center gap-2"
                >
                  <Upload className="w-4 h-4" />
                  <span>نشر المحتوى في المنصة الآن</span>
                </button>
              </div>

            </form>
          </div>
        )}

        {/* ================================================================= */}
        {/* TAB 2: SUBJECTS MANAGEMENT (إضافة مواد، تعديل أسماء، وحذف)         */}
        {/* ================================================================= */}
        {activeTab === 'subjects' && (
          <div className="space-y-8">
            
            {/* Add Subject Card */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
              <div className="flex items-center gap-2 mb-2">
                <BookOpen className="w-5 h-5 text-indigo-600" />
                <h3 className="text-base font-black text-slate-900">
                  إضافة مادة دراسية جديدة
                </h3>
              </div>
              <p className="text-xs text-slate-600 mb-6">
                حدد الفرقة الدراسية واكتب اسم المادة ليتم حفظها وتوفيرها للطلاب والمشرفين.
              </p>

              <form onSubmit={handleAddSubject} className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    الفرقة الدراسية
                  </label>
                  <select
                    value={subjectFilterYear}
                    onChange={(e) => setSubjectFilterYear(e.target.value as AcademicYearId)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900"
                  >
                    {ACADEMIC_YEARS.map(y => (
                      <option key={y.id} value={y.id}>{y.title}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    اسم المادة الجديدة
                  </label>
                  <input
                    type="text"
                    required
                    value={newSubjectName}
                    onChange={(e) => setNewSubjectName(e.target.value)}
                    placeholder="مثال: ذكاء اصطناعي، شبكات، فيزياء حديثة..."
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div className="flex items-end">
                  <button
                    type="submit"
                    className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" />
                    <span>إضافة المادة للفرقة</span>
                  </button>
                </div>
              </form>
            </div>

            {/* Edit Subject Inline Modal */}
            {editingSubject && (
              <div className="bg-indigo-50 border-2 border-indigo-300 rounded-2xl p-6 shadow-md animate-in fade-in">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-sm font-bold text-indigo-900 flex items-center gap-2">
                    <Edit3 className="w-4 h-4" />
                    <span>تعديل اسم المادة: &quot;{editingSubject.name}&quot;</span>
                  </h4>
                  <button
                    type="button"
                    onClick={() => setEditingSubject(null)}
                    className="text-xs text-indigo-700 hover:underline"
                  >
                    إلغاء التعديل
                  </button>
                </div>
                <form onSubmit={handleSaveEditSubject} className="flex gap-3">
                  <input
                    type="text"
                    required
                    value={editingSubjectName}
                    onChange={(e) => setEditingSubjectName(e.target.value)}
                    className="flex-1 p-2.5 bg-white border border-indigo-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow cursor-pointer whitespace-nowrap"
                  >
                    حفظ الاسم الجديد وتحديث المحتوى المربوط
                  </button>
                </form>
              </div>
            )}

            {/* Subjects Table */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-800">
                    المواد الدراسية المسجلة في:
                  </span>
                  <select
                    value={subjectFilterYear}
                    onChange={(e) => setSubjectFilterYear(e.target.value as AcademicYearId)}
                    className="p-1.5 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-900"
                  >
                    {ACADEMIC_YEARS.map(y => (
                      <option key={y.id} value={y.id}>{y.title}</option>
                    ))}
                  </select>
                </div>
                <span className="text-xs text-slate-500">
                  عدد المواد: <strong className="text-slate-900 font-mono">{currentYearSubjects.length}</strong>
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-4">اسم المادة</th>
                      <th className="py-3 px-4">الفرقة</th>
                      <th className="py-3 px-4">المحتويات التابعة</th>
                      <th className="py-3 px-4 text-center">إجراءات (تعديل الاسم / حذف)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {currentYearSubjects.map(subj => {
                      const count = contentList.filter(i => i.yearId === subj.yearId && i.subject === subj.name).length;
                      return (
                        <tr key={subj.id} className="hover:bg-slate-50 transition-colors">
                          <td className="py-3.5 px-4 font-bold text-slate-900">
                            {subj.name}
                          </td>
                          <td className="py-3.5 px-4 text-slate-600">
                            {ACADEMIC_YEARS.find(y => y.id === subj.yearId)?.title}
                          </td>
                          <td className="py-3.5 px-4 font-mono text-slate-500">
                            {count} عنصر مضاف
                          </td>
                          <td className="py-3.5 px-4 text-center whitespace-nowrap">
                            <div className="flex items-center justify-center gap-2">
                              <button
                                onClick={() => {
                                  setEditingSubject(subj);
                                  setEditingSubjectName(subj.name);
                                }}
                                className="px-3 py-1 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                                <span>تعديل الاسم</span>
                              </button>
                              <button
                                onClick={() => handleDeleteSubject(subj)}
                                className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg cursor-pointer"
                                title="حذف المادة"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* ================================================================= */}
        {/* TAB 3: CATEGORIES MANAGEMENT (تغيير الأقسام: محاضرات، تكليفات...)    */}
        {/* ================================================================= */}
        {activeTab === 'categories' && isAdmin && (
          <div className="space-y-8">
            
            {/* Add Category Card */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
              <div className="flex items-center gap-2 mb-2">
                <FolderPlus className="w-5 h-5 text-purple-600" />
                <h3 className="text-base font-black text-slate-900">
                  إضافة قسم أكاديمي جديد
                </h3>
              </div>
              <p className="text-xs text-slate-600 mb-6">
                يمكنك إضافة أقسام جديدة تظهر داخل الفرق الدراسية (مثل: &quot;شيتات وتمارين&quot;، &quot;نماذج امتحانات&quot;، &quot;تسجيلات صوتية&quot;، &quot;مشاريع عملية&quot;).
              </p>

              <form onSubmit={handleAddCategory} className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    اسم القسم (جمع) *
                  </label>
                  <input
                    type="text"
                    required
                    value={newCatTitle}
                    onChange={(e) => setNewCatTitle(e.target.value)}
                    placeholder="مثال: شيتات وتمارين، امتحانات سابقة"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    اسم المفرد (مثل: شيت / امتحان)
                  </label>
                  <input
                    type="text"
                    value={newCatSingular}
                    onChange={(e) => setNewCatSingular(e.target.value)}
                    placeholder="مثال: شيت، امتحان، تكليف"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <div className="flex items-end">
                  <button
                    type="submit"
                    className="w-full py-2.5 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-xl shadow transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" />
                    <span>إضافة القسم الجديد</span>
                  </button>
                </div>
              </form>
            </div>

            {/* Edit Category Inline Modal */}
            {editingCategory && (
              <div className="bg-purple-50 border-2 border-purple-300 rounded-2xl p-6 shadow-md animate-in fade-in">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-sm font-bold text-purple-900 flex items-center gap-2">
                    <Edit3 className="w-4 h-4" />
                    <span>تعديل مسمى القسم: &quot;{editingCategory.title}&quot;</span>
                  </h4>
                  <button
                    type="button"
                    onClick={() => setEditingCategory(null)}
                    className="text-xs text-purple-700 hover:underline"
                  >
                    إلغاء
                  </button>
                </div>
                <form onSubmit={handleSaveEditCategory} className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs text-purple-900 mb-1">اسم القسم (الجمع)</label>
                    <input
                      type="text"
                      required
                      value={editCatTitle}
                      onChange={(e) => setEditCatTitle(e.target.value)}
                      className="w-full p-2 bg-white border border-purple-300 rounded-xl text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-purple-900 mb-1">اسم المفرد</label>
                    <input
                      type="text"
                      value={editCatSingular}
                      onChange={(e) => setEditCatSingular(e.target.value)}
                      className="w-full p-2 bg-white border border-purple-300 rounded-xl text-xs"
                    />
                  </div>
                  <div className="flex items-end">
                    <button
                      type="submit"
                      className="w-full py-2 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-xl cursor-pointer"
                    >
                      حفظ التعديلات
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* Categories Table */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800">
                  الأقسام المتاحة حالياً داخل الفرق ({categoriesList.length})
                </span>
                <span className="text-[11px] text-slate-500">
                  يمكنك تعديل اسم أي قسم أو مسحه أو إضافة أقسام بديلة
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-4">اسم القسم</th>
                      <th className="py-3 px-4">اسم المفرد</th>
                      <th className="py-3 px-4">الوصف</th>
                      <th className="py-3 px-4">عدد المواد المرفوعة به</th>
                      <th className="py-3 px-4 text-center">إجراءات (تعديل / مسح)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {categoriesList.map(cat => {
                      const count = contentList.filter(i => i.categoryId === cat.id).length;
                      return (
                        <tr key={cat.id} className="hover:bg-slate-50 transition-colors">
                          <td className="py-3.5 px-4 font-bold text-slate-900">
                            {cat.title}
                          </td>
                          <td className="py-3.5 px-4 text-slate-600">
                            {cat.singular}
                          </td>
                          <td className="py-3.5 px-4 text-slate-500 max-w-xs truncate">
                            {cat.description}
                          </td>
                          <td className="py-3.5 px-4 font-mono text-purple-600 font-bold">
                            {count} عنصر
                          </td>
                          <td className="py-3.5 px-4 text-center whitespace-nowrap">
                            <div className="flex items-center justify-center gap-2">
                              <button
                                onClick={() => {
                                  setEditingCategory(cat);
                                  setEditCatTitle(cat.title);
                                  setEditCatSingular(cat.singular);
                                  setEditCatDesc(cat.description);
                                }}
                                className="px-3 py-1 bg-purple-50 text-purple-700 hover:bg-purple-100 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                                <span>تعديل الاسم</span>
                              </button>
                              <button
                                onClick={() => handleDeleteCategory(cat)}
                                className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg cursor-pointer"
                                title="مسح القسم"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* ================================================================= */}
        {/* TAB 4: SUPERVISORS MANAGEMENT (صلاحيات كل مشرف وسنة كام)           */}
        {/* ================================================================= */}
        {activeTab === 'supervisors' && isAdmin && (
          <div className="space-y-8">
            
            {/* Add Supervisor Card */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
              <div className="flex items-center gap-2 mb-2">
                <UserPlus className="w-5 h-5 text-blue-600" />
                <h3 className="text-base font-black text-slate-900">
                  إضافة مشرف جديد وتحديد صلاحياته
                </h3>
              </div>
              <p className="text-xs text-slate-600 mb-6">
                أنشئ حساباً للمشرف وحدد الفرق المصرح له بها (سنة كام) والصلاحيات المسموح بها له.
              </p>

              <form onSubmit={handleAddSupervisor} className="space-y-5">
                
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">اسم المشرف *</label>
                    <input
                      type="text"
                      required
                      value={newSupName}
                      onChange={(e) => setNewSupName(e.target.value)}
                      placeholder="مثال: م. أحمد حسام"
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">البريد الإلكتروني للدخول *</label>
                    <input
                      type="email"
                      required
                      value={newSupEmail}
                      onChange={(e) => setNewSupEmail(e.target.value)}
                      placeholder="supervisor@example.com"
                      dir="ltr"
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-sans"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">كلمة المرور *</label>
                    <input
                      type="text"
                      required
                      value={newSupPassword}
                      onChange={(e) => setNewSupPassword(e.target.value)}
                      placeholder="اكتب كلمة مرور المشرف"
                      dir="ltr"
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">رقم الهاتف (اختياري)</label>
                    <input
                      type="text"
                      value={newSupPhone}
                      onChange={(e) => setNewSupPhone(e.target.value)}
                      placeholder="01012345678"
                      dir="ltr"
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-mono"
                    />
                  </div>
                </div>

                {/* Assigned Years (سنة كام) */}
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-2">
                    الفرق الدراسية المصرح له برفع المحتوى لها (سنة كام):
                  </label>
                  <div className="flex flex-wrap gap-3">
                    {ACADEMIC_YEARS.map(y => {
                      const isChecked = newSupYears.includes(y.id);
                      return (
                        <label key={y.id} className="flex items-center gap-2 cursor-pointer bg-slate-50 px-3 py-2 rounded-xl border border-slate-200 text-xs">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setNewSupYears([...newSupYears, y.id]);
                              } else {
                                setNewSupYears(newSupYears.filter(id => id !== y.id));
                              }
                            }}
                            className="rounded text-blue-600 focus:ring-blue-500"
                          />
                          <span className="font-bold text-slate-800">{y.title}</span>
                        </label>
                      );
                    })}
                  </div>
                </div>

                {/* Fine-grained Permissions (تعديل المحتوى، رفع محتوى...) */}
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                  <label className="block text-xs font-bold text-slate-800 mb-3">
                    صلاحيات هذا المشرف:
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={newSupPerms.canUpload}
                        onChange={(e) => setNewSupPerms({ ...newSupPerms, canUpload: e.target.checked })}
                        className="rounded text-blue-600"
                      />
                      <span className="font-bold text-slate-700">رفع محتوى جديد</span>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={newSupPerms.canEdit}
                        onChange={(e) => setNewSupPerms({ ...newSupPerms, canEdit: e.target.checked })}
                        className="rounded text-blue-600"
                      />
                      <span className="font-bold text-slate-700">تعديل المحتوى</span>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={newSupPerms.canDelete}
                        onChange={(e) => setNewSupPerms({ ...newSupPerms, canDelete: e.target.checked })}
                        className="rounded text-blue-600"
                      />
                      <span className="font-bold text-slate-700">حذف المحتوى</span>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={newSupPerms.canManageSubjects}
                        onChange={(e) => setNewSupPerms({ ...newSupPerms, canManageSubjects: e.target.checked })}
                        className="rounded text-blue-600"
                      />
                      <span className="font-bold text-slate-700">إدارة وتعديل المواد</span>
                    </label>
                  </div>
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow cursor-pointer flex items-center gap-1.5"
                  >
                    <UserPlus className="w-4 h-4" />
                    <span>إنشاء حساب المشرف</span>
                  </button>
                </div>

              </form>
            </div>

            {/* Edit Supervisor Permissions Modal */}
            {editingSupervisor && (
              <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4">
                <div 
                  className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-xl w-full p-6 animate-in fade-in"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                    <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                      <Edit3 className="w-5 h-5 text-blue-600" />
                      <span>تعديل صلاحيات المشرف: {editingSupervisor.name}</span>
                    </h3>
                    <button
                      onClick={() => setEditingSupervisor(null)}
                      className="text-slate-400 hover:text-slate-700 p-1"
                    >
                      ✕
                    </button>
                  </div>

                  <form onSubmit={handleSaveSupervisorChanges} className="space-y-4">
                    
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">اسم المشرف</label>
                      <input
                        type="text"
                        required
                        value={editSupName}
                        onChange={(e) => setEditSupName(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">كلمة المرور</label>
                      <input
                        type="text"
                        required
                        value={editSupPassword}
                        onChange={(e) => setEditSupPassword(e.target.value)}
                        dir="ltr"
                        className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-mono"
                      />
                    </div>

                    {/* Assigned Years (سنة كام) */}
                    <div>
                      <label className="block text-xs font-bold text-slate-800 mb-2">
                        الفرق المسموح له بإدارتها (سنة كام):
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        {ACADEMIC_YEARS.map(y => {
                          const isChecked = editSupYears.includes(y.id);
                          return (
                            <label key={y.id} className="flex items-center gap-2 cursor-pointer bg-slate-50 p-2 rounded-lg border text-xs">
                              <input
                                type="checkbox"
                                checked={isChecked}
                                onChange={(e) => {
                                  if (e.target.checked) {
                                    setEditSupYears([...editSupYears, y.id]);
                                  } else {
                                    setEditSupYears(editSupYears.filter(id => id !== y.id));
                                  }
                                }}
                                className="rounded text-blue-600"
                              />
                              <span className="font-bold text-slate-800">{y.title}</span>
                            </label>
                          );
                        })}
                      </div>
                    </div>

                    {/* Detailed Permissions */}
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                      <label className="block text-xs font-bold text-slate-800 mb-2">
                        صلاحيات العمليات:
                      </label>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={editSupPerms.canUpload}
                            onChange={(e) => setEditSupPerms({ ...editSupPerms, canUpload: e.target.checked })}
                            className="rounded text-blue-600"
                          />
                          <span className="font-bold text-slate-700">رفع محتوى جديد</span>
                        </label>

                        <label className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={editSupPerms.canEdit}
                            onChange={(e) => setEditSupPerms({ ...editSupPerms, canEdit: e.target.checked })}
                            className="rounded text-blue-600"
                          />
                          <span className="font-bold text-slate-700">تعديل المحتوى</span>
                        </label>

                        <label className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={editSupPerms.canDelete}
                            onChange={(e) => setEditSupPerms({ ...editSupPerms, canDelete: e.target.checked })}
                            className="rounded text-blue-600"
                          />
                          <span className="font-bold text-slate-700">حذف المحتوى</span>
                        </label>

                        <label className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={editSupPerms.canManageSubjects}
                            onChange={(e) => setEditSupPerms({ ...editSupPerms, canManageSubjects: e.target.checked })}
                            className="rounded text-blue-600"
                          />
                          <span className="font-bold text-slate-700">إدارة وتعديل المواد</span>
                        </label>
                      </div>
                    </div>

                    <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                      <button
                        type="button"
                        onClick={() => setEditingSupervisor(null)}
                        className="px-4 py-2 bg-slate-200 text-slate-700 rounded-xl text-xs font-bold"
                      >
                        إلغاء
                      </button>
                      <button
                        type="submit"
                        className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold"
                      >
                        حفظ التعديلات
                      </button>
                    </div>

                  </form>
                </div>
              </div>
            )}

            {/* Supervisors Table */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800">
                  قائمة المشرفين وصلاحياتهم ({supervisorsList.length})
                </span>
                <span className="text-[11px] text-slate-500">
                  يمكنك تعديل صلاحية الرفع والتعديل والحذف وسنة كام لأي مشرف
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-4">اسم المشرف</th>
                      <th className="py-3 px-4">البريد</th>
                      <th className="py-3 px-4">كلمة المرور</th>
                      <th className="py-3 px-4">السنوات المصرح بها</th>
                      <th className="py-3 px-4">الصلاحيات</th>
                      <th className="py-3 px-4 text-center">إجراءات</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {supervisorsList.map(sup => {
                      const isRevealed = !!revealedPasswords[sup.id];
                      return (
                        <tr key={sup.id} className="hover:bg-slate-50 transition-colors">
                          <td className="py-3.5 px-4 font-bold text-slate-900">
                            {sup.name}
                          </td>
                          <td className="py-3.5 px-4 font-sans text-slate-700" dir="ltr">
                            {sup.email}
                          </td>
                          <td className="py-3.5 px-4 whitespace-nowrap">
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-xs bg-slate-100 px-2 py-1 rounded border">
                                {isRevealed ? sup.password : '••••••••'}
                              </span>
                              <button
                                type="button"
                                onClick={() => togglePasswordVisibility(sup.id)}
                                className="text-slate-400 hover:text-slate-700 p-1 cursor-pointer"
                              >
                                {isRevealed ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                              </button>
                            </div>
                          </td>
                          <td className="py-3.5 px-4 text-slate-600">
                            {sup.assignedYears?.length === 4
                              ? 'جميع الفرق'
                              : sup.assignedYears?.map(yId => ACADEMIC_YEARS.find(a => a.id === yId)?.shortTitle).join('، ')}
                          </td>
                          <td className="py-3.5 px-4 whitespace-nowrap">
                            <div className="flex flex-wrap gap-1 text-[10px]">
                              {sup.permissions?.canUpload && <span className="bg-emerald-50 text-emerald-700 px-1.5 py-0.5 rounded">رفع</span>}
                              {sup.permissions?.canEdit && <span className="bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded">تعديل</span>}
                              {sup.permissions?.canDelete && <span className="bg-red-50 text-red-700 px-1.5 py-0.5 rounded">حذف</span>}
                              {sup.permissions?.canManageSubjects && <span className="bg-indigo-50 text-indigo-700 px-1.5 py-0.5 rounded">مواد</span>}
                            </div>
                          </td>
                          <td className="py-3.5 px-4 text-center whitespace-nowrap">
                            <div className="flex items-center justify-center gap-2">
                              <button
                                onClick={() => handleOpenEditSupervisor(sup)}
                                className="px-2.5 py-1 bg-blue-50 text-blue-700 hover:bg-blue-100 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer"
                              >
                                <Edit3 className="w-3 h-3" />
                                <span>تعديل الصلاحيات</span>
                              </button>
                              <button
                                onClick={() => handleDeleteSupervisor(sup.id, sup.name)}
                                className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg cursor-pointer"
                                title="حذف المشرف"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* ================================================================= */}
        {/* TAB 5: PUBLISHED CONTENT LIST (معاينة، تعديل، حذف)                 */}
        {/* ================================================================= */}
        {activeTab === 'content' && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            
            {/* Filter Bar */}
            <div className="p-5 border-b border-slate-200 bg-slate-50 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
              <div className="flex flex-wrap items-center gap-3">
                <select
                  value={filterYear}
                  onChange={(e) => setFilterYear(e.target.value)}
                  className="p-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 font-bold focus:outline-none"
                >
                  <option value="all">جميع الفرق الدراسية</option>
                  <option value="year-1">الفرقة الأولى</option>
                  <option value="year-2">الفرقة الثانية</option>
                  <option value="year-3">الفرقة الثالثة</option>
                  <option value="year-4">الفرقة الرابعة</option>
                </select>

                <select
                  value={filterCategory}
                  onChange={(e) => setFilterCategory(e.target.value)}
                  className="p-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 font-bold focus:outline-none"
                >
                  <option value="all">جميع الأقسام</option>
                  {categoriesList.map(c => (
                    <option key={c.id} value={c.id}>{c.title}</option>
                  ))}
                </select>
              </div>

              <div className="relative min-w-[240px]">
                <input
                  type="text"
                  value={filterSearch}
                  onChange={(e) => setFilterSearch(e.target.value)}
                  placeholder="بحث في المحتوى..."
                  className="w-full pl-3 pr-8 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none"
                />
                <Search className="w-4 h-4 text-slate-400 absolute right-2.5 top-2.5 pointer-events-none" />
              </div>
            </div>

            {/* Table */}
            {filteredContent.length === 0 ? (
              <div className="p-12 text-center text-slate-500 text-xs">
                لا توجد عناصر تطابق معايير البحث الحالية.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-4">العنوان</th>
                      <th className="py-3 px-4">الفرقة</th>
                      <th className="py-3 px-4">القسم</th>
                      <th className="py-3 px-4">المادة</th>
                      <th className="py-3 px-4">نوع المحتوى</th>
                      <th className="py-3 px-4">الناشر</th>
                      <th className="py-3 px-4 text-center">إجراءات</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredContent.map(item => {
                      const catName = categoriesList.find(c => c.id === item.categoryId)?.singular || item.categoryId;
                      return (
                        <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                          <td className="py-3.5 px-4 font-bold text-slate-900 max-w-xs truncate" title={item.title}>
                            {item.title}
                          </td>
                          <td className="py-3.5 px-4 text-slate-600 whitespace-nowrap">
                            {ACADEMIC_YEARS.find(y => y.id === item.yearId)?.shortTitle}
                          </td>
                          <td className="py-3.5 px-4 text-slate-600 whitespace-nowrap">
                            {catName}
                          </td>
                          <td className="py-3.5 px-4 text-blue-600 font-semibold whitespace-nowrap">
                            {item.subject}
                          </td>
                          <td className="py-3.5 px-4 whitespace-nowrap">
                            {item.contentType === 'youtube' && <span className="text-red-600 font-bold">فيديو يوتيوب</span>}
                            {item.contentType === 'file' && <span className="text-emerald-700 font-bold">ملف مرفوع</span>}
                            {item.contentType === 'link' && <span className="text-purple-600 font-bold">رابط خارجي</span>}
                          </td>
                          <td className="py-3.5 px-4 text-slate-600 max-w-[120px] truncate">
                            {item.uploaderName}
                          </td>
                          <td className="py-3.5 px-4 text-center whitespace-nowrap">
                            <div className="flex items-center justify-center gap-2">
                              <button
                                onClick={() => onOpenContent(item)}
                                className="p-1.5 text-slate-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                                title="معاينة"
                              >
                                <Eye className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => setEditingItem(item)}
                                className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                                title="تعديل هذا المحتوى"
                              >
                                <Edit3 className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleDeleteContent(item.id, item.title)}
                                className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                                title="حذف"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

          </div>
        )}

        {/* ================================================================= */}
        {/* TAB 6: ADMIN PROFILE SETTINGS                                     */}
        {/* ================================================================= */}
        {activeTab === 'profile' && isAdmin && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8 max-w-2xl">
            <div className="mb-6">
              <h2 className="text-xl font-black text-slate-900">
                إعدادات حساب المدير العام (Admin)
              </h2>
              <p className="text-xs text-slate-600 mt-1">
                تغيير البريد الإلكتروني وكلمة المرور الخاصة بك بكل سرية وأمان.
              </p>
            </div>

            <form onSubmit={handleUpdateAdminProfile} className="space-y-5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">اسم المدير</label>
                <input
                  type="text"
                  required
                  value={adminName}
                  onChange={(e) => setAdminName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">البريد الإلكتروني للادمن</label>
                <input
                  type="email"
                  required
                  value={adminEmail}
                  onChange={(e) => setAdminEmail(e.target.value)}
                  dir="ltr"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-sans"
                />
              </div>

              <div className="pt-4 border-t border-slate-100 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900">تغيير كلمة المرور</span>
                  <button
                    type="button"
                    onClick={() => setShowAdminPassword(!showAdminPassword)}
                    className="text-[11px] text-blue-600 flex items-center gap-1 cursor-pointer"
                  >
                    {showAdminPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    <span>{showAdminPassword ? 'إخفاء' : 'إظهار'}</span>
                  </button>
                </div>

                <div>
                  <label className="block text-xs text-slate-600 mb-1">كلمة المرور الجديدة</label>
                  <input
                    type={showAdminPassword ? 'text' : 'password'}
                    value={adminNewPassword}
                    onChange={(e) => setAdminNewPassword(e.target.value)}
                    placeholder="••••••••••••"
                    dir="ltr"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-mono"
                  />
                </div>

                {adminNewPassword && (
                  <div>
                    <label className="block text-xs text-slate-600 mb-1">تأكيد كلمة المرور</label>
                    <input
                      type={showAdminPassword ? 'text' : 'password'}
                      value={adminConfirmPassword}
                      onChange={(e) => setAdminConfirmPassword(e.target.value)}
                      placeholder="••••••••••••"
                      dir="ltr"
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-mono"
                    />
                  </div>
                )}
              </div>

              <div className="pt-4">
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow cursor-pointer flex items-center gap-2"
                >
                  <Check className="w-4 h-4" />
                  <span>حفظ التعديلات الجديدة</span>
                </button>
              </div>
            </form>
          </div>
        )}

        {/* ================================================================= */}
        {/* TAB 7: MAINTENANCE MODE (وضع الصيانة وإغلاق الموقع مؤقتاً)         */}
        {/* ================================================================= */}
        {activeTab === 'maintenance' && isAdmin && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8 max-w-3xl">
            <div className="flex items-center gap-3 mb-6 pb-4 border-b border-slate-100">
              <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center">
                <Wrench className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-xl font-black text-slate-900">
                  إدارة وضع الصيانة (Maintenance Mode)
                </h2>
                <p className="text-xs text-slate-600 mt-0.5">
                  حجب الموقع مؤقتاً عن الطلاب وعرض شاشة صيانة رسمية ريثما تنتهي من تعديل المواد أو رفع المحتوى.
                </p>
              </div>
            </div>

            <div className="space-y-6">
              {/* Toggle Box */}
              <div className={`p-5 rounded-2xl border transition-all ${
                maintenanceConfig.isEnabled 
                  ? 'bg-amber-50/80 border-amber-300' 
                  : 'bg-slate-50 border-slate-200'
              }`}>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">
                      حالة وضع الصيانة: {maintenanceConfig.isEnabled ? 'مُفعّل (الموقع محجوب ⚠️)' : 'معطّل (الموقع متاح للطلاب ✅)'}
                    </h3>
                    <p className="text-xs text-slate-600 mt-1">
                      {maintenanceConfig.isEnabled 
                        ? 'المنصة محجوبة حالياً عن الطلاب وتظهر لهم شاشة الصيانة، بينما يمكنك أنت كمدير التصفح والتعديل بحرية.' 
                        : 'المنصة مفتوحة ومتاحة لجميع الطلاب والمشرفين بشكل طبيعي.'}
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleSaveMaintenance(!maintenanceConfig.isEnabled)}
                    className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer shadow-md whitespace-nowrap flex items-center gap-2 self-start sm:self-center ${
                      maintenanceConfig.isEnabled
                        ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                        : 'bg-amber-600 hover:bg-amber-700 text-white'
                    }`}
                  >
                    <Power className="w-4 h-4" />
                    <span>{maintenanceConfig.isEnabled ? 'تعطيل الصيانة وفتح الموقع' : 'تفعيل الصيانة وقفل الموقع'}</span>
                  </button>
                </div>
              </div>

              {/* Maintenance Message Fields */}
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    عنوان أو رسالة شاشة الصيانة (الظاهرة للطلاب)
                  </label>
                  <input
                    type="text"
                    value={maintenanceMessage}
                    onChange={(e) => setMaintenanceMessage(e.target.value)}
                    placeholder="مثال: تجري حالياً صيانة دورية وتحديثات شاملة على مقررات الفصل الدراسي"
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    سبب الصيانة أو تعليمات إضافية
                  </label>
                  <textarea
                    rows={3}
                    value={maintenanceReason}
                    onChange={(e) => setMaintenanceReason(e.target.value)}
                    placeholder="مثال: نقوم برفع شيتات وتكليفات جديدة، سنعود للعمل بكامل الكفاءة خلال وقت قصير."
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    الوقت التقريبي لعودة المنصة (اختياري)
                  </label>
                  <input
                    type="text"
                    value={maintenanceEndTime}
                    onChange={(e) => setMaintenanceEndTime(e.target.value)}
                    placeholder="مثال: خلال ساعتين / في تمام الساعة 8:00 مساءً"
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => handleSaveMaintenance(maintenanceConfig.isEnabled)}
                    className="px-6 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl shadow cursor-pointer flex items-center gap-2"
                  >
                    <Check className="w-4 h-4" />
                    <span>تحديث نصوص ورسائل الصيانة</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ================================================================= */}
        {/* TAB 8: ACTIVITY LOG (سجل الأنشطة والعمليات)                        */}
        {/* ================================================================= */}
        {activeTab === 'activity' && (
          <div className="space-y-6">
            
            {/* Header with Title and Actions */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                  <History className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-xl font-black text-slate-900">
                    📋 سجل الأنشطة والعمليات (Activity Log)
                  </h2>
                  <p className="text-xs text-slate-600 mt-0.5">
                    متابعة دقيقة وفورية لمن قام برفع أو حذف أو تعديل أي مادة أو محتوى مع التاريخ والتوقيت بالثواني.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 self-start md:self-center">
                {isAdmin && activityLogs.length > 0 && (
                  <button
                    onClick={handleClearActivityLogs}
                    className="px-4 py-2 bg-red-50 hover:bg-red-100 text-red-700 text-xs font-bold rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>مسح السجل</span>
                  </button>
                )}
                <button
                  onClick={handleExportBackup}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>تصدير نسخة احتياطية</span>
                </button>
              </div>
            </div>

            {/* Filter & Search Bar */}
            <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
              {/* Category Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs font-bold">
                <button
                  onClick={() => setActivityActionFilter('all')}
                  className={`px-3.5 py-2 rounded-xl transition-all cursor-pointer whitespace-nowrap ${
                    activityActionFilter === 'all'
                      ? 'bg-slate-900 text-white shadow'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  الكل ({activityLogs.length})
                </button>

                <button
                  onClick={() => setActivityActionFilter('upload')}
                  className={`px-3.5 py-2 rounded-xl transition-all cursor-pointer whitespace-nowrap ${
                    activityActionFilter === 'upload'
                      ? 'bg-emerald-600 text-white shadow'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  📤 رفع محتوى ({activityLogs.filter(a => a.action === 'upload_content').length})
                </button>

                <button
                  onClick={() => setActivityActionFilter('delete')}
                  className={`px-3.5 py-2 rounded-xl transition-all cursor-pointer whitespace-nowrap ${
                    activityActionFilter === 'delete'
                      ? 'bg-red-600 text-white shadow'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  🗑️ عمليات الحذف ({activityLogs.filter(a => a.action.startsWith('delete_') || a.action === 'clean_slate_reset').length})
                </button>

                <button
                  onClick={() => setActivityActionFilter('edit')}
                  className={`px-3.5 py-2 rounded-xl transition-all cursor-pointer whitespace-nowrap ${
                    activityActionFilter === 'edit'
                      ? 'bg-blue-600 text-white shadow'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  ✏️ تعديلات ({activityLogs.filter(a => a.action.startsWith('edit_')).length})
                </button>

                <button
                  onClick={() => setActivityActionFilter('system')}
                  className={`px-3.5 py-2 rounded-xl transition-all cursor-pointer whitespace-nowrap ${
                    activityActionFilter === 'system'
                      ? 'bg-purple-600 text-white shadow'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  ⚙️ النظام والنسخ ({activityLogs.filter(a => a.action.startsWith('backup_') || a.action === 'maintenance_mode' || a.action === 'clean_slate_reset').length})
                </button>
              </div>

              {/* Search Box */}
              <div className="relative min-w-[260px]">
                <input
                  type="text"
                  value={activitySearchQuery}
                  onChange={(e) => setActivitySearchQuery(e.target.value)}
                  placeholder="بحث باسم المشرف، المادة، أو العنوان..."
                  className="w-full pl-3 pr-9 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5 pointer-events-none" />
              </div>
            </div>

            {/* Activities Timeline / Cards List */}
            {filteredActivities.length === 0 ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center shadow-sm">
                <div className="w-16 h-16 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-3">
                  <History className="w-8 h-8" />
                </div>
                <h3 className="text-sm font-bold text-slate-800 mb-1">
                  لا توجد أنشطة مسجلة تطابق البحث
                </h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  أي عملية رفع مواد أو حذف محتويات أو تعديلات من قِبل المدير العام أو المشرفين ستظهر هنا تلقائياً مع الاسم والتاريخ والتوقيت الدقيق.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredActivities.map((log) => {
                  const info = getActionInfo(log.action);
                  const Icon = info.icon;
                  const yearShort = log.yearId ? ACADEMIC_YEARS.find(y => y.id === log.yearId)?.shortTitle : undefined;
                  const deptShort = log.departmentId && log.departmentId !== 'all' ? DEPARTMENTS.find(d => d.id === log.departmentId)?.shortName : undefined;
                  const semShort = log.semesterId && log.semesterId !== 'all' ? SEMESTERS.find(s => s.id === log.semesterId)?.shortName : undefined;

                  return (
                    <div
                      key={log.id}
                      className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-xs hover:shadow-md transition-shadow"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-2.5 pb-2.5 border-b border-slate-100">
                        {/* Action Badge & Target Title */}
                        <div className="flex flex-wrap items-center gap-2">
                          <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-bold border ${info.badgeClass}`}>
                            <Icon className="w-3.5 h-3.5" />
                            <span>{info.label}</span>
                          </span>

                          <span className="text-sm font-black text-slate-900">
                            {log.targetTitle}
                          </span>

                          {log.targetType && (
                            <span className="text-[11px] px-2 py-0.5 bg-slate-100 text-slate-600 rounded-md">
                              {log.targetType}
                            </span>
                          )}
                        </div>

                        {/* Timestamp */}
                        <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 font-sans whitespace-nowrap self-start sm:self-auto">
                          <Clock className="w-3.5 h-3.5 text-slate-400" />
                          <span>{formatArabicDateTime(log.timestamp)}</span>
                        </div>
                      </div>

                      {/* User Info & Academic Context */}
                      <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
                        {/* Who did it */}
                        <div className="flex items-center gap-2 text-slate-700">
                          <span className="text-slate-500">القائم بالإجراء:</span>
                          <span className="font-bold text-slate-900">{log.userName}</span>
                          <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                            log.userRole === 'admin'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-indigo-100 text-indigo-800'
                          }`}>
                            {log.userRole === 'admin' ? 'المدير العام' : 'مشرف'}
                          </span>
                          {log.userEmail && (
                            <span className="text-[11px] text-slate-400 font-mono hidden md:inline">
                              ({log.userEmail})
                            </span>
                          )}
                        </div>

                        {/* Academic Context tags */}
                        {(yearShort || deptShort || semShort) && (
                          <div className="flex items-center gap-1 text-[11px]">
                            {yearShort && (
                              <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md font-medium">
                                {yearShort}
                              </span>
                            )}
                            {deptShort && (
                              <span className="bg-blue-50 text-blue-700 px-2 py-0.5 rounded-md font-medium">
                                {deptShort}
                              </span>
                            )}
                            {semShort && (
                              <span className="bg-amber-50 text-amber-700 px-2 py-0.5 rounded-md font-medium">
                                {semShort}
                              </span>
                            )}
                          </div>
                        )}
                      </div>

                      {/* Detailed Log Explanation */}
                      {log.details && (
                        <p className="mt-2.5 text-xs text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-100 leading-relaxed">
                          {log.details}
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

          </div>
        )}

        {/* ================================================================= */}
        {/* TAB 9: BACKUP & RESTORE (النسخ الاحتياطي واستعادة البيانات)        */}
        {/* ================================================================= */}
        {activeTab === 'backup' && isAdmin && (
          <div className="space-y-8 max-w-4xl">
            
            {/* Header Banner */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-12 h-12 rounded-2xl bg-purple-100 text-purple-700 flex items-center justify-center">
                  <FileDown className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-xl font-black text-slate-900">
                    💾 النسخ الاحتياطي واستعادة البيانات (Backup & Restore)
                  </h2>
                  <p className="text-xs text-slate-600 mt-0.5">
                    احمِ محتوى منصتك بالكامل من الضياع، صَدر نسخة احتياطية بصيغة JSON واستعدها في أي وقت بضغطة زر واحدة.
                  </p>
                </div>
              </div>
            </div>

            {/* Dual Panel: Export & Import */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* PANEL 1: EXPORT BACKUP */}
              <div className="bg-white rounded-2xl border-2 border-slate-200 hover:border-purple-600 transition-colors p-6 shadow-sm flex flex-col justify-between">
                <div>
                  <div className="w-12 h-12 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center mb-4">
                    <Download className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-black text-slate-900 mb-2">
                    1. تصدير نسخة احتياطية للمنصة (Export JSON)
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed mb-6">
                    قم بتنزيل ملف JSON يحتوي على كافة المواد والمحاضرات والسكاشن والتكليفات والملخصات المسجلة حالياً، واحتفظ به على جهازك كنسخة أمان.
                  </p>

                  {/* Summary of what will be exported */}
                  <div className="p-4 bg-slate-50 rounded-xl space-y-2 text-xs mb-6 border border-slate-100">
                    <span className="font-bold text-slate-800 block mb-1">محتويات النسخة التي سيتم تصديرها:</span>
                    <div className="flex items-center justify-between text-slate-600">
                      <span>إجمالي المحتويات الأكاديمية:</span>
                      <span className="font-mono font-bold text-blue-600">{contentList.length}</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-600">
                      <span>المواد الدراسية المسجلة:</span>
                      <span className="font-mono font-bold text-indigo-600">{subjectsList.length}</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-600">
                      <span>الأقسام المفعلة:</span>
                      <span className="font-mono font-bold text-purple-600">{categoriesList.length}</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-600">
                      <span>سجل الأنشطة والعمليات:</span>
                      <span className="font-mono font-bold text-emerald-600">{activityLogs.length} سجل</span>
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleExportBackup}
                  className="w-full py-3 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <FileDown className="w-4 h-4" />
                  <span>تنزيل ملف النسخة الاحتياطية الآن (Download JSON) 📥</span>
                </button>
              </div>

              {/* PANEL 2: IMPORT BACKUP */}
              <div className="bg-white rounded-2xl border-2 border-slate-200 hover:border-emerald-600 transition-colors p-6 shadow-sm flex flex-col justify-between">
                <div>
                  <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-4">
                    <FileUp className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-black text-slate-900 mb-2">
                    2. استيراد واستعادة نسخة احتياطية (Restore JSON)
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed mb-6">
                    إذا قمت بتغيير المتصفح أو فُقدت البيانات، ارفع ملف النسخة الاحتياطية (`.json`) لاستعادة كافة المواد والمحاضرات فوراً كما كانت.
                  </p>

                  <div className="p-4 bg-emerald-50/60 rounded-xl text-xs text-emerald-900 mb-6 border border-emerald-100 leading-relaxed">
                    🛡️ <strong>استعادة آمنة وموثوقة:</strong> بمجرد اختيار الملف، سيتم فحص محتواه وعرض معاينة تفصيلية قبل التطبيق لضمان سلامة بياناتك.
                  </div>
                </div>

                <div>
                  <label className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2">
                    <FileUp className="w-4 h-4" />
                    <span>اختر ملف النسخة الاحتياطية (.json) 📤</span>
                    <input
                      type="file"
                      accept=".json,application/json"
                      onChange={handleImportFileChange}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

            </div>

          </div>
        )}

      </div>

      {/* Edit Content Modal */}
      <EditContentModal
        item={editingItem}
        isOpen={!!editingItem}
        onClose={() => setEditingItem(null)}
        onSaveSuccess={() => {
          refreshAllState();
          showToast('تم حفظ التعديلات بنجاح!');
        }}
      />

      {/* In-App Delete Confirmation Modal (100% Reliable Deletion) */}
      <DeleteConfirmationModal
        isOpen={!!itemToDelete}
        itemTitle={itemToDelete?.title || ''}
        onConfirm={handleConfirmDelete}
        onCancel={() => setItemToDelete(null)}
      />

      {/* Clean Slate Confirmation Modal (تأكيد تفريغ المنصة) */}
      {isResetConfirmOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border border-red-200 text-center animate-in fade-in zoom-in-95">
            <div className="w-16 h-16 rounded-2xl bg-red-100 text-red-600 flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-8 h-8" />
            </div>
            
            <h3 className="text-lg font-black text-slate-900 mb-2">
              تأكيد تفريغ كافة المواد والمحتويات؟
            </h3>
            
            <p className="text-xs text-slate-600 leading-relaxed mb-6">
              سيتم مسح كافة المواد الدراسية والمحاضرات والتكليفات المسجلة، وستصبح المنصة فارغة تماماً لتقوم أنت بإضافة موادك الخاصة من الصفر.
            </p>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={handleResetPlatform}
                className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl shadow-md cursor-pointer transition-all flex items-center justify-center gap-2"
              >
                <span>نعم، فرّغ المنصة وابدأ من الصفر 🧹</span>
              </button>
              <button
                type="button"
                onClick={() => setIsResetConfirmOpen(false)}
                className="px-5 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer transition-colors"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Restore Backup Confirmation Modal (تأكيد استعادة النسخة الاحتياطية JSON) */}
      {isImportModalOpen && backupToImport && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl border border-emerald-200 text-right animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 mb-4 pb-3 border-b border-slate-100">
              <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                <FileUp className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-black text-slate-900">
                  تأكيد استعادة النسخة الاحتياطية
                </h3>
                <p className="text-xs text-slate-600">
                  تم فحص ملف JSON بنجاح وهو صالح للاستعادة الفورية.
                </p>
              </div>
            </div>

            {/* Backup Meta Breakdown */}
            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 mb-6 space-y-2.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-600">تاريخ إنشاء النسخة:</span>
                <span className="font-bold text-slate-900 font-sans">
                  {backupToImport.exportedAt ? formatArabicDateTime(backupToImport.exportedAt) : 'غير محدد'}
                </span>
              </div>

              {backupToImport.exportedBy && (
                <div className="flex items-center justify-between">
                  <span className="text-slate-600">القائم بالتصدير:</span>
                  <span className="font-bold text-slate-900">
                    {backupToImport.exportedBy.name} ({backupToImport.exportedBy.role === 'admin' ? 'المدير العام' : 'مشرف'})
                  </span>
                </div>
              )}

              <div className="pt-2 border-t border-slate-200 grid grid-cols-3 gap-2 text-center">
                <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                  <span className="text-[11px] text-slate-500 block">المحتويات</span>
                  <strong className="text-sm font-black text-blue-600 font-mono">
                    {Array.isArray(backupToImport.content) ? backupToImport.content.length : 0}
                  </strong>
                </div>
                <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                  <span className="text-[11px] text-slate-500 block">المواد الدراسية</span>
                  <strong className="text-sm font-black text-indigo-600 font-mono">
                    {Array.isArray(backupToImport.subjects) ? backupToImport.subjects.length : 0}
                  </strong>
                </div>
                <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                  <span className="text-[11px] text-slate-500 block">الأقسام</span>
                  <strong className="text-sm font-black text-purple-600 font-mono">
                    {Array.isArray(backupToImport.categories) ? backupToImport.categories.length : 0}
                  </strong>
                </div>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed mb-6 bg-emerald-50 p-3 rounded-xl border border-emerald-100">
              💡 <strong>ملاحظة:</strong> سيتم استيراد كافة المواد والمحتويات ودمجها مباشرة في المنصة وإلغاء أي حظر قديم عليها لتعود متاحة للطلاب على الفور.
            </p>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={handleConfirmImport}
                className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-md cursor-pointer transition-all flex items-center justify-center gap-2"
              >
                <Check className="w-4 h-4" />
                <span>تأكيد استعادة المحتوى الآن</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsImportModalOpen(false);
                  setBackupToImport(null);
                }}
                className="px-5 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer transition-colors"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
