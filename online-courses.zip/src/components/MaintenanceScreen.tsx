import React from 'react';
import { Wrench, ShieldAlert, Clock, LogIn, Sparkles, RefreshCw } from 'lucide-react';
import { MaintenanceConfig } from '../types';

interface MaintenanceScreenProps {
  config: MaintenanceConfig;
  onOpenLogin: () => void;
  onRefresh: () => void;
}

export const MaintenanceScreen: React.FC<MaintenanceScreenProps> = ({
  config,
  onOpenLogin,
  onRefresh
}) => {
  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col justify-between p-4 sm:p-8 text-right selection:bg-blue-500 selection:text-white" dir="rtl">
      
      {/* Top Navbar Header */}
      <header className="max-w-6xl mx-auto w-full flex items-center justify-between py-4 border-b border-slate-800/80">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-blue-500/20">
            <Wrench className="w-5 h-5 text-white animate-spin-slow" />
          </div>
          <div>
            <h1 className="text-base font-black text-white">Online Courses</h1>
            <p className="text-[11px] text-slate-400">منصة المحتوى الأكاديمي والمحاضرات</p>
          </div>
        </div>

        <button
          onClick={onOpenLogin}
          className="inline-flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-slate-200 hover:text-white text-xs font-bold rounded-xl border border-slate-800 transition-colors cursor-pointer"
        >
          <LogIn className="w-4 h-4 text-blue-400" />
          <span>دخول الإدارة والمشرفين</span>
        </button>
      </header>

      {/* Main Content Area */}
      <main className="max-w-2xl mx-auto w-full my-auto py-12 text-center">
        
        {/* Animated Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold mb-8">
          <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
          <span>وضع الصيانة والتحديث الدوري مفعل حالياً</span>
        </div>

        {/* Big Illustration / Icon */}
        <div className="relative w-28 h-28 mx-auto mb-8 flex items-center justify-center">
          <div className="absolute inset-0 bg-blue-600/20 rounded-full blur-2xl animate-pulse"></div>
          <div className="relative w-24 h-24 rounded-3xl bg-slate-900 border-2 border-slate-800 flex items-center justify-center shadow-2xl">
            <Wrench className="w-12 h-12 text-blue-400" />
          </div>
        </div>

        {/* Heading */}
        <h2 className="text-2xl sm:text-4xl font-black text-white tracking-tight leading-tight mb-4">
          الموقع قيد الصيانة والترقية الآن 🛠️
        </h2>

        {/* Custom Admin Message or Default */}
        <p className="text-base sm:text-lg text-slate-300 leading-relaxed mb-8 max-w-xl mx-auto">
          {config.message || 'نقوم حالياً بإجراء تحديثات وتحسينات تقنية لضمان أفضل تجربة تصفح وسرعة لمحتوى المحاضرات والتكليفات. سنعود للعمل بكامل طاقتنا في أقرب وقت!'}
        </p>

        {/* Return Time or Reason if provided */}
        {(config.reason || config.estimatedEndTime) && (
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 mb-8 max-w-lg mx-auto text-right">
            {config.reason && (
              <div className="text-xs text-slate-400 mb-2">
                <strong className="text-slate-300">السبب: </strong>
                {config.reason}
              </div>
            )}
            {config.estimatedEndTime && (
              <div className="flex items-center gap-2 text-xs font-bold text-blue-400">
                <Clock className="w-4 h-4" />
                <span>الموعد المتوقع للعودة: {config.estimatedEndTime}</span>
              </div>
            )}
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onRefresh}
            className="w-full sm:w-auto px-6 py-3.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-lg shadow-blue-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
            <span>إعادة فحص حالة الموقع</span>
          </button>

          <button
            onClick={onOpenLogin}
            className="w-full sm:w-auto px-6 py-3.5 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white text-xs font-bold rounded-xl border border-slate-800 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <ShieldAlert className="w-4 h-4 text-amber-400" />
            <span>لوحة تحكم المسؤول (تجاوز شاشة الصيانة)</span>
          </button>
        </div>

      </main>

      {/* Footer */}
      <footer className="max-w-6xl mx-auto w-full py-4 text-center text-xs text-slate-500 border-t border-slate-900">
        منصة Online Courses للمحاضرات الجامعية • نشكركم على صبركم وتفهمكم.
      </footer>

    </div>
  );
};
