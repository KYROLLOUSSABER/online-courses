import React, { useState, useEffect } from 'react';
import { ContentItem, UserAccount } from '../types';
import { 
  X, 
  ExternalLink, 
  Download, 
  Calendar, 
  User, 
  Clock, 
  FileText, 
  Play, 
  Share2,
  CheckCircle2,
  Sparkles,
  Bookmark,
  BookmarkCheck,
  AlertTriangle,
  Bot,
  HelpCircle,
  FileCheck,
  Maximize2,
  Trash2,
  Timer
} from 'lucide-react';
import { ACADEMIC_YEARS, CATEGORY_INFO } from '../data/mockData';
import { StorageService } from '../services/storage';
import { OfflineStorageService } from '../services/offlineStorage';
import { AIStudyAssistantModal } from './AIStudyAssistantModal';
import { PDFInteractiveViewer } from './PDFInteractiveViewer';
import { PomodoroTimer } from './PomodoroTimer';
import { DeleteConfirmationModal } from './DeleteConfirmationModal';

interface ContentViewModalProps {
  item: ContentItem | null;
  currentUser?: UserAccount | null;
  onClose: () => void;
  onDownload: (item: ContentItem) => void;
  onDelete?: (id: string, title: string) => void;
}

export const ContentViewModal: React.FC<ContentViewModalProps> = ({
  item,
  currentUser,
  onClose,
  onDownload,
  onDelete
}) => {
  if (!item) return null;

  const isAdmin = currentUser?.role === 'admin';
  const canDeleteThisItem = isAdmin || (
    currentUser?.permissions?.canDelete === true &&
    currentUser?.assignedYears?.includes(item.yearId)
  );
  const [isConfirmingDelete, setIsConfirmingDelete] = useState(false);
  const yearInfo = ACADEMIC_YEARS.find(y => y.id === item.yearId);
  const categoryInfo = CATEGORY_INFO[item.categoryId];

  // Offline status
  const [isSavedOffline, setIsSavedOffline] = useState(false);
  const [offlineToast, setOfflineToast] = useState<string | null>(null);

  // Standalone File Viewer Mode
  const [isStandaloneView, setIsStandaloneView] = useState(false);

  // Pomodoro Study Timer Tool
  const [showPomodoro, setShowPomodoro] = useState(false);

  // AI Modal
  const [isAIModalOpen, setIsAIModalOpen] = useState(false);
  const [initialAITab, setInitialAITab] = useState<'summary' | 'quiz' | 'ask' | 'external'>('summary');

  useEffect(() => {
    if (item) {
      setIsSavedOffline(OfflineStorageService.isItemSaved(item.id));
    }
  }, [item]);

  // Toggle offline save
  const handleToggleOffline = () => {
    const res = OfflineStorageService.toggleSave(item);
    setIsSavedOffline(res.isSaved);
    setOfflineToast(
      res.isSaved 
        ? 'تم حفظ المحتوى بنجاح! يمكنك فتحه ومراجعته في أي وقت بدون إنترنت 💾' 
        : 'تمت إزالة المحتوى من قائمة التشغيل بدون إنترنت'
    );
    setTimeout(() => setOfflineToast(null), 3500);
  };

  // Helper to trigger direct file download
  const handleDownloadFile = () => {
    onDownload(item);

    if (item.fileData) {
      const link = document.createElement('a');
      link.href = item.fileData;
      link.download = item.fileName || `${item.title}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } else if (item.externalUrl) {
      window.open(item.externalUrl, '_blank', 'noopener,noreferrer');
    }
  };

  const handleOpenExternal = () => {
    if (item.externalUrl) {
      window.open(item.externalUrl, '_blank', 'noopener,noreferrer');
    } else if (item.youtubeUrl) {
      window.open(item.youtubeUrl, '_blank', 'noopener,noreferrer');
    }
  };

  // Check deadline remaining days
  const getDeadlineStatus = () => {
    if (!item.dueDate) return null;
    const now = new Date();
    const due = new Date(item.dueDate);
    const diffHours = (due.getTime() - now.getTime()) / (1000 * 60 * 60);

    if (diffHours < 0) {
      return { text: 'انتهى موعد التسليم', isUrgent: true, color: 'text-red-600 bg-red-50 dark:bg-red-950/40 border-red-200' };
    }
    if (diffHours <= 24) {
      return { text: 'ينتهي اليوم! (أقل من 24 ساعة متبقية)', isUrgent: true, color: 'text-red-600 bg-red-50 dark:bg-red-950/40 border-red-200' };
    }
    const days = Math.ceil(diffHours / 24);
    if (days <= 3) {
      return { text: `متبقي ${days} أيام فقط على التسليم`, isUrgent: true, color: 'text-amber-700 bg-amber-50 dark:bg-amber-950/40 border-amber-200' };
    }
    return { text: `آخر موعد: ${due.toLocaleDateString('ar-EG')}`, isUrgent: false, color: 'text-blue-700 bg-blue-50 dark:bg-blue-950/40 border-blue-200' };
  };

  const deadlineStatus = getDeadlineStatus();

  // If in Standalone full-screen PDF view
  if (isStandaloneView) {
    return (
      <div className="fixed inset-0 z-50 bg-slate-950 text-white">
        <PDFInteractiveViewer
          item={item}
          isStandalone={true}
          isAdmin={isAdmin}
          onClose={() => setIsStandaloneView(false)}
        />
      </div>
    );
  }

  return (
    <>
      <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 text-right">
        <div 
          className="relative bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-4xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 my-6 text-slate-900 dark:text-slate-100"
          onClick={(e) => e.stopPropagation()}
        >
          
          {/* Modal Top Bar */}
          <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-blue-400">
                {yearInfo?.title}
              </span>
              <span className="text-slate-500">/</span>
              <span className="text-xs text-slate-300">
                {categoryInfo?.title || item.categoryId}
              </span>
              <span className="text-slate-500">/</span>
              <span className="text-xs text-slate-300 font-bold">
                {item.subject}
              </span>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              title="إغلاق"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Toast Notification */}
          {offlineToast && (
            <div className="px-6 py-2.5 bg-emerald-600 text-white text-xs font-bold flex items-center justify-between animate-in slide-in-from-top">
              <div className="flex items-center gap-2">
                <BookmarkCheck className="w-4 h-4" />
                <span>{offlineToast}</span>
              </div>
              <button onClick={() => setOfflineToast(null)} className="text-emerald-200 hover:text-white">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Modal Body */}
          <div className="p-6 max-h-[80vh] overflow-y-auto">
            
            {/* Deadline Notification Banner if set */}
            {deadlineStatus && (
              <div className={`p-4 rounded-2xl border mb-6 flex items-center justify-between gap-4 ${deadlineStatus.color}`}>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white/60 dark:bg-slate-800 flex items-center justify-center shrink-0">
                    <Clock className="w-5 h-5 text-current animate-pulse" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black uppercase tracking-wider">
                      تنبيه الموعد النهائي (Deadline):
                    </h4>
                    <p className="text-xs font-bold mt-0.5">
                      {deadlineStatus.text}
                    </p>
                    {item.deadlineNote && (
                      <p className="text-[11px] opacity-90 mt-0.5">
                        ملاحظة التسليم: {item.deadlineNote}
                      </p>
                    )}
                  </div>
                </div>
                <span className="text-[11px] font-bold px-2.5 py-1 bg-white/80 dark:bg-slate-800 rounded-lg shadow-xs">
                  {new Date(item.dueDate!).toLocaleDateString('ar-EG')}
                </span>
              </div>
            )}

            {/* Header Title */}
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-4">
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white leading-snug flex-1">
                {item.title}
              </h2>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-2 shrink-0">
                
                {/* Standalone Viewer Button (for files/PDFs) */}
                {item.contentType === 'file' && (
                  <button
                    onClick={() => setIsStandaloneView(true)}
                    className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer border border-slate-700"
                    title="عرض الملف لوحده بملء الشاشة مع القلم والأدوات"
                  >
                    <Maximize2 className="w-4 h-4 text-amber-300" />
                    <span>عرض الملف لوحده 📄</span>
                  </button>
                )}

                {/* Pomodoro Focus Timer Tool Button */}
                <button
                  onClick={() => setShowPomodoro(!showPomodoro)}
                  className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer border ${
                    showPomodoro
                      ? 'bg-amber-600 text-white border-amber-600'
                      : 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800 hover:bg-amber-100'
                  }`}
                  title="مؤقت المذاكرة والتركيز (Pomodoro) لمساعدتك على تنظيم الوقت أثناء تصفح المحاضرة"
                >
                  <Timer className="w-4 h-4 animate-pulse" />
                  <span>مؤقت المذاكرة 🍅</span>
                </button>

                <button
                  onClick={handleToggleOffline}
                  className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer shadow-xs ${
                    isSavedOffline
                      ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                      : 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700'
                  }`}
                  title={isSavedOffline ? 'المحتوى محفوظ بدون إنترنت' : 'حفظ للتشغيل بدون إنترنت'}
                >
                  {isSavedOffline ? (
                    <>
                      <BookmarkCheck className="w-4 h-4 text-emerald-200" />
                      <span>محفوظ أوفلاين ✓</span>
                    </>
                  ) : (
                    <>
                      <Bookmark className="w-4 h-4 text-slate-500" />
                      <span>تشغيل بدون إنترنت 💾</span>
                    </>
                  )}
                </button>

                <button
                  onClick={() => {
                    setInitialAITab('summary');
                    setIsAIModalOpen(true);
                  }}
                  className="flex items-center gap-1.5 px-3.5 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white text-xs font-bold rounded-xl shadow-sm transition-all cursor-pointer active:scale-95"
                  title="المساعد الذكي للمحاضرة"
                >
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>مساعد الذكاء الاصطناعي ✨</span>
                </button>

                {canDeleteThisItem && (
                  <button
                    onClick={() => setIsConfirmingDelete(true)}
                    className="flex items-center gap-1.5 px-3 py-2 bg-red-50 hover:bg-red-100 dark:bg-red-950/40 dark:hover:bg-red-900/50 text-red-600 dark:text-red-400 text-xs font-bold rounded-xl border border-red-200 dark:border-red-900/50 shadow-xs transition-colors cursor-pointer"
                    title="حذف هذا المحتوى نهائياً من المنصة"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>حذف المحتوى</span>
                  </button>
                )}
              </div>
            </div>

            {/* Embedded Pomodoro Focus Timer Tool */}
            {showPomodoro && (
              <div className="mb-6 animate-in fade-in slide-in-from-top-3">
                <PomodoroTimer onClose={() => setShowPomodoro(false)} />
              </div>
            )}

            {/* Metadata Row: PUBLISHER NAME IS SHOWN TO ADMIN ONLY! */}
            <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 dark:text-slate-400 mb-6 pb-4 border-b border-slate-100 dark:border-slate-800">
              
              {/* Only admin sees uploader name */}
              {isAdmin ? (
                <div className="flex items-center gap-1.5 bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 px-2 py-0.5 rounded-lg border border-blue-200 dark:border-blue-800 font-bold">
                  <User className="w-3.5 h-3.5" />
                  <span>الناشر (خاص بالمدير فقط): <strong>{item.uploaderName}</strong></span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 font-bold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>محتوى معتمد للمقرر الجامعي</span>
                </div>
              )}

              <span aria-hidden="true">·</span>
              <div className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>تاريخ النشر: {new Date(item.createdAt).toLocaleDateString('ar-EG')}</span>
              </div>
              <span aria-hidden="true">·</span>
              <div className="flex items-center gap-1.5">
                <FileCheck className="w-3.5 h-3.5 text-slate-400" />
                <span>المادة: <strong className="text-slate-800 dark:text-slate-200">{item.subject}</strong></span>
              </div>
            </div>

            {/* Description */}
            {item.description && (
              <div className="bg-slate-50 dark:bg-slate-800/50 rounded-2xl p-4 text-xs sm:text-sm text-slate-700 dark:text-slate-200 leading-relaxed mb-6 border border-slate-100 dark:border-slate-800">
                <span className="font-bold text-slate-900 dark:text-white block mb-1">وصف وتفاصيل المحتوى:</span>
                <p>{item.description}</p>
              </div>
            )}

            {/* PRIMARY MEDIA / FILE VIEWER */}
            
            {/* 1. YouTube Video Player */}
            {item.contentType === 'youtube' && (
              <div className="mb-6">
                <div className="relative aspect-video w-full rounded-2xl overflow-hidden bg-black shadow-lg border border-slate-800">
                  {item.youtubeVideoId ? (
                    <iframe
                      src={`https://www.youtube.com/embed/${item.youtubeVideoId}?rel=0&modestbranding=1`}
                      title={item.title}
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                      className="w-full h-full border-0"
                    />
                  ) : (
                    <div className="flex flex-col items-center justify-center h-full text-white p-6 text-center">
                      <Play className="w-12 h-12 text-red-500 mb-2" />
                      <p className="text-sm font-bold">رابط يوتيوب متاح للعرض المباشر</p>
                      {item.youtubeUrl && (
                        <p className="text-xs text-slate-400 mt-1 font-mono">{item.youtubeUrl}</p>
                      )}
                    </div>
                  )}
                </div>

                <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                  <span className="text-xs text-slate-500 dark:text-slate-400">
                    يمكنك المشاهدة مباشرة أعلاه أو فتح الفيديو في موقع وتطبيق YouTube الرسمي
                  </span>
                  {item.youtubeUrl && (
                    <button
                      onClick={() => window.open(item.youtubeUrl, '_blank', 'noopener,noreferrer')}
                      className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl flex items-center gap-2 shadow-sm transition-colors cursor-pointer"
                    >
                      <ExternalLink className="w-4 h-4" />
                      <span>مشاهدة على موقع YouTube</span>
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* 2. File / PDF Document Viewer with UNIVERSAL CROSS-BROWSER VIEWER & PEN TOOL */}
            {item.contentType === 'file' && (
              <div className="mb-6">
                
                {/* Download bar + Standalone View CTA */}
                <div className="border border-slate-200 dark:border-slate-800 rounded-2xl p-4 bg-slate-50 dark:bg-slate-800/40 mb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-red-100 dark:bg-red-950/60 text-red-600 dark:text-red-400 flex items-center justify-center shrink-0">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white truncate max-w-sm">
                        {item.fileName || `${item.title}.pdf`}
                      </h4>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">
                        {item.fileSize || 'ملف رقمي معتمد'} · يدعم القلم والكتابة بجميع المتصفحات
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setIsStandaloneView(true)}
                      className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
                    >
                      <Maximize2 className="w-3.5 h-3.5 text-amber-300" />
                      <span>عرض الملف لوحده 📄</span>
                    </button>

                    <button
                      onClick={handleDownloadFile}
                      className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md transition-colors flex items-center gap-1.5 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>تحميل الملف</span>
                    </button>
                  </div>
                </div>

                {/* Embedded Cross-Browser Interactive PDF Viewer with Pen */}
                <PDFInteractiveViewer
                  item={item}
                  isStandalone={false}
                  isAdmin={isAdmin}
                />

              </div>
            )}

            {/* 3. External Link Viewer */}
            {item.contentType === 'link' && (
              <div className="mb-6 p-6 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 text-center">
                <div className="w-14 h-14 rounded-2xl bg-purple-100 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 mx-auto flex items-center justify-center mb-4">
                  <ExternalLink className="w-7 h-7" />
                </div>
                <h4 className="text-base font-bold text-slate-900 dark:text-white mb-2">
                  {item.externalUrlTitle || 'رابط خارجي للمحتوى الأكاديمي'}
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-300 max-w-md mx-auto mb-6">
                  هذا المحتوى مستضاف على رابط سحابي (Google Drive أو Telegram أو منصة خارجية).
                </p>
                {item.externalUrl && (
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                    <button
                      onClick={handleOpenExternal}
                      className="w-full sm:w-auto px-6 py-3 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold rounded-xl shadow-md transition-colors flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <ExternalLink className="w-4 h-4" />
                      <span>الانتقال إلى الرابط الخارجي</span>
                    </button>
                  </div>
                )}
              </div>
            )}

          </div>

          {/* Modal Footer */}
          <div className="px-6 py-4 bg-slate-50 dark:bg-slate-900/90 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>محتوى معتمد من منصة Online Courses</span>
            </div>

            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold rounded-xl transition-colors cursor-pointer"
            >
              إغلاق
            </button>
          </div>

        </div>
      </div>

      {/* Delete Confirmation Modal */}
      <DeleteConfirmationModal
        isOpen={isConfirmingDelete}
        title={item.title}
        itemType="content"
        onClose={() => setIsConfirmingDelete(false)}
        onConfirm={() => {
          StorageService.deleteContentItem(item.id);
          setIsConfirmingDelete(false);
          onDelete?.(item.id, item.title);
          onClose();
        }}
      />

      {/* Embedded AI Assistant Modal */}
      <AIStudyAssistantModal
        item={item}
        isOpen={isAIModalOpen}
        onClose={() => setIsAIModalOpen(false)}
        initialTab={initialAITab}
      />
    </>
  );
};
