import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area
} from 'recharts';
import {
  Eye,
  Download,
  TrendingUp,
  BarChart3,
  Award,
  Layers,
  BookOpen,
  Filter,
  Sparkles,
  ArrowUpRight,
  PieChart as PieIcon,
  Video,
  FileText,
  Link as LinkIcon,
  Calendar,
  Upload
} from 'lucide-react';
import {
  ContentItem,
  SubjectItem,
  CategoryDefinition,
  AcademicYearId
} from '../types';
import { ACADEMIC_YEARS } from '../data/mockData';

interface AnalyticsDashboardProps {
  contentList: ContentItem[];
  subjectsList: SubjectItem[];
  categoriesList: CategoryDefinition[];
  onOpenContent: (item: ContentItem) => void;
  onNavigateToUpload: () => void;
}

// Visual color palette for charts
const CATEGORY_COLORS = [
  '#3b82f6', // blue
  '#8b5cf6', // purple
  '#10b981', // emerald
  '#f59e0b', // amber
  '#ec4899', // pink
  '#06b6d4', // cyan
  '#6366f1', // indigo
  '#14b8a6'  // teal
];

const FORMAT_COLORS: Record<string, string> = {
  file: '#10b981',    // emerald
  youtube: '#ef4444', // red
  link: '#8b5cf6'     // purple
};

// Simulated mock data for demo preview if the user platform is currently empty
const DEMO_CONTENT_ITEMS: ContentItem[] = [
  {
    id: 'demo-1',
    yearId: 'year-1',
    categoryId: 'lectures',
    subject: 'مقدمة في علوم الحاسب',
    title: 'المحاضرة 1: بنية الحاسب والأنظمة الثنائية',
    description: 'شرح تمهيدي لأنظمة العد الثنائي والبوابات المنطقية',
    contentType: 'file',
    fileName: 'intro_cs_lec1.pdf',
    uploaderName: 'د. خالد عبد الرحمن',
    uploaderEmail: 'admin@college.edu',
    uploaderRole: 'admin',
    createdAt: '2026-10-10T10:00:00Z',
    views: 420,
    downloads: 310
  },
  {
    id: 'demo-2',
    yearId: 'year-1',
    categoryId: 'lectures',
    subject: 'مقدمة في علوم الحاسب',
    title: 'المحاضرة 2: الخوارزميات وهياكل التحكم',
    description: 'تمثيل الخوارزميات ومخططات الانسياب',
    contentType: 'youtube',
    youtubeUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    uploaderName: 'د. خالد عبد الرحمن',
    uploaderEmail: 'admin@college.edu',
    uploaderRole: 'admin',
    createdAt: '2026-10-12T10:00:00Z',
    views: 380,
    downloads: 0
  },
  {
    id: 'demo-3',
    yearId: 'year-1',
    categoryId: 'assignments',
    subject: 'تراكيب البيانات',
    title: 'تكليف 1: تنفيذ القوائم المتصلة (Linked Lists)',
    description: 'واجب برمجي عملي بلغة ++C',
    contentType: 'file',
    fileName: 'assignment_1_linked_list.pdf',
    uploaderName: 'م. أحمد ممدوح',
    uploaderEmail: 'supervisor1@college.edu',
    uploaderRole: 'supervisor',
    createdAt: '2026-10-14T10:00:00Z',
    views: 560,
    downloads: 480
  },
  {
    id: 'demo-4',
    yearId: 'year-2',
    categoryId: 'lectures',
    subject: 'تراكيب البيانات',
    title: 'المحاضرة 3: الأشجار الثنائية وBinary Search Tree',
    description: 'شرح مفصل لبناء والبحث في الـ BST',
    contentType: 'file',
    fileName: 'data_structures_trees.pdf',
    uploaderName: 'د. رانيا سامي',
    uploaderEmail: 'admin@college.edu',
    uploaderRole: 'admin',
    createdAt: '2026-10-15T10:00:00Z',
    views: 610,
    downloads: 520
  },
  {
    id: 'demo-5',
    yearId: 'year-2',
    categoryId: 'summaries',
    subject: 'قواعد البيانات',
    title: 'ملخص شامل: استعلامات SQL والـ Joins المتقدمة',
    description: 'مراجعة شاملة لاختبار منتصف الفصل',
    contentType: 'file',
    fileName: 'sql_advanced_cheatsheet.pdf',
    uploaderName: 'م. سارة محمود',
    uploaderEmail: 'supervisor2@college.edu',
    uploaderRole: 'supervisor',
    createdAt: '2026-10-16T10:00:00Z',
    views: 740,
    downloads: 690
  },
  {
    id: 'demo-6',
    yearId: 'year-3',
    categoryId: 'lectures',
    subject: 'هندسة البرمجيات',
    title: 'المحاضرة 4: أساليب التصميم والتطوير بنظام Agile',
    description: 'منهجيات Agile و Scrum ومراحل دورة حياة البرمجيات',
    contentType: 'youtube',
    youtubeUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    uploaderName: 'د. طارق فاروق',
    uploaderEmail: 'admin@college.edu',
    uploaderRole: 'admin',
    createdAt: '2026-10-18T10:00:00Z',
    views: 290,
    downloads: 0
  },
  {
    id: 'demo-7',
    yearId: 'year-3',
    categoryId: 'sections',
    subject: 'شبكات الحاسب',
    title: 'سكشن 2: بروتوكولات TCP/IP وحساب الـ Subnetting',
    description: 'تمارين عملية ومسائل محلولة في تقسيم الشبكات',
    contentType: 'file',
    fileName: 'networking_subnetting_exercises.pdf',
    uploaderName: 'م. أحمد ممدوح',
    uploaderEmail: 'supervisor1@college.edu',
    uploaderRole: 'supervisor',
    createdAt: '2026-10-20T10:00:00Z',
    views: 450,
    downloads: 390
  },
  {
    id: 'demo-8',
    yearId: 'year-4',
    categoryId: 'lectures',
    subject: 'الذكاء الاصطناعي وتعلم الآلة',
    title: 'المحاضرة 5: الشبكات العصبية العميقة (Deep Learning)',
    description: 'مقدمة للشبكات الالتفافية CNN وتطبيقات الرؤية الحاسوبية',
    contentType: 'file',
    fileName: 'deep_learning_intro.pdf',
    uploaderName: 'د. رانيا سامي',
    uploaderEmail: 'admin@college.edu',
    uploaderRole: 'admin',
    createdAt: '2026-10-22T10:00:00Z',
    views: 890,
    downloads: 780
  }
];

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({
  contentList,
  subjectsList,
  categoriesList,
  onOpenContent,
  onNavigateToUpload
}) => {
  // State for Demo Preview when real content is empty
  const [showDemoPreview, setShowDemoPreview] = useState<boolean>(false);

  // Active year filter for statistics
  const [selectedYear, setSelectedYear] = useState<string>('all');

  // Metric focus toggle: 'both' | 'views' | 'downloads'
  const [metricFocus, setMetricFocus] = useState<'both' | 'views' | 'downloads'>('both');

  // Chart display style: 'bar' | 'area'
  const [chartType, setChartType] = useState<'bar' | 'area'>('bar');

  // Effective content items to analyze
  const isActualEmpty = contentList.length === 0;
  const activeContent: ContentItem[] = useMemo(() => {
    if (isActualEmpty) {
      return showDemoPreview ? DEMO_CONTENT_ITEMS : [];
    }
    return contentList;
  }, [contentList, isActualEmpty, showDemoPreview]);

  // Filter content by selected academic year
  const filteredContent = useMemo(() => {
    if (selectedYear === 'all') return activeContent;
    return activeContent.filter(item => item.yearId === selectedYear);
  }, [activeContent, selectedYear]);

  // 1. Overall Aggregated KPI Stats
  const kpiStats = useMemo(() => {
    const totalViews = filteredContent.reduce((sum, item) => sum + (item.views || 0), 0);
    const totalDownloads = filteredContent.reduce((sum, item) => sum + (item.downloads || 0), 0);
    const avgViewsPerItem = filteredContent.length > 0 ? Math.round(totalViews / filteredContent.length) : 0;

    // Top subject by total engagement (views + downloads)
    const subjectEngagementMap: Record<string, number> = {};
    filteredContent.forEach(item => {
      const subName = item.subject || 'غير محدد';
      subjectEngagementMap[subName] = (subjectEngagementMap[subName] || 0) + (item.views || 0) + (item.downloads || 0);
    });

    let topSubject = 'لا يوجد';
    let maxEngagement = -1;
    Object.entries(subjectEngagementMap).forEach(([sub, score]) => {
      if (score > maxEngagement) {
        maxEngagement = score;
        topSubject = sub;
      }
    });

    return {
      totalViews,
      totalDownloads,
      avgViewsPerItem,
      topSubject: maxEngagement > 0 ? topSubject : (filteredContent[0]?.subject || 'لا يوجد'),
      totalItems: filteredContent.length
    };
  }, [filteredContent]);

  // 2. Top Subjects by Views & Downloads (Core User Request)
  const subjectsData = useMemo(() => {
    const map: Record<string, { subject: string; views: number; downloads: number; total: number; count: number }> = {};

    filteredContent.forEach(item => {
      const name = item.subject ? item.subject.trim() : 'أخرى';
      if (!map[name]) {
        map[name] = {
          subject: name,
          views: 0,
          downloads: 0,
          total: 0,
          count: 0
        };
      }
      const v = item.views || 0;
      const d = item.downloads || 0;
      map[name].views += v;
      map[name].downloads += d;
      map[name].total += (v + d);
      map[name].count += 1;
    });

    const list = Object.values(map);

    // Sort according to metric focus
    if (metricFocus === 'views') {
      list.sort((a, b) => b.views - a.views);
    } else if (metricFocus === 'downloads') {
      list.sort((a, b) => b.downloads - a.downloads);
    } else {
      list.sort((a, b) => b.total - a.total);
    }

    // Truncate long subject names for readable X-Axis
    return list.slice(0, 10).map(s => ({
      ...s,
      displayName: s.subject.length > 18 ? `${s.subject.substring(0, 16)}...` : s.subject
    }));
  }, [filteredContent, metricFocus]);

  // 3. Category Breakdown (Pie / Donut Chart)
  const categoryData = useMemo(() => {
    const catMap: Record<string, { name: string; count: number; views: number; downloads: number }> = {};

    filteredContent.forEach(item => {
      const catId = item.categoryId;
      const catDef = categoriesList.find(c => c.id === catId);
      const catTitle = catDef ? catDef.title : catId;

      if (!catMap[catId]) {
        catMap[catId] = {
          name: catTitle,
          count: 0,
          views: 0,
          downloads: 0
        };
      }
      catMap[catId].count += 1;
      catMap[catId].views += (item.views || 0);
      catMap[catId].downloads += (item.downloads || 0);
    });

    return Object.values(catMap);
  }, [filteredContent, categoriesList]);

  // 4. Academic Year Engagement Breakdown
  const yearData = useMemo(() => {
    return ACADEMIC_YEARS.map(y => {
      const items = activeContent.filter(item => item.yearId === y.id);
      const views = items.reduce((sum, i) => sum + (i.views || 0), 0);
      const downloads = items.reduce((sum, i) => sum + (i.downloads || 0), 0);
      return {
        name: y.shortTitle,
        fullTitle: y.title,
        itemsCount: items.length,
        views,
        downloads,
        total: views + downloads
      };
    });
  }, [activeContent]);

  // 5. Content Format Breakdown (PDF vs Video vs Link)
  const formatData = useMemo(() => {
    let files = 0;
    let videos = 0;
    let links = 0;

    filteredContent.forEach(item => {
      if (item.contentType === 'file') files += 1;
      else if (item.contentType === 'youtube') videos += 1;
      else if (item.contentType === 'link') links += 1;
    });

    return [
      { name: 'ملفات مرفوعة (PDF / مستندات)', type: 'file', count: files, color: FORMAT_COLORS.file },
      { name: 'محاضرات يوتيوب (فيديوهات)', type: 'youtube', count: videos, color: FORMAT_COLORS.youtube },
      { name: 'روابط خارجية ومراجع', type: 'link', count: links, color: FORMAT_COLORS.link }
    ].filter(f => f.count > 0);
  }, [filteredContent]);

  // 6. Top Ranked Content Items (Leaderboard)
  const topContentItems = useMemo(() => {
    return [...filteredContent]
      .sort((a, b) => ((b.views || 0) + (b.downloads || 0)) - ((a.views || 0) + (a.downloads || 0)))
      .slice(0, 5);
  }, [filteredContent]);

  // Custom Tooltip for Recharts in Arabic
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const dataPoint = payload[0]?.payload;
      return (
        <div className="bg-slate-900 text-white text-xs p-3 rounded-xl shadow-xl border border-slate-700 text-right min-w-[170px] space-y-1.5">
          <p className="font-black text-slate-100 border-b border-slate-800 pb-1">
            {dataPoint?.subject || label}
          </p>
          {payload.map((entry: any, index: number) => (
            <div key={`item-${index}`} className="flex items-center justify-between gap-3 text-[11px]">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: entry.color }} />
                <span className="text-slate-300">{entry.name}:</span>
              </span>
              <strong className="font-mono text-white text-xs">
                {entry.value.toLocaleString('ar-EG')}
              </strong>
            </div>
          ))}
          {dataPoint?.count !== undefined && (
            <div className="pt-1 border-t border-slate-800 text-[10px] text-slate-400 flex justify-between">
              <span>عدد المحتويات:</span>
              <span className="font-mono">{dataPoint.count}</span>
            </div>
          )}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-8 text-right">
      
      {/* ===================================================================== */}
      {/* HEADER & FILTERS BAR                                                  */}
      {/* ===================================================================== */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          
          {/* Title and Description */}
          <div className="flex items-start gap-4">
            <div className="w-13 h-13 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center shadow-lg shadow-blue-500/20 shrink-0">
              <TrendingUp className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-xl sm:text-2xl font-black text-slate-900">
                  لوحة الإحصائيات التفاعلية والتحليلات
                </h2>
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-50 text-blue-700 border border-blue-200 flex items-center gap-1">
                  <BarChart3 className="w-3.5 h-3.5" />
                  <span>مكتبة Recharts</span>
                </span>
                {showDemoPreview && (
                  <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-50 text-amber-700 border border-amber-200 flex items-center gap-1 animate-pulse">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>وضع المعاينة التوضيحية (Demo)</span>
                  </span>
                )}
              </div>
              <p className="text-xs sm:text-sm text-slate-600 mt-1">
                رصد تفاعل الطلاب، ترتيب المواد الأكثر مشاهدة وتحميلاً، ومعدلات الإقبال على المحاضرات والسكاشن والتكليفات.
              </p>
            </div>
          </div>

          {/* Interactive Filters Controls */}
          <div className="flex flex-wrap items-center gap-3">
            
            {/* Year Filter */}
            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-bold">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={selectedYear}
                onChange={(e) => setSelectedYear(e.target.value)}
                className="bg-transparent text-slate-800 font-bold focus:outline-none cursor-pointer"
              >
                <option value="all">كل الفرق الدراسية</option>
                {ACADEMIC_YEARS.map(y => (
                  <option key={y.id} value={y.id}>{y.shortTitle}</option>
                ))}
              </select>
            </div>

            {/* Metric Mode Filter */}
            <div className="flex items-center bg-slate-100 p-1 rounded-xl text-xs font-bold">
              <button
                type="button"
                onClick={() => setMetricFocus('both')}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                  metricFocus === 'both' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                معاً (مشاهدات + تحميلات)
              </button>
              <button
                type="button"
                onClick={() => setMetricFocus('views')}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1 ${
                  metricFocus === 'views' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Eye className="w-3 h-3" />
                <span>المشاهدات</span>
              </button>
              <button
                type="button"
                onClick={() => setMetricFocus('downloads')}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1 ${
                  metricFocus === 'downloads' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Download className="w-3 h-3" />
                <span>التحميلات</span>
              </button>
            </div>

            {/* Demo Preview Toggle Button if empty */}
            {isActualEmpty && (
              <button
                type="button"
                onClick={() => setShowDemoPreview(!showDemoPreview)}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                  showDemoPreview
                    ? 'bg-amber-600 text-white shadow-md'
                    : 'bg-amber-50 text-amber-800 hover:bg-amber-100 border border-amber-300'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{showDemoPreview ? 'إخفاء المعاينة التوضيحية' : 'عرض معاينة تفاعلية (Demo)'}</span>
              </button>
            )}

          </div>

        </div>
      </div>

      {/* ===================================================================== */}
      {/* EMPTY STATE BANNER (When no content uploaded yet)                     */}
      {/* ===================================================================== */}
      {isActualEmpty && !showDemoPreview && (
        <div className="bg-gradient-to-br from-blue-50 to-indigo-50/60 rounded-3xl border-2 border-dashed border-blue-200 p-8 sm:p-12 text-center shadow-xs">
          <div className="w-16 h-16 rounded-2xl bg-blue-600 text-white flex items-center justify-center mx-auto mb-4 shadow-lg shadow-blue-500/25">
            <BarChart3 className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-black text-slate-900 mb-2">
            المنصة فارغة وجاهزة لاستقبال مقرراتك الخاصة!
          </h3>
          <p className="text-xs sm:text-sm text-slate-600 max-w-lg mx-auto leading-relaxed mb-6">
            ستبدأ المخططات التفاعلية ومكتبة Recharts فوراً في تتبع ورصد تفاعل الطلاب ومعدلات المشاهدة والتحميل بمجرد إضافة مواد ورفع محاضرات أو تكليفات.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={onNavigateToUpload}
              className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer flex items-center gap-2"
            >
              <Upload className="w-4 h-4" />
              <span>رفع أول محتوى أكاديمي الآن 📤</span>
            </button>
            <button
              onClick={() => setShowDemoPreview(true)}
              className="px-5 py-3 bg-white hover:bg-slate-50 text-slate-800 text-xs font-bold rounded-xl border border-slate-200 shadow-xs transition-colors cursor-pointer flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>تجربة الرسوم البيانية التفاعلية (بيانات توضيحية)</span>
            </button>
          </div>
        </div>
      )}

      {/* When data exists or Demo is enabled */}
      {(!isActualEmpty || showDemoPreview) && (
        <>
          {/* ================================================================= */}
          {/* KEY PERFORMANCE INDICATORS (KPIs)                                 */}
          {/* ================================================================= */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            
            {/* KPI 1: Total Views */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-slate-600">إجمالي المشاهدات</span>
                <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                  <Eye className="w-5 h-5" />
                </div>
              </div>
              <div className="text-2xl sm:text-3xl font-black text-slate-900 font-mono">
                {kpiStats.totalViews.toLocaleString('ar-EG')}
              </div>
              <p className="text-[11px] text-slate-500 mt-2 flex items-center gap-1">
                <span className="text-blue-600 font-bold">●</span>
                <span>لكافة المحتويات المنشورة</span>
              </p>
            </div>

            {/* KPI 2: Total Downloads */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-slate-600">إجمالي التحميلات والتنزيل</span>
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                  <Download className="w-5 h-5" />
                </div>
              </div>
              <div className="text-2xl sm:text-3xl font-black text-slate-900 font-mono">
                {kpiStats.totalDownloads.toLocaleString('ar-EG')}
              </div>
              <p className="text-[11px] text-slate-500 mt-2 flex items-center gap-1">
                <span className="text-emerald-600 font-bold">●</span>
                <span>ملفات PDF ومرفقات تم حفظها</span>
              </p>
            </div>

            {/* KPI 3: Top Subject */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-slate-600">المادة الأكثر طلباً وتفاعلاً</span>
                <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
                  <Award className="w-5 h-5" />
                </div>
              </div>
              <div className="text-base sm:text-lg font-black text-slate-900 truncate" title={kpiStats.topSubject}>
                {kpiStats.topSubject}
              </div>
              <p className="text-[11px] text-slate-500 mt-2 flex items-center gap-1">
                <span className="text-amber-600 font-bold">★</span>
                <span>حققت أعلى معدل زيارات وتحميلات</span>
              </p>
            </div>

            {/* KPI 4: Average Engagement */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-slate-600">متوسط المشاهدات لكل محتوى</span>
                <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
                  <TrendingUp className="w-5 h-5" />
                </div>
              </div>
              <div className="text-2xl sm:text-3xl font-black text-slate-900 font-mono">
                {kpiStats.avgViewsPerItem.toLocaleString('ar-EG')}
              </div>
              <p className="text-[11px] text-slate-500 mt-2 flex items-center gap-1">
                <span className="text-purple-600 font-bold">●</span>
                <span>معدل إقبال الطلاب لكل محاضرة أو شيت</span>
              </p>
            </div>

          </div>

          {/* ================================================================= */}
          {/* PRIMARY CHART: TOP SUBJECTS BY VIEWS & DOWNLOADS                  */}
          {/* ================================================================= */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-black text-slate-900">
                    📊 ترتيب المواد الأكثر مشاهدة أو تحميلاً (Top Subjects)
                  </h3>
                  <span className="text-xs font-bold text-slate-500">
                    ({subjectsData.length} مادة)
                  </span>
                </div>
                <p className="text-xs text-slate-600 mt-0.5">
                  رسم بياني تفاعلي يوضح المقارنة المباشرة بين عدد مرات فتح المحتوى ومرات التنزيل لكل مادة دراسية.
                </p>
              </div>

              {/* Chart Format Switcher */}
              <div className="flex items-center gap-2 self-start sm:self-auto bg-slate-100 p-1 rounded-xl text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setChartType('bar')}
                  className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                    chartType === 'bar' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  أعمدة مقارنة (Bar)
                </button>
                <button
                  type="button"
                  onClick={() => setChartType('area')}
                  className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                    chartType === 'area' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  منحنى تفاعلي (Area)
                </button>
              </div>
            </div>

            {subjectsData.length === 0 ? (
              <div className="py-16 text-center text-slate-500 text-xs">
                لا توجد مواد مسجلة تطابق التصفية المختارة.
              </div>
            ) : (
              <div className="w-full h-80 sm:h-96" dir="ltr">
                <ResponsiveContainer width="100%" height="100%">
                  {chartType === 'bar' ? (
                    <BarChart
                      data={subjectsData}
                      margin={{ top: 20, right: 30, left: 10, bottom: 60 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                      <XAxis
                        dataKey="displayName"
                        tick={{ fill: '#64748b', fontSize: 11 }}
                        interval={0}
                        angle={-25}
                        textAnchor="end"
                        height={60}
                      />
                      <YAxis
                        tick={{ fill: '#64748b', fontSize: 11 }}
                        allowDecimals={false}
                      />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend
                        verticalAlign="top"
                        align="right"
                        wrapperStyle={{ paddingBottom: 15, fontSize: 12 }}
                      />
                      {(metricFocus === 'both' || metricFocus === 'views') && (
                        <Bar
                          dataKey="views"
                          name="المشاهدات (Views)"
                          fill="#3b82f6"
                          radius={[6, 6, 0, 0]}
                        />
                      )}
                      {(metricFocus === 'both' || metricFocus === 'downloads') && (
                        <Bar
                          dataKey="downloads"
                          name="التحميلات (Downloads)"
                          fill="#10b981"
                          radius={[6, 6, 0, 0]}
                        />
                      )}
                    </BarChart>
                  ) : (
                    <AreaChart
                      data={subjectsData}
                      margin={{ top: 20, right: 30, left: 10, bottom: 60 }}
                    >
                      <defs>
                        <linearGradient id="colorViews" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                          <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.05}/>
                        </linearGradient>
                        <linearGradient id="colorDownloads" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#10b981" stopOpacity={0.8}/>
                          <stop offset="95%" stopColor="#10b981" stopOpacity={0.05}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                      <XAxis
                        dataKey="displayName"
                        tick={{ fill: '#64748b', fontSize: 11 }}
                        interval={0}
                        angle={-25}
                        textAnchor="end"
                        height={60}
                      />
                      <YAxis
                        tick={{ fill: '#64748b', fontSize: 11 }}
                        allowDecimals={false}
                      />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend
                        verticalAlign="top"
                        align="right"
                        wrapperStyle={{ paddingBottom: 15, fontSize: 12 }}
                      />
                      {(metricFocus === 'both' || metricFocus === 'views') && (
                        <Area
                          type="monotone"
                          dataKey="views"
                          name="المشاهدات (Views)"
                          stroke="#3b82f6"
                          strokeWidth={2}
                          fillOpacity={1}
                          fill="url(#colorViews)"
                        />
                      )}
                      {(metricFocus === 'both' || metricFocus === 'downloads') && (
                        <Area
                          type="monotone"
                          dataKey="downloads"
                          name="التحميلات (Downloads)"
                          stroke="#10b981"
                          strokeWidth={2}
                          fillOpacity={1}
                          fill="url(#colorDownloads)"
                        />
                      )}
                    </AreaChart>
                  )}
                </ResponsiveContainer>
              </div>
            )}
          </div>

          {/* ================================================================= */}
          {/* SECONDARY CHARTS (CATEGORY BREAKDOWN & ACADEMIC YEARS)             */}
          {/* ================================================================= */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Chart 2: Category Breakdown (Donut Pie) */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <PieIcon className="w-5 h-5 text-purple-600" />
                    <h4 className="text-sm font-black text-slate-900">
                      توزيع المحتوى ونسبة التفاعل حسب الأقسام
                    </h4>
                  </div>
                  <span className="text-[11px] font-bold text-slate-500">
                    المحاضرات، السكاشن، التكليفات
                  </span>
                </div>

                {categoryData.length === 0 ? (
                  <div className="py-12 text-center text-slate-500 text-xs">
                    لا توجد أقسام مسجلة.
                  </div>
                ) : (
                  <div className="w-full h-64" dir="ltr">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={categoryData}
                          dataKey="count"
                          nameKey="name"
                          cx="50%"
                          cy="50%"
                          innerRadius={55}
                          outerRadius={85}
                          paddingAngle={4}
                        >
                          {categoryData.map((_, index) => (
                            <Cell
                              key={`cell-${index}`}
                              fill={CATEGORY_COLORS[index % CATEGORY_COLORS.length]}
                            />
                          ))}
                        </Pie>
                        <Tooltip
                          formatter={(value: any, name: any, item: any) => {
                            const p = item.payload;
                            return [
                              `${value} محتوى (مشاهدات: ${p.views || 0} | تحميلات: ${p.downloads || 0})`,
                              name
                            ];
                          }}
                        />
                        <Legend
                          verticalAlign="bottom"
                          wrapperStyle={{ fontSize: 11, paddingTop: 10 }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </div>

              {/* Category Mini Stats List */}
              <div className="mt-4 pt-4 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-3 gap-2">
                {categoryData.map((cat, idx) => (
                  <div key={idx} className="bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-center">
                    <span className="text-[11px] font-bold text-slate-700 block truncate" title={cat.name}>
                      {cat.name}
                    </span>
                    <strong className="text-xs font-mono font-black text-slate-900">
                      {cat.count} عنصر
                    </strong>
                    <div className="text-[10px] text-slate-500 mt-0.5">
                      👁️ {cat.views} | 📥 {cat.downloads}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Chart 3: Academic Years Comparison */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <Layers className="w-5 h-5 text-indigo-600" />
                    <h4 className="text-sm font-black text-slate-900">
                      تفاعل واستهلاك المحتوى عبر الفرق الدراسية
                    </h4>
                  </div>
                  <span className="text-[11px] font-bold text-slate-500">
                    الفرقة 1 إلى الفرقة 4
                  </span>
                </div>

                <div className="w-full h-64" dir="ltr">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={yearData}
                      margin={{ top: 10, right: 20, left: 0, bottom: 20 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                      <XAxis
                        dataKey="name"
                        tick={{ fill: '#64748b', fontSize: 11 }}
                      />
                      <YAxis
                        tick={{ fill: '#64748b', fontSize: 11 }}
                        allowDecimals={false}
                      />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend
                        verticalAlign="top"
                        align="right"
                        wrapperStyle={{ paddingBottom: 10, fontSize: 11 }}
                      />
                      <Bar
                        dataKey="views"
                        name="المشاهدات"
                        fill="#6366f1"
                        radius={[5, 5, 0, 0]}
                      />
                      <Bar
                        dataKey="downloads"
                        name="التحميلات"
                        fill="#06b6d4"
                        radius={[5, 5, 0, 0]}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Year Summary Bar */}
              <div className="mt-4 pt-4 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
                {yearData.map((y, idx) => (
                  <div key={idx} className="bg-slate-50 p-2 rounded-xl border border-slate-100">
                    <span className="text-[11px] font-bold text-slate-700 block">{y.name}</span>
                    <strong className="text-xs font-mono font-black text-indigo-600">
                      {y.total} تفاعل
                    </strong>
                    <span className="text-[10px] text-slate-400 block font-mono">({y.itemsCount} محتوى)</span>
                  </div>
                ))}
              </div>
            </div>

          </div>

          {/* ================================================================= */}
          {/* FORMAT BREAKDOWN & LEADERBOARD                                    */}
          {/* ================================================================= */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Format Breakdown (PDF vs Video vs Link) */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
              <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-100">
                <FileText className="w-5 h-5 text-emerald-600" />
                <h4 className="text-sm font-black text-slate-900">
                  صيغ ونوع المحتوى المرفوع
                </h4>
              </div>

              <div className="space-y-4">
                {formatData.map((fmt, idx) => {
                  const percent = filteredContent.length > 0 ? Math.round((fmt.count / filteredContent.length) * 100) : 0;
                  return (
                    <div key={idx} className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="flex items-center gap-2 font-bold text-slate-800">
                          {fmt.type === 'file' && <FileText className="w-4 h-4 text-emerald-600" />}
                          {fmt.type === 'youtube' && <Video className="w-4 h-4 text-red-600" />}
                          {fmt.type === 'link' && <LinkIcon className="w-4 h-4 text-purple-600" />}
                          <span>{fmt.name}</span>
                        </span>
                        <span className="font-mono font-black text-slate-900">
                          {fmt.count} ({percent}%)
                        </span>
                      </div>
                      <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-500"
                          style={{ width: `${percent}%`, backgroundColor: fmt.color }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="mt-6 p-4 bg-slate-50 rounded-xl border border-slate-100 text-xs text-slate-600 leading-relaxed">
                💡 <strong>توصية أكاديمية:</strong> الطلاب يفضلون تنزيل ملفات الـ PDF والملخصات لمذاكرتها دون إنترنت، بينما الفيديوهات تعزز فهم الشروحات المعقدة.
              </div>
            </div>

            {/* Top 5 Content Items Leaderboard */}
            <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
              <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-amber-500" />
                  <h4 className="text-sm font-black text-slate-900">
                    قائمة الشرف: المحتويات والمحاضرات الأكثر تفاعلاً
                  </h4>
                </div>
                <span className="text-[11px] font-bold text-slate-500">
                  ترتيب تنازلي حسب المشاهدات والتحميلات
                </span>
              </div>

              {topContentItems.length === 0 ? (
                <div className="py-12 text-center text-slate-500 text-xs">
                  لا توجد محتويات كافية للترتيب حالياً.
                </div>
              ) : (
                <div className="divide-y divide-slate-100">
                  {topContentItems.map((item, index) => {
                    const catTitle = categoriesList.find(c => c.id === item.categoryId)?.singular || item.categoryId;
                    const yearShort = ACADEMIC_YEARS.find(y => y.id === item.yearId)?.shortTitle;
                    const totalEngagement = (item.views || 0) + (item.downloads || 0);

                    return (
                      <div key={item.id} className="py-3 sm:py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/70 px-2 rounded-xl transition-colors">
                        
                        {/* Rank and Title */}
                        <div className="flex items-center gap-3 min-w-0">
                          <div className={`w-8 h-8 rounded-xl flex items-center justify-center font-black text-xs shrink-0 ${
                            index === 0
                              ? 'bg-amber-100 text-amber-800 border border-amber-300'
                              : index === 1
                              ? 'bg-slate-200 text-slate-700'
                              : index === 2
                              ? 'bg-orange-100 text-orange-800'
                              : 'bg-slate-100 text-slate-600'
                          }`}>
                            {index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `#${index + 1}`}
                          </div>

                          <div className="min-w-0">
                            <h5 className="text-xs font-black text-slate-900 truncate" title={item.title}>
                              {item.title}
                            </h5>
                            <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5">
                              <span className="text-blue-600 font-bold">{item.subject}</span>
                              <span>•</span>
                              <span>{catTitle}</span>
                              {yearShort && (
                                <>
                                  <span>•</span>
                                  <span>{yearShort}</span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Stats & Preview Action */}
                        <div className="flex items-center gap-3 sm:gap-4 shrink-0 self-end sm:self-auto">
                          <div className="flex items-center gap-3 text-xs font-mono">
                            <span className="flex items-center gap-1 text-blue-600 font-bold" title="عدد المشاهدات">
                              <Eye className="w-3.5 h-3.5" />
                              <span>{item.views || 0}</span>
                            </span>
                            <span className="flex items-center gap-1 text-emerald-600 font-bold" title="عدد التحميلات">
                              <Download className="w-3.5 h-3.5" />
                              <span>{item.downloads || 0}</span>
                            </span>
                            <span className="text-[11px] font-bold text-slate-500 hidden sm:inline">
                              (الإجمالي: {totalEngagement})
                            </span>
                          </div>

                          <button
                            type="button"
                            onClick={() => onOpenContent(item)}
                            className="px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg text-xs font-bold transition-colors cursor-pointer flex items-center gap-1"
                          >
                            <ArrowUpRight className="w-3.5 h-3.5" />
                            <span>معاينة</span>
                          </button>
                        </div>

                      </div>
                    );
                  })}
                </div>
              )}
            </div>

          </div>
        </>
      )}

    </div>
  );
};
