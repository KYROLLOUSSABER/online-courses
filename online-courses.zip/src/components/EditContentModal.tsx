import React, { useState, useEffect } from 'react';
import { ContentItem, AcademicYearId, CategoryId, ContentType, DepartmentId, SemesterId } from '../types';
import { ACADEMIC_YEARS } from '../data/mockData';
import { StorageService } from '../services/storage';
import { 
  X, 
  Check, 
  Upload, 
  Video, 
  FileText, 
  ExternalLink, 
  Edit3,
  Clock
} from 'lucide-react';

interface EditContentModalProps {
  item: ContentItem | null;
  isOpen: boolean;
  onClose: () => void;
  onSaveSuccess: () => void;
}

export const EditContentModal: React.FC<EditContentModalProps> = ({
  item,
  isOpen,
  onClose,
  onSaveSuccess
}) => {
  if (!isOpen || !item) return null;

  const [yearId, setYearId] = useState<AcademicYearId>(item.yearId);
  const [departmentId, setDepartmentId] = useState<DepartmentId>(item.departmentId || 'cs');
  const [semesterId, setSemesterId] = useState<SemesterId>(item.semesterId || 'sem-1');
  const [categoryId, setCategoryId] = useState<CategoryId>(item.categoryId);
  const [subject, setSubject] = useState<string>(item.subject);
  const [title, setTitle] = useState<string>(item.title);
  const [description, setDescription] = useState<string>(item.description);
  const [contentType, setContentType] = useState<ContentType>(item.contentType);
  
  // File replacement
  const [newFile, setNewFile] = useState<{
    name: string;
    size: string;
    type: string;
    data: string;
  } | null>(null);

  // YouTube URL
  const [youtubeUrl, setYoutubeUrl] = useState<string>(item.youtubeUrl || '');

  // External link
  const [externalUrl, setExternalUrl] = useState<string>(item.externalUrl || '');
  const [externalUrlTitle, setExternalUrlTitle] = useState<string>(item.externalUrlTitle || '');

  // Due Date & Deadline Note (Allowed for ANY content item)
  const [dueDate, setDueDate] = useState<string>(item.dueDate || '');
  const [deadlineNote, setDeadlineNote] = useState<string>(item.deadlineNote || '');

  useEffect(() => {
    if (item) {
      setYearId(item.yearId);
      setDepartmentId(item.departmentId || 'cs');
      setSemesterId(item.semesterId || 'sem-1');
      setCategoryId(item.categoryId);
      setSubject(item.subject);
      setTitle(item.title);
      setDescription(item.description);
      setContentType(item.contentType);
      setYoutubeUrl(item.youtubeUrl || '');
      setExternalUrl(item.externalUrl || '');
      setExternalUrlTitle(item.externalUrlTitle || '');
      setDueDate(item.dueDate || '');
      setDeadlineNote(item.deadlineNote || '');
      setNewFile(null);
    }
  }, [item]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const sizeInMb = (file.size / (1024 * 1024)).toFixed(1);
    const reader = new FileReader();
    reader.onload = () => {
      setNewFile({
        name: file.name,
        size: `${sizeInMb} ميجابايت`,
        type: file.type,
        data: reader.result as string
      });
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !subject.trim()) return;

    const updates: Partial<ContentItem> = {
      yearId,
      departmentId,
      semesterId,
      categoryId,
      subject: subject.trim(),
      title: title.trim(),
      description: description.trim(),
      contentType,
      dueDate: dueDate ? dueDate : undefined,
      deadlineNote: deadlineNote.trim() ? deadlineNote.trim() : undefined
    };

    if (contentType === 'youtube') {
      updates.youtubeUrl = youtubeUrl.trim();
    } else if (contentType === 'link') {
      updates.externalUrl = externalUrl.trim();
      updates.externalUrlTitle = externalUrlTitle.trim() || undefined;
    } else if (contentType === 'file') {
      if (newFile) {
        updates.fileName = newFile.name;
        updates.fileSize = newFile.size;
        updates.fileType = newFile.type;
        updates.fileData = newFile.data;
      }
    }

    const res = StorageService.updateContentItem(item.id, updates);
    if (res.success) {
      onSaveSuccess();
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 text-right">
      <div 
        className="relative bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 my-6"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Edit3 className="w-5 h-5 text-blue-400" />
            <h3 className="text-base font-bold text-white">
              تعديل المحتوى الأكاديمي
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 max-h-[80vh] overflow-y-auto space-y-4">
          
          {/* Year and Category */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                الفرقة الدراسية
              </label>
              <select
                value={yearId}
                onChange={(e) => setYearId(e.target.value as AcademicYearId)}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {ACADEMIC_YEARS.map(y => (
                  <option key={y.id} value={y.id}>{y.title}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                نوع القسم
              </label>
              <select
                value={categoryId}
                onChange={(e) => setCategoryId(e.target.value as CategoryId)}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {StorageService.getCategories().map(c => (
                  <option key={c.id} value={c.id}>
                    {c.title}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Department and Semester */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                القسم / التخصص الأكاديمي
              </label>
              <select
                value={departmentId}
                onChange={(e) => setDepartmentId(e.target.value as DepartmentId)}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="cs">💻 قسم علوم حاسب</option>
                <option value="ai">🤖 قسم ذكاء اصطناعي</option>
                <option value="cyber">🛡️ قسم أمن سيبراني</option>
                <option value="all">🌐 عام لجميع الأقسام</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                الفصل الدراسي (الترم)
              </label>
              <select
                value={semesterId}
                onChange={(e) => setSemesterId(e.target.value as SemesterId)}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="sem-1">📅 الترم الأول</option>
                <option value="sem-2">📅 الترم الثاني</option>
                <option value="all">🗓️ ممتد طوال العام</option>
              </select>
            </div>
          </div>

          {/* Subject */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              اسم المادة الدراسية
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                required
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="اسم المادة..."
                className="flex-1 p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <select
                onChange={(e) => {
                  if (e.target.value) setSubject(e.target.value);
                }}
                className="p-2.5 bg-slate-100 border border-slate-200 rounded-xl text-xs text-slate-700 max-w-[180px]"
              >
                <option value="">اختر من المواد المسجلة</option>
                {StorageService.getSubjects(yearId).map(s => (
                  <option key={s.id} value={s.name}>{s.name}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Title */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              عنوان المحتوى
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              الوصف أو الملاحظات
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Deadline / Due Date & Alert Note for ANY content item */}
          <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/40 p-3.5 rounded-xl">
            <div className="flex items-center gap-2 mb-2 text-xs font-bold text-amber-900 dark:text-amber-300">
              <Clock className="w-4 h-4 text-amber-600" />
              <span>الموعد النهائي وتنبيه الفرقة (Deadline) - اختياري</span>
            </div>
            <div className="grid sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  تاريخ الموعد النهائي
                </label>
                <input
                  type="date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  ملاحظة أو تنبيه التسليم (يظهر للفرقة)
                </label>
                <input
                  type="text"
                  value={deadlineNote}
                  onChange={(e) => setDeadlineNote(e.target.value)}
                  placeholder="مثال: تسليم الشيت للدكتور قبل 12 ظهراً"
                  className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-white"
                />
              </div>
            </div>
          </div>

          {/* Content Type Selector */}
          <div className="border border-slate-200 rounded-xl p-4 bg-slate-50">
            <label className="block text-xs font-bold text-slate-800 mb-2">
              نوع المحتوى المرفق
            </label>
            
            <div className="flex gap-2 mb-3">
              <button
                type="button"
                onClick={() => setContentType('file')}
                className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                  contentType === 'file' ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-slate-700'
                }`}
              >
                ملف (PDF / مستند)
              </button>
              <button
                type="button"
                onClick={() => setContentType('youtube')}
                className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                  contentType === 'youtube' ? 'bg-red-600 text-white border-red-600' : 'bg-white text-slate-700'
                }`}
              >
                رابط يوتيوب
              </button>
              <button
                type="button"
                onClick={() => setContentType('link')}
                className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                  contentType === 'link' ? 'bg-purple-600 text-white border-purple-600' : 'bg-white text-slate-700'
                }`}
              >
                رابط خارجي
              </button>
            </div>

            {/* File options */}
            {contentType === 'file' && (
              <div className="space-y-2">
                <div className="text-xs text-slate-600">
                  الملف الحالي: <strong className="text-slate-900">{item.fileName || 'ملف PDF'}</strong>
                </div>
                <div className="flex items-center gap-2">
                  <label className="px-3 py-2 bg-white border border-slate-300 hover:border-blue-500 rounded-lg text-xs font-bold text-blue-600 cursor-pointer flex items-center gap-1.5 shadow-sm">
                    <Upload className="w-3.5 h-3.5" />
                    <span>تغيير ورفع ملف جديد بديل</span>
                    <input
                      type="file"
                      accept=".pdf,.doc,.docx,.ppt,.pptx,.zip,.txt,image/*"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                  </label>
                  {newFile && (
                    <span className="text-xs text-emerald-600 font-bold">
                      تم اختيار: {newFile.name}
                    </span>
                  )}
                </div>
              </div>
            )}

            {/* YouTube option */}
            {contentType === 'youtube' && (
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  رابط يوتيوب
                </label>
                <input
                  type="url"
                  value={youtubeUrl}
                  onChange={(e) => setYoutubeUrl(e.target.value)}
                  dir="ltr"
                  className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 font-sans"
                />
              </div>
            )}

            {/* Link option */}
            {contentType === 'link' && (
              <div className="space-y-2">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    الرابط الخارجي
                  </label>
                  <input
                    type="url"
                    value={externalUrl}
                    onChange={(e) => setExternalUrl(e.target.value)}
                    dir="ltr"
                    className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 font-sans"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    عنوان الرابط
                  </label>
                  <input
                    type="text"
                    value={externalUrlTitle}
                    onChange={(e) => setExternalUrlTitle(e.target.value)}
                    className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-900"
                  />
                </div>
              </div>
            )}

          </div>

          {/* Footer Buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold rounded-xl transition-colors cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>حفظ التعديلات</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
