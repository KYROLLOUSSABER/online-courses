import React, { useState, useMemo, useEffect } from 'react';
import { 
  AcademicYearId, 
  CategoryId, 
  ContentItem, 
  UserAccount, 
  CategoryDefinition, 
  SubjectItem,
  DepartmentId,
  SemesterId
} from '../types';
import { ACADEMIC_YEARS, CATEGORY_INFO, DEPARTMENTS, SEMESTERS } from '../data/mockData';
import { StorageService } from '../services/storage';
import { OfflineStorageService } from '../services/offlineStorage';
import { AIStudyAssistantModal } from './AIStudyAssistantModal';
import { PDFInteractiveViewer } from './PDFInteractiveViewer';
import { DeleteConfirmationModal } from './DeleteConfirmationModal';
import { PomodoroTimer } from './PomodoroTimer';
import { 
  Video, 
  Code, 
  FileCheck, 
  BookMarked, 
  Search, 
  ArrowRight, 
  Calendar, 
  Eye, 
  Download, 
  ExternalLink, 
  Play, 
  FileText, 
  Plus, 
  Clock, 
  BookOpen, 
  Edit3, 
  Trash2, 
  Upload, 
  Bookmark, 
  BookmarkCheck, 
  Sparkles, 
  Bell, 
  AlertTriangle, 
  FolderOpen,
  Maximize2,
  CheckCircle2,
  User,
  Laptop,
  Cpu,
  ShieldAlert,
  ArrowLeft,
  ChevronLeft,
  Layers,
  GraduationCap,
  Timer
} from 'lucide-react';

interface YearViewProps {
  yearId: AcademicYearId;
  contentList: ContentItem[];
  currentUser: UserAccount | null;
  onBackToHome: () => void;
  onSwitchYear: (yearId: AcademicYearId) => void;
  onOpenContent: (item: ContentItem) => void;
  onAddNewContent: (yearId: AcademicYearId, categoryId: CategoryId) => void;
  onEditContent?: (item: ContentItem) => void;
  onDeleteContent?: (id: string, title: string) => void;
}

export const YearView: React.FC<YearViewProps> = ({
  yearId,
  contentList,
  currentUser,
  onBackToHome,
  onSwitchYear,
  onOpenContent,
  onAddNewContent,
  onEditContent,
  onDeleteContent
}) => {
  const isAdmin = currentUser?.role === 'admin';
  const currentYearInfo = ACADEMIC_YEARS.find(y => y.id === yearId) || ACADEMIC_YEARS[0];
  const categories = StorageService.getCategories();

  // Navigation Steps:
  // Step 1: Department Selection ('cs' | 'ai' | 'cyber')
  // Step 2: Semester Selection ('sem-1' | 'sem-2')
  const [selectedDepartment, setSelectedDepartment] = useState<DepartmentId | null>(null);
  const [selectedSemester, setSelectedSemester] = useState<SemesterId | null>(null);

  // Material filters inside chosen department & semester
  const [activeCategory, setActiveCategory] = useState<CategoryId>(categories[0]?.id || 'lectures');
  const [selectedSubject, setSelectedSubject] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterOfflineOnly, setFilterOfflineOnly] = useState(false);
  const [filterDeadlinesOnly, setFilterDeadlinesOnly] = useState(false);

  // Pomodoro Focus Timer State
  const [showPomodoro, setShowPomodoro] = useState(false);

  // Standalone File Viewer State (for "عرض الملف لوحده")
  const [standaloneItem, setStandaloneItem] = useState<ContentItem | null>(null);

  // In-app Delete Confirmation State
  const [itemToDelete, setItemToDelete] = useState<{ id: string; title: string } | null>(null);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // AI Modal
  const [aiModalItem, setAiModalItem] = useState<ContentItem | null>(null);

  // Real-time synchronization on content/subject deletion or modification
  const [dataVersion, setDataVersion] = useState(0);

  useEffect(() => {
    const onDataChanged = () => {
      setDataVersion(v => v + 1);
    };
    window.addEventListener('online_courses_data_changed', onDataChanged);
    return () => {
      window.removeEventListener('online_courses_data_changed', onDataChanged);
    };
  }, []);

  // Offline state tracker
  const [savedOfflineIds, setSavedOfflineIds] = useState<Set<string>>(() => {
    return new Set(OfflineStorageService.getSavedItems().map(i => i.id));
  });

  const toggleSaveOffline = (item: ContentItem) => {
    const res = OfflineStorageService.toggleSave(item);
    setSavedOfflineIds(prev => {
      const next = new Set(prev);
      if (res.isSaved) {
        next.add(item.id);
      } else {
        next.delete(item.id);
      }
      return next;
    });
    showToast(res.isSaved ? 'تم حفظ المحتوى للتشغيل بدون إنترنت 💾' : 'تمت إزالة المحتوى من قائمة الأوفلاين');
  };

  // Direct download button right from outside of the card
  const handleDirectDownload = (item: ContentItem, e: React.MouseEvent) => {
    e.stopPropagation();
    StorageService.incrementDownload(item.id);

    if (item.fileData) {
      const link = document.createElement('a');
      link.href = item.fileData;
      link.download = item.fileName || `${item.title}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      showToast('جاري بدء تحميل الملف...');
    } else if (item.externalUrl) {
      window.open(item.externalUrl, '_blank', 'noopener,noreferrer');
    } else if (item.youtubeUrl) {
      window.open(item.youtubeUrl, '_blank', 'noopener,noreferrer');
    }
  };

  // Confirm delete handler (100% reliable)
  const handleConfirmDelete = () => {
    if (!itemToDelete) return;
    StorageService.deleteContentItem(itemToDelete.id);
    onDeleteContent?.(itemToDelete.id, itemToDelete.title);
    showToast(`تم حذف "${itemToDelete.title}" بنجاح!`);
    setItemToDelete(null);
  };

  // Filter content for this year
  const yearContent = useMemo(() => {
    return contentList.filter(item => item.yearId === yearId);
  }, [contentList, yearId]);

  // Active Deadlines for this specific year
  const yearDeadlines = useMemo(() => {
    return yearContent
      .filter(item => item.dueDate)
      .sort((a, b) => new Date(a.dueDate!).getTime() - new Date(b.dueDate!).getTime());
  }, [yearContent]);

  // Extract all registered subjects for this year + department + semester
  // STRICTLY from storage: No resurrecting old deleted subjects!
  const subjectsList = useMemo(() => {
    const subs = StorageService.getSubjects(
      yearId, 
      selectedDepartment || undefined, 
      selectedSemester || undefined
    );
    const subNames = new Set<string>();
    subs.forEach(s => subNames.add(s.name));
    
    // Also include subjects from currently active content matching this dept and sem
    yearContent.forEach(item => {
      const matchDept = !selectedDepartment || item.departmentId === 'all' || item.departmentId === selectedDepartment;
      const matchSem = !selectedSemester || item.semesterId === 'all' || item.semesterId === selectedSemester;
      if (matchDept && matchSem && item.subject) {
        subNames.add(item.subject);
      }
    });

    return Array.from(subNames);
  }, [yearId, selectedDepartment, selectedSemester, yearContent, dataVersion]);

  // If the active filtered subject no longer exists after a delete, reset to 'all'
  useEffect(() => {
    if (selectedSubject !== 'all' && !subjectsList.includes(selectedSubject)) {
      setSelectedSubject('all');
    }
  }, [subjectsList, selectedSubject]);

  // Filtered items based on Department, Semester, Category, Subject, Search, and Offline/Deadline Toggles
  const displayItems = useMemo(() => {
    return yearContent.filter(item => {
      // Department match
      const matchDept = !selectedDepartment || item.departmentId === 'all' || item.departmentId === selectedDepartment;
      
      // Semester match
      const matchSem = !selectedSemester || item.semesterId === 'all' || item.semesterId === selectedSemester;

      // Category match
      const matchesCategory = filterOfflineOnly || filterDeadlinesOnly ? true : item.categoryId === activeCategory;
      
      // Subject match
      const matchesSubject = selectedSubject === 'all' || item.subject === selectedSubject;
      
      // Search match
      const matchesSearch = !searchQuery.trim() || 
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesOffline = !filterOfflineOnly || savedOfflineIds.has(item.id);
      const matchesDeadline = !filterDeadlinesOnly || !!item.dueDate;

      return matchDept && matchSem && matchesCategory && matchesSubject && matchesSearch && matchesOffline && matchesDeadline;
    });
  }, [yearContent, selectedDepartment, selectedSemester, activeCategory, selectedSubject, searchQuery, filterOfflineOnly, filterDeadlinesOnly, savedOfflineIds]);

  // Format date helper
  const formatDate = (isoString: string) => {
    try {
      const d = new Date(isoString);
      return d.toLocaleDateString('ar-EG', { year: 'numeric', month: 'short', day: 'numeric' });
    } catch {
      return isoString;
    }
  };

  // Granular permissions
  const isAssigned = currentUser && (currentUser.role === 'admin' || currentUser.assignedYears.includes(yearId));
  const canUpload = !!(isAssigned && (currentUser?.role === 'admin' || currentUser?.permissions?.canUpload !== false));
  const canEdit = !!(isAssigned && (currentUser?.role === 'admin' || currentUser?.permissions?.canEdit !== false));
  const canDelete = !!(isAssigned && (currentUser?.role === 'admin' || currentUser?.permissions?.canDelete === true));

  const currentDeptInfo = DEPARTMENTS.find(d => d.id === selectedDepartment);
  const currentSemInfo = SEMESTERS.find(s => s.id === selectedSemester);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 pb-20 text-right transition-colors duration-200">
      
      {/* Toast Feedback */}
      {toastMessage && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 px-6 py-3 bg-emerald-600 text-white rounded-2xl shadow-2xl text-xs font-bold animate-in fade-in slide-in-from-top-4 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-slate-900 text-white border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
          
          {/* Breadcrumb Navigation Bar */}
          <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
              <button
                onClick={onBackToHome}
                className="hover:text-white transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <ArrowRight className="w-4 h-4" />
                <span>الرئيسية</span>
              </button>
              
              <span className="text-slate-600">/</span>
              
              <button
                onClick={() => {
                  setSelectedDepartment(null);
                  setSelectedSemester(null);
                }}
                className={`transition-colors cursor-pointer ${
                  !selectedDepartment ? 'text-blue-400 font-bold' : 'hover:text-white'
                }`}
              >
                {currentYearInfo.title}
              </button>

              {selectedDepartment && (
                <>
                  <span className="text-slate-600">/</span>
                  <button
                    onClick={() => setSelectedSemester(null)}
                    className={`transition-colors cursor-pointer ${
                      !selectedSemester ? 'text-blue-400 font-bold' : 'hover:text-white'
                    }`}
                  >
                    {currentDeptInfo?.name}
                  </button>
                </>
              )}

              {selectedSemester && (
                <>
                  <span className="text-slate-600">/</span>
                  <span className="text-amber-400 font-bold">
                    {currentSemInfo?.shortName}
                  </span>
                </>
              )}
            </div>

            {/* Quick Actions (Pomodoro Timer + Year Switcher) */}
            <div className="flex items-center gap-3">
              
              {/* Pomodoro Focus Study Timer Button */}
              <button
                onClick={() => setShowPomodoro(!showPomodoro)}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer shadow-xs ${
                  showPomodoro 
                    ? 'bg-amber-500 text-white ring-2 ring-amber-400/30' 
                    : 'bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30'
                }`}
                title="فتح أداة بومودورو لتنظيم فترات المذاكرة والتركيز"
              >
                <Timer className="w-4 h-4 animate-pulse" />
                <span>مؤقت المذاكرة (Pomodoro) 🍅</span>
              </button>

              {/* Quick Year Switcher */}
              <div className="flex items-center gap-1 bg-slate-800/80 p-1 rounded-xl border border-slate-700">
                {ACADEMIC_YEARS.map(y => (
                  <button
                    key={y.id}
                    onClick={() => {
                      onSwitchYear(y.id);
                      setSelectedDepartment(null);
                      setSelectedSemester(null);
                    }}
                    className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                      y.id === yearId
                        ? 'bg-blue-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {y.shortTitle}
                  </button>
                ))}
              </div>

            </div>
          </div>

          {/* Title Area */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs font-bold text-blue-400 block mb-1">
                المستوى الجامعي #{currentYearInfo.orderNumber}
              </span>
              <h1 className="text-2xl sm:text-3xl font-black text-white">
                {currentYearInfo.title}
                {currentDeptInfo && <span className="text-blue-400"> • {currentDeptInfo.name}</span>}
                {currentSemInfo && <span className="text-amber-400 text-xl font-bold"> ({currentSemInfo.shortName})</span>}
              </h1>
              <p className="mt-1 text-xs sm:text-sm text-slate-300 max-w-2xl font-normal">
                {currentDeptInfo?.description || currentYearInfo.description}
              </p>
            </div>

            {/* Admin/Supervisor Upload Shortcut */}
            {canUpload && (
              <button
                onClick={() => onAddNewContent(yearId, activeCategory)}
                className="inline-flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md transition-colors cursor-pointer self-start sm:self-auto shrink-0"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة محتوى جديد في هذه الفرقة</span>
              </button>
            )}
          </div>

        </div>
      </div>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        
        {/* Floating/Embedded Pomodoro Timer if toggled */}
        {showPomodoro && (
          <div className="mb-8 max-w-xl mx-auto animate-in fade-in slide-in-from-top-4">
            <PomodoroTimer onClose={() => setShowPomodoro(false)} />
          </div>
        )}

        {/* ================================================================= */}
        {/* STAGE 1: DEPARTMENT SELECTION (الأقسام الثلاثة: علوم حاسب، ذكاء اصطناعي، أمن سيبراني) */}
        {/* ================================================================= */}
        {!selectedDepartment ? (
          <section className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-10 border border-slate-200 dark:border-slate-800 shadow-xl my-6">
            <div className="text-center max-w-2xl mx-auto mb-8">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800 rounded-lg text-xs font-bold mb-3">
                <Sparkles className="w-3.5 h-3.5 text-blue-500" />
                <span>الخطوة 1 من 2: اختيار التخصص والقسم الأكاديمي</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
                اختر القسم في {currentYearInfo.title}
              </h2>
              <p className="mt-2 text-xs sm:text-sm text-slate-600 dark:text-slate-400">
                حدد القسم لعرض المواد والمحاضرات والتكليفات الخاصة بتخصصك:
              </p>
            </div>

            {/* The 3 Department Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              
              {/* DEPARTMENT 1: قسم علوم حاسب (قسم لوحده مستقل) */}
              <button
                onClick={() => setSelectedDepartment('cs')}
                className="group relative p-6 sm:p-8 rounded-3xl bg-slate-50 dark:bg-slate-800/60 border-2 border-slate-200 dark:border-slate-700 hover:border-blue-600 dark:hover:border-blue-500 shadow-sm hover:shadow-2xl transition-all duration-200 text-right cursor-pointer flex flex-col justify-between transform hover:-translate-y-1 overflow-hidden"
              >
                <div className="absolute top-0 right-0 w-28 h-28 bg-blue-600/10 rounded-bl-full group-hover:bg-blue-600/20 transition-all pointer-events-none"></div>

                <div>
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center shadow-lg shadow-blue-500/20 mb-6 group-hover:scale-105 transition-transform">
                    <Laptop className="w-7 h-7" />
                  </div>

                  <span className="text-[11px] font-bold text-blue-600 dark:text-blue-400 block mb-1">
                    قسم عام مستقل
                  </span>
                  <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors mb-2">
                    قسم علوم حاسب
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-6">
                    القسم الأساسي لعلوم الحاسب، البرمجيات، هندسة النظم، الخوارزميات، ونظم التشغيل وقواعد البيانات.
                  </p>
                </div>

                <div className="pt-4 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs font-bold text-blue-600 dark:text-blue-400">
                  <span>دخول القسم وتحديد الترم</span>
                  <ArrowLeft className="w-4 h-4 transform group-hover:-translate-x-1.5 transition-transform" />
                </div>
              </button>

              {/* DEPARTMENT 2: قسم ذكاء اصطناعي */}
              <button
                onClick={() => setSelectedDepartment('ai')}
                className="group relative p-6 sm:p-8 rounded-3xl bg-slate-50 dark:bg-slate-800/60 border-2 border-slate-200 dark:border-slate-700 hover:border-purple-600 dark:hover:border-purple-500 shadow-sm hover:shadow-2xl transition-all duration-200 text-right cursor-pointer flex flex-col justify-between transform hover:-translate-y-1 overflow-hidden"
              >
                <div className="absolute top-0 right-0 w-28 h-28 bg-purple-600/10 rounded-bl-full group-hover:bg-purple-600/20 transition-all pointer-events-none"></div>

                <div>
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-purple-600 to-pink-600 text-white flex items-center justify-center shadow-lg shadow-purple-500/20 mb-6 group-hover:scale-105 transition-transform">
                    <Cpu className="w-7 h-7" />
                  </div>

                  <span className="text-[11px] font-bold text-purple-600 dark:text-purple-400 block mb-1">
                    تخصص الذكاء الاصطناعي
                  </span>
                  <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors mb-2">
                    قسم ذكاء اصطناعي
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-6">
                    تعلم الآلة، التعلم العميق، معالجة اللغات الطبيعية (NLP)، رؤية الحاسوب، ونماذج المحولات والذكاء التوليدي.
                  </p>
                </div>

                <div className="pt-4 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs font-bold text-purple-600 dark:text-purple-400">
                  <span>دخول القسم وتحديد الترم</span>
                  <ArrowLeft className="w-4 h-4 transform group-hover:-translate-x-1.5 transition-transform" />
                </div>
              </button>

              {/* DEPARTMENT 3: قسم أمن سيبراني */}
              <button
                onClick={() => setSelectedDepartment('cyber')}
                className="group relative p-6 sm:p-8 rounded-3xl bg-slate-50 dark:bg-slate-800/60 border-2 border-slate-200 dark:border-slate-700 hover:border-emerald-600 dark:hover:border-emerald-500 shadow-sm hover:shadow-2xl transition-all duration-200 text-right cursor-pointer flex flex-col justify-between transform hover:-translate-y-1 overflow-hidden"
              >
                <div className="absolute top-0 right-0 w-28 h-28 bg-emerald-600/10 rounded-bl-full group-hover:bg-emerald-600/20 transition-all pointer-events-none"></div>

                <div>
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-600 text-white flex items-center justify-center shadow-lg shadow-emerald-500/20 mb-6 group-hover:scale-105 transition-transform">
                    <ShieldAlert className="w-7 h-7" />
                  </div>

                  <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 block mb-1">
                    تخصص الأمن الرقمي
                  </span>
                  <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors mb-2">
                    قسم أمن سيبراني
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-6">
                    حماية الشبكات، التشفير التطبيقي، اختبار الاختراق الأخلاقي، التحقيق الجنائي الرقمي، والاستجابة للحوادث.
                  </p>
                </div>

                <div className="pt-4 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs font-bold text-emerald-600 dark:text-emerald-400">
                  <span>دخول القسم وتحديد الترم</span>
                  <ArrowLeft className="w-4 h-4 transform group-hover:-translate-x-1.5 transition-transform" />
                </div>
              </button>

            </div>
          </section>
        ) : !selectedSemester ? (
          /* =============================================================== */
          /* STAGE 2: SEMESTER SELECTION (الترم الأول والترم الثاني)          */
          /* =============================================================== */
          <section className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-10 border border-slate-200 dark:border-slate-800 shadow-xl my-6">
            <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-100 dark:border-slate-800">
              <button
                onClick={() => setSelectedDepartment(null)}
                className="inline-flex items-center gap-2 text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
              >
                <ArrowRight className="w-4 h-4" />
                <span>العودة لاختيار قسم آخر</span>
              </button>
              
              <div className="text-xs font-bold px-3 py-1 rounded-lg bg-blue-50 dark:bg-blue-950/50 text-blue-700 dark:text-blue-300">
                القسم المختار: {currentDeptInfo?.name}
              </div>
            </div>

            <div className="text-center max-w-xl mx-auto mb-8">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800 rounded-lg text-xs font-bold mb-3">
                <Calendar className="w-3.5 h-3.5 text-amber-500" />
                <span>الخطوة 2 من 2: اختيار الفصل الدراسي</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
                اختر الفصل الدراسي (الترم)
              </h2>
              <p className="mt-2 text-xs sm:text-sm text-slate-600 dark:text-slate-400">
                اختر الترم الأول أو الترم الثاني لعرض المواد المسجلة الخاصة به:
              </p>
            </div>

            {/* The 2 Semester Big Buttons */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
              
              {/* SEMESTER 1 */}
              <button
                onClick={() => setSelectedSemester('sem-1')}
                className="group relative p-8 rounded-3xl bg-slate-50 dark:bg-slate-800/60 border-2 border-slate-200 dark:border-slate-700 hover:border-blue-600 dark:hover:border-blue-500 shadow-sm hover:shadow-xl transition-all text-right cursor-pointer flex flex-col justify-between transform hover:-translate-y-1"
              >
                <div>
                  <div className="w-14 h-14 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-lg shadow-blue-500/20 mb-6 group-hover:scale-105 transition-transform">
                    <Calendar className="w-7 h-7" />
                  </div>
                  <span className="text-[11px] font-bold text-blue-600 dark:text-blue-400 block mb-1">
                    الفصل الدراسي الأول
                  </span>
                  <h3 className="text-2xl font-black text-slate-900 dark:text-white group-hover:text-blue-600 transition-colors mb-2">
                    الترم الأول
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-6">
                    تصفح محاضرات، سكاشن، تكليفات، وملخصات الترم الأول الخاصة بـ {currentDeptInfo?.name}.
                  </p>
                </div>

                <div className="pt-4 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs font-bold text-blue-600 dark:text-blue-400">
                  <span>فتح مواد الترم الأول</span>
                  <ArrowLeft className="w-4 h-4 transform group-hover:-translate-x-1.5 transition-transform" />
                </div>
              </button>

              {/* SEMESTER 2 */}
              <button
                onClick={() => setSelectedSemester('sem-2')}
                className="group relative p-8 rounded-3xl bg-slate-50 dark:bg-slate-800/60 border-2 border-slate-200 dark:border-slate-700 hover:border-emerald-600 dark:hover:border-emerald-500 shadow-sm hover:shadow-xl transition-all text-right cursor-pointer flex flex-col justify-between transform hover:-translate-y-1"
              >
                <div>
                  <div className="w-14 h-14 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-lg shadow-emerald-500/20 mb-6 group-hover:scale-105 transition-transform">
                    <Calendar className="w-7 h-7" />
                  </div>
                  <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 block mb-1">
                    الفصل الدراسي الثاني
                  </span>
                  <h3 className="text-2xl font-black text-slate-900 dark:text-white group-hover:text-emerald-600 transition-colors mb-2">
                    الترم الثاني
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-6">
                    تصفح محاضرات، سكاشن، تكليفات، وملخصات الترم الثاني الخاصة بـ {currentDeptInfo?.name}.
                  </p>
                </div>

                <div className="pt-4 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs font-bold text-emerald-600 dark:text-emerald-400">
                  <span>فتح مواد الترم الثاني</span>
                  <ArrowLeft className="w-4 h-4 transform group-hover:-translate-x-1.5 transition-transform" />
                </div>
              </button>

            </div>
          </section>
        ) : (
          /* =============================================================== */
          /* STAGE 3: CONTENT VIEW FOR CHOSEN DEPARTMENT & SEMESTER          */
          /* =============================================================== */
          <div>
            
            {/* Quick Department & Semester Bar */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm mb-6 flex flex-wrap items-center justify-between gap-4">
              
              <div className="flex flex-wrap items-center gap-3">
                {/* Active Department Badge + Switcher */}
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-500 dark:text-slate-400">القسم:</span>
                  <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
                    {DEPARTMENTS.map(d => (
                      <button
                        key={d.id}
                        onClick={() => setSelectedDepartment(d.id)}
                        className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                          selectedDepartment === d.id
                            ? 'bg-blue-600 text-white shadow-xs'
                            : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                        }`}
                      >
                        {d.shortName}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Active Semester Tabs */}
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-500 dark:text-slate-400">الفصل:</span>
                  <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
                    {SEMESTERS.map(s => (
                      <button
                        key={s.id}
                        onClick={() => setSelectedSemester(s.id)}
                        className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                          selectedSemester === s.id
                            ? 'bg-amber-600 text-white shadow-xs'
                            : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                        }`}
                      >
                        {s.shortName}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Reset to see all departments */}
              <button
                onClick={() => {
                  setSelectedDepartment(null);
                  setSelectedSemester(null);
                }}
                className="text-xs font-bold text-slate-500 hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400 transition-colors flex items-center gap-1"
              >
                <span>تغيير القسم والتخصص</span>
                <ChevronLeft className="w-4 h-4" />
              </button>

            </div>

            {/* Categories Navigation Bar (المحاضرات، السكاشن، التكليفات، الملخصات) */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-2.5 border border-slate-200 dark:border-slate-800 shadow-sm mb-6">
              <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
                {categories.map((cat) => {
                  const count = yearContent.filter(i => {
                    const matchDept = !selectedDepartment || i.departmentId === 'all' || i.departmentId === selectedDepartment;
                    const matchSem = !selectedSemester || i.semesterId === 'all' || i.semesterId === selectedSemester;
                    return matchDept && matchSem && i.categoryId === cat.id;
                  }).length;

                  return (
                    <button
                      key={cat.id}
                      onClick={() => {
                        setActiveCategory(cat.id);
                        setFilterOfflineOnly(false);
                        setFilterDeadlinesOnly(false);
                      }}
                      className={`flex items-center gap-2 px-5 py-3 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                        activeCategory === cat.id && !filterOfflineOnly && !filterDeadlinesOnly
                          ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                          : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                    >
                      <span>{cat.title}</span>
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-mono ${
                        activeCategory === cat.id && !filterOfflineOnly && !filterDeadlinesOnly
                          ? 'bg-blue-700 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
                      }`}>
                        {count}
                      </span>
                    </button>
                  );
                })}

                {/* Offline Filter Button */}
                <button
                  onClick={() => {
                    setFilterOfflineOnly(!filterOfflineOnly);
                    setFilterDeadlinesOnly(false);
                  }}
                  className={`flex items-center gap-2 px-4 py-3 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap border ${
                    filterOfflineOnly
                      ? 'bg-emerald-600 text-white border-emerald-600 shadow-md'
                      : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                  }`}
                >
                  <BookmarkCheck className="w-4 h-4" />
                  <span>المحفوظ بدون إنترنت ({savedOfflineIds.size})</span>
                </button>
              </div>
            </div>

            {/* Filter Bar: Subjects, Search Query */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm mb-6 flex flex-col sm:flex-row items-center justify-between gap-4">
              
              {/* Subjects Pills */}
              <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto pb-2 sm:pb-0 scrollbar-none">
                <button
                  onClick={() => setSelectedSubject('all')}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-colors cursor-pointer ${
                    selectedSubject === 'all'
                      ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  جميع المواد
                </button>

                {subjectsList.map((subName) => (
                  <button
                    key={subName}
                    onClick={() => setSelectedSubject(subName)}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-colors cursor-pointer ${
                      selectedSubject === subName
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    {subName}
                  </button>
                ))}
              </div>

              {/* Search in this category */}
              <div className="relative w-full sm:w-72">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="ابحث في هذا القسم والمادة..."
                  className="w-full pl-9 pr-9 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute left-2.5 top-2 text-[10px] bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 px-1.5 py-0.5 rounded"
                  >
                    مسح
                  </button>
                )}
              </div>

            </div>

            {/* CONTENT CARDS GRID */}
            {displayItems.length === 0 ? (
              <div className="bg-white dark:bg-slate-900 rounded-3xl p-12 text-center border border-slate-200 dark:border-slate-800 shadow-sm my-6">
                <FolderOpen className="w-12 h-12 text-slate-400 mx-auto mb-3" />
                <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">
                  لا يوجد محتوى مسجل حالياً
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto mb-6">
                  لم يتم إضافة محتوى في هذا القسم والفصل الدراسي بعد، أو لا توجد نتائج تطابق بحثك.
                </p>
                {canUpload && (
                  <button
                    onClick={() => onAddNewContent(yearId, activeCategory)}
                    className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md transition-colors cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>إضافة محتوى في {currentDeptInfo?.name}</span>
                  </button>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {displayItems.map((item) => {
                  const isSaved = savedOfflineIds.has(item.id);
                  const isAssignment = !!item.dueDate;

                  return (
                    <div
                      key={item.id}
                      onClick={() => onOpenContent(item)}
                      className="group bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 hover:border-blue-500 dark:hover:border-blue-500 shadow-sm hover:shadow-xl transition-all duration-200 overflow-hidden flex flex-col justify-between cursor-pointer"
                    >
                      {/* Card Content Top */}
                      <div className="p-6">
                        
                        {/* Tags Header */}
                        <div className="flex items-center justify-between gap-2 mb-3">
                          <span className="text-[11px] font-bold text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-900/40 px-2.5 py-1 rounded-lg">
                            {item.subject}
                          </span>

                          <div className="flex items-center gap-1.5">
                            {item.contentType === 'file' && (
                              <span className="text-[10px] font-bold text-purple-700 dark:text-purple-300 bg-purple-50 dark:bg-purple-950/50 px-2 py-0.5 rounded-md flex items-center gap-1">
                                <FileText className="w-3 h-3" />
                                <span>PDF</span>
                              </span>
                            )}
                            {item.contentType === 'youtube' && (
                              <span className="text-[10px] font-bold text-red-700 dark:text-red-300 bg-red-50 dark:bg-red-950/50 px-2 py-0.5 rounded-md flex items-center gap-1">
                                <Play className="w-3 h-3" />
                                <span>فيديو</span>
                              </span>
                            )}
                            {item.contentType === 'link' && (
                              <span className="text-[10px] font-bold text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/50 px-2 py-0.5 rounded-md flex items-center gap-1">
                                <ExternalLink className="w-3 h-3" />
                                <span>رابط</span>
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Deadline Tag if exists */}
                        {item.dueDate && (
                          <div className="mb-3 px-3 py-1.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/50 text-amber-800 dark:text-amber-300 text-[11px] font-bold flex items-center justify-between">
                            <span className="flex items-center gap-1.5">
                              <Clock className="w-3.5 h-3.5 animate-pulse" />
                              <span>موعد التسليم:</span>
                            </span>
                            <span className="font-mono">{formatDate(item.dueDate)}</span>
                          </div>
                        )}

                        {/* Title */}
                        <h4 className="text-base font-black text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors line-clamp-2 mb-2 leading-snug">
                          {item.title}
                        </h4>

                        {/* Description */}
                        <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2 leading-relaxed mb-4">
                          {item.description}
                        </p>

                        {/* Metadata: ONLY ADMIN SEES PUBLISHER NAME! */}
                        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
                          {isAdmin ? (
                            <span className="text-blue-600 dark:text-blue-400 font-bold">
                              الناشر: {item.uploaderName}
                            </span>
                          ) : (
                            <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-medium">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>محتوى معتمد</span>
                            </span>
                          )}

                          <span className="font-mono">
                            {formatDate(item.createdAt)}
                          </span>
                        </div>

                      </div>

                      {/* Card Action Buttons Bar */}
                      <div className="px-5 py-3 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2" onClick={(e) => e.stopPropagation()}>
                        
                        <div className="flex items-center gap-1.5">
                          {/* Direct External Download Button */}
                          <button
                            onClick={(e) => handleDirectDownload(item, e)}
                            className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:text-blue-600 hover:bg-white dark:hover:bg-slate-700 transition-colors shadow-xs"
                            title="تحميل مباشر من الخارج"
                          >
                            <Download className="w-4 h-4" />
                          </button>

                          {/* Standalone File View button */}
                          {item.contentType === 'file' && (
                            <button
                              onClick={() => setStandaloneItem(item)}
                              className="px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-600 text-[11px] font-bold shadow-xs transition-colors border border-slate-200 dark:border-slate-600 flex items-center gap-1"
                              title="عرض الملف لوحده بملء الشاشة مع القلم والأدوات"
                            >
                              <Maximize2 className="w-3.5 h-3.5 text-amber-500" />
                              <span>عرض لوحده</span>
                            </button>
                          )}

                          {/* Offline toggle */}
                          <button
                            onClick={() => toggleSaveOffline(item)}
                            className={`p-2 rounded-xl transition-colors shadow-xs ${
                              isSaved
                                ? 'bg-emerald-600 text-white'
                                : 'text-slate-600 dark:text-slate-300 hover:text-emerald-600 hover:bg-white dark:hover:bg-slate-700'
                            }`}
                            title={isSaved ? 'محفوظ بدون إنترنت' : 'حفظ بدون إنترنت'}
                          >
                            {isSaved ? <BookmarkCheck className="w-4 h-4" /> : <Bookmark className="w-4 h-4" />}
                          </button>
                        </div>

                        {/* Admin / Edit / Delete */}
                        <div className="flex items-center gap-1">
                          {canEdit && onEditContent && (
                            <button
                              onClick={() => onEditContent(item)}
                              className="p-1.5 text-slate-400 hover:text-blue-600 rounded-lg hover:bg-white dark:hover:bg-slate-700"
                              title="تعديل المحتوى"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {canDelete && (
                            <button
                              onClick={() => setItemToDelete({ id: item.id, title: item.title })}
                              className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg hover:bg-white dark:hover:bg-slate-700"
                              title="حذف المحتوى نهائياً"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>

                      </div>

                    </div>
                  );
                })}
              </div>
            )}

          </div>
        )}

      </div>

      {/* Standalone Interactive PDF Viewer Modal */}
      {standaloneItem && (
        <div className="fixed inset-0 z-50 bg-slate-950 text-white">
          <PDFInteractiveViewer
            item={standaloneItem}
            isStandalone={true}
            isAdmin={isAdmin}
            onClose={() => setStandaloneItem(null)}
          />
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <DeleteConfirmationModal
        isOpen={!!itemToDelete}
        title={itemToDelete?.title || ''}
        itemType="content"
        onClose={() => setItemToDelete(null)}
        onConfirm={handleConfirmDelete}
      />

    </div>
  );
};
