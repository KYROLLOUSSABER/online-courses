import React from 'react';
import { Trash2, AlertTriangle, X } from 'lucide-react';

interface DeleteConfirmationModalProps {
  isOpen: boolean;
  itemTitle?: string;
  title?: string;
  itemType?: string;
  onConfirm: () => void;
  onCancel?: () => void;
  onClose?: () => void;
}

export const DeleteConfirmationModal: React.FC<DeleteConfirmationModalProps> = ({
  isOpen,
  itemTitle,
  title,
  itemType = 'content',
  onConfirm,
  onCancel,
  onClose
}) => {
  if (!isOpen) return null;

  const displayTitle = itemTitle || title || 'هذا العنصر';
  const handleDismiss = () => {
    if (onCancel) onCancel();
    else if (onClose) onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 text-right animate-in fade-in duration-100" dir="rtl">
      <div 
        className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-7 shadow-2xl animate-in zoom-in-95 text-slate-900 dark:text-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <div className="w-12 h-12 rounded-2xl bg-red-100 dark:bg-red-950/60 text-red-600 dark:text-red-400 flex items-center justify-center">
            <Trash2 className="w-6 h-6" />
          </div>

          <button
            type="button"
            onClick={handleDismiss}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <h3 className="text-lg font-black text-slate-900 dark:text-white mb-2">
          تأكيد الحذف النهائي
        </h3>

        <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-4">
          هل أنت متأكد من رغبتك في حذف:
          <strong className="block text-slate-900 dark:text-white mt-1.5 p-3 bg-slate-100 dark:bg-slate-800 rounded-xl font-bold truncate text-sm">
            {displayTitle}
          </strong>
        </p>

        <p className="text-[11px] text-amber-800 dark:text-amber-300 mb-6 bg-amber-50 dark:bg-amber-950/40 p-3 rounded-xl border border-amber-200 dark:border-amber-900/50 flex items-center gap-2 font-medium">
          <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600" />
          <span>سيتم مسح هذا العنصر نهائياً ولن يعود للظهور مجدداً حتى بعد إعادة تحميل الصفحة (Refresh).</span>
        </p>

        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={handleDismiss}
            className="px-4 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl transition cursor-pointer"
          >
            إلغاء التراجع
          </button>
          
          <button
            type="button"
            onClick={() => {
              onConfirm();
              handleDismiss();
            }}
            className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl shadow-lg shadow-red-500/20 transition cursor-pointer flex items-center gap-1.5"
          >
            <Trash2 className="w-4 h-4" />
            <span>نعم، حذف نهائي الآن</span>
          </button>
        </div>
      </div>
    </div>
  );
};
