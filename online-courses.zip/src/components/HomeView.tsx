import React, { useState, useMemo } from 'react';
import { AcademicYearId, ContentItem, CategoryDefinition } from '../types';
import { ACADEMIC_YEARS } from '../data/mockData';
import { StorageService } from '../services/storage';
import { OfflineStorageService } from '../services/offlineStorage';
import { PWAInstallButton } from './PWAInstallButton';
import { 
  GraduationCap, 
  BookOpen, 
  Layers, 
  Award, 
  Search, 
  Video, 
  Code, 
  FileCheck, 
  BookMarked, 
  ArrowLeft,
  Sparkles,
  FileText,
  Clock,
  Bookmark,
  Bell,
  Smartphone,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';

interface HomeViewProps {
  contentList: ContentItem[];
  onSelectYear: (yearId: AcademicYearId) => void;
  onOpenContent: (item: ContentItem) => void;
  onNavigateAdmin: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  contentList,
  onSelectYear,
  onOpenContent,
  onNavigateAdmin
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  // Calculate counts for each year
  const getYearStats = (yearId: AcademicYearId) => {
    const yearItems = contentList.filter(item => item.yearId === yearId);
    return {
      total: yearItems.length,
      lectures: yearItems.filter(i => i.categoryId === 'lectures').length,
      sections: yearItems.filter(i => i.categoryId === 'sections').length,
      assignments: yearItems.filter(i => i.categoryId === 'assignments').length,
      summaries: yearItems.filter(i => i.categoryId === 'summaries').length,
    };
  };

  // Search filtered results
  const filteredItems = searchQuery.trim()
    ? contentList.filter(item =>
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  // Urgent upcoming deadlines across all years
  const upcomingDeadlines = useMemo(() => {
    return contentList
      .filter(item => item.dueDate)
      .sort((a, b) => new Date(a.dueDate!).getTime() - new Date(b.dueDate!).getTime())
      .slice(0, 4);
  }, [contentList]);

  // Offline items count
  const offlineCount = OfflineStorageService.getCount();

  const iconsMap = {
    GraduationCap,
    BookOpen,
    Layers,
    Award
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 pb-20 transition-colors duration-200">
      
      {/* Hero Section */}
      <section className="relative bg-slate-900 text-white overflow-hidden border-b border-slate-800">
        <div className="absolute inset-0 opacity-20 pointer-events-none">
          <img
            src="/src/assets/images/online_courses_hero_1791831240896.jpg"
            alt="Study Library"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/80 to-transparent"></div>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-20">
          <div className="max-w-3xl text-right">
            
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-500/10 border border-blue-400/20 text-blue-300 text-xs font-bold rounded-lg mb-4">
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              <span>البوابة الرسمية للمحتوى الجامعي والمحاضرات للفرق الأربعة</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight leading-tight">
              منصة <span className="text-blue-400">Online Courses</span> للمحاضرات والسكاشن
            </h1>
            
            <p className="mt-4 text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl font-normal">
              مرجعك الجامعي الشامل لجميع الفرق الدراسية. تصفح وحمل المحاضرات المسجلة عبر يوتيوب، مذكرات السكاشن، تكليفات العملي بصيغة PDF، مع إمكانية التشغيل بدون إنترنت ومساعد ذكاء اصطناعي للملخصات والامتحانات.
            </p>

            {/* Global Search Bar */}
            <div className="mt-8 relative max-w-xl">
              <div className="relative flex items-center">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="ابحث عن مادة، عنوان محاضرة، سكشن، أو ملخص..."
                  className="w-full pl-10 pr-12 py-3.5 bg-slate-800/90 border border-slate-700 rounded-xl text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm shadow-inner text-right"
                />
                <Search className="w-5 h-5 text-slate-400 absolute right-4 pointer-events-none" />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute left-3 text-xs text-slate-400 hover:text-white px-2 py-1 bg-slate-700 rounded"
                  >
                    مسح
                  </button>
                )}
              </div>

              {/* Live Search Results Dropdown */}
              {searchQuery.trim() && (
                <div className="absolute z-30 top-full mt-2 w-full bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden max-h-96 overflow-y-auto">
                  <div className="p-3 bg-slate-100 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-600 dark:text-slate-300 flex justify-between items-center">
                    <span>نتائج البحث ({filteredItems.length})</span>
                    <span>اضغط على أي عنصر للعرض الفوري</span>
                  </div>
                  {filteredItems.length === 0 ? (
                    <div className="p-6 text-center text-slate-500 dark:text-slate-400 text-sm">
                      لم يتم العثور على محتوى يطابق &quot;{searchQuery}&quot;
                    </div>
                  ) : (
                    <div className="divide-y divide-slate-100 dark:divide-slate-800">
                      {filteredItems.map(item => (
                        <button
                          key={item.id}
                          onClick={() => {
                            setSearchQuery('');
                            onOpenContent(item);
                          }}
                          className="w-full text-right p-3.5 hover:bg-blue-50 dark:hover:bg-slate-800/60 flex items-start gap-3 transition-colors cursor-pointer"
                        >
                          <div className="mt-1 p-2 rounded-lg bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300 shrink-0">
                            {item.contentType === 'youtube' && <Video className="w-4 h-4" />}
                            {item.contentType === 'file' && <FileText className="w-4 h-4" />}
                            {item.contentType === 'link' && <BookMarked className="w-4 h-4" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="text-sm font-bold text-slate-900 dark:text-white truncate">
                              {item.title}
                            </div>
                            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                              <span>{item.subject}</span>
                              <span aria-hidden="true">·</span>
                              <span>
                                {item.yearId === 'year-1' && 'الفرقة الأولى'}
                                {item.yearId === 'year-2' && 'الفرقة الثانية'}
                                {item.yearId === 'year-3' && 'الفرقة الثالثة'}
                                {item.yearId === 'year-4' && 'الفرقة الرابعة'}
                              </span>
                            </div>
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

          </div>
        </div>
      </section>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10 -mt-8 relative z-20">
        
        {/* Main 4 Big Buttons Section (الاربع زراير الكبار) */}
        <section className="bg-white dark:bg-slate-900 rounded-3xl shadow-xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 transition-colors">
          
          <div className="text-center max-w-2xl mx-auto mb-8">
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
              اختر الفرقة الدراسية
            </h2>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
              اضغط على أحد الأزرار الكبيرة للدخول مباشرة إلى المحاضرات، السكاشن، التكليفات، والملخصات
            </p>
          </div>

          {/* The 4 Big Year Buttons */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {ACADEMIC_YEARS.map((year) => {
              const stats = getYearStats(year.id);
              const IconComp = iconsMap[year.iconName as keyof typeof iconsMap] || GraduationCap;
              
              return (
                <button
                  key={year.id}
                  onClick={() => onSelectYear(year.id)}
                  className="group relative text-right p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-800/80 border-2 border-slate-200 dark:border-slate-700 hover:border-blue-600 dark:hover:border-blue-500 shadow-md hover:shadow-2xl transition-all duration-200 flex flex-col justify-between cursor-pointer overflow-hidden transform hover:-translate-y-1"
                >
                  {/* Decorative Subtle Background Glow */}
                  <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${year.accentBg} opacity-10 rounded-bl-full group-hover:opacity-20 transition-opacity pointer-events-none`}></div>

                  <div>
                    {/* Header Row: Icon + Title */}
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-4">
                        <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${year.accentBg} text-white flex items-center justify-center shadow-lg shadow-blue-500/10 group-hover:scale-105 transition-transform`}>
                          <IconComp className="w-7 h-7" />
                        </div>
                        <div>
                          <span className="text-xs font-bold text-slate-400 block mb-0.5">
                            المستوى الدراسي #{year.orderNumber}
                          </span>
                          <h3 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                            {year.title}
                          </h3>
                        </div>
                      </div>

                      {/* Open Badge / Arrow */}
                      <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-700 group-hover:bg-blue-600 group-hover:text-white flex items-center justify-center text-slate-600 dark:text-slate-300 transition-colors shrink-0">
                        <ArrowLeft className="w-5 h-5 transform group-hover:-translate-x-1 transition-transform" />
                      </div>
                    </div>

                    {/* Description */}
                    <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mb-4 leading-relaxed">
                      {year.description}
                    </p>

                    {/* Academic Departments & Semesters Available in this Year */}
                    <div className="flex flex-wrap items-center gap-1.5 mb-5">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-blue-50 dark:bg-blue-950/50 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-900/40">
                        💻 قسم علوم حاسب
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-purple-50 dark:bg-purple-950/50 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-900/40">
                        🤖 قسم ذكاء اصطناعي
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-900/40">
                        🛡️ قسم أمن سيبراني
                      </span>
                      <span className="text-[10px] font-semibold text-slate-400">
                        • الترم الأول والترم الثاني
                      </span>
                    </div>
                  </div>

                  {/* Categories Breakdown (محاضرة، سكشن، تكليفات، ملخصات) */}
                  <div className="pt-4 border-t border-slate-100 dark:border-slate-700/60 grid grid-cols-2 sm:grid-cols-4 gap-2">
                    
                    <div className="bg-slate-50 dark:bg-slate-900/50 p-2.5 rounded-xl text-center border border-slate-100 dark:border-slate-800">
                      <div className="flex items-center justify-center gap-1 text-blue-600 dark:text-blue-400 mb-1">
                        <Video className="w-3.5 h-3.5" />
                        <span className="text-[11px] font-bold">محاضرات</span>
                      </div>
                      <span className="text-sm font-black text-slate-900 dark:text-white">{stats.lectures}</span>
                    </div>

                    <div className="bg-slate-50 dark:bg-slate-900/50 p-2.5 rounded-xl text-center border border-slate-100 dark:border-slate-800">
                      <div className="flex items-center justify-center gap-1 text-emerald-600 dark:text-emerald-400 mb-1">
                        <Code className="w-3.5 h-3.5" />
                        <span className="text-[11px] font-bold">سكاشن</span>
                      </div>
                      <span className="text-sm font-black text-slate-900 dark:text-white">{stats.sections}</span>
                    </div>

                    <div className="bg-slate-50 dark:bg-slate-900/50 p-2.5 rounded-xl text-center border border-slate-100 dark:border-slate-800">
                      <div className="flex items-center justify-center gap-1 text-amber-600 dark:text-amber-400 mb-1">
                        <FileCheck className="w-3.5 h-3.5" />
                        <span className="text-[11px] font-bold">تكليفات</span>
                      </div>
                      <span className="text-sm font-black text-slate-900 dark:text-white">{stats.assignments}</span>
                    </div>

                    <div className="bg-slate-50 dark:bg-slate-900/50 p-2.5 rounded-xl text-center border border-slate-100 dark:border-slate-800">
                      <div className="flex items-center justify-center gap-1 text-purple-600 dark:text-purple-400 mb-1">
                        <BookMarked className="w-3.5 h-3.5" />
                        <span className="text-[11px] font-bold">ملخصات</span>
                      </div>
                      <span className="text-sm font-black text-slate-900 dark:text-white">{stats.summaries}</span>
                    </div>

                  </div>
                </button>
              );
            })}
          </div>

        </section>

        {/* Upcoming Deadlines Widget if any exist */}
        {upcomingDeadlines.length > 0 && (
          <section className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-md">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center">
                  <Bell className="w-5 h-5 animate-bounce" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-900 dark:text-white">
                    تنبيهات المواعيد النهائية والتكليفات القادمة ⏰
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    أحدث التكليفات والمهام المطلوبة من الفرق مع موعد التسليم
                  </p>
                </div>
              </div>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {upcomingDeadlines.map(item => {
                const yearName = ACADEMIC_YEARS.find(y => y.id === item.yearId)?.title || item.yearId;
                return (
                  <div
                    key={item.id}
                    onClick={() => onOpenContent(item)}
                    className="p-4 rounded-2xl bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 text-right cursor-pointer hover:border-amber-400 transition-all"
                  >
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className="text-[11px] font-bold text-amber-700 dark:text-amber-300 bg-amber-100 dark:bg-amber-900/40 px-2 py-0.5 rounded-md">
                        {yearName}
                      </span>
                      <span className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {new Date(item.dueDate!).toLocaleDateString('ar-EG')}
                      </span>
                    </div>

                    <h4 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white truncate mb-1">
                      {item.title}
                    </h4>
                    <p className="text-[11px] text-slate-600 dark:text-slate-300 truncate">
                      {item.subject}
                    </p>
                    {item.deadlineNote && (
                      <p className="text-[10px] text-amber-800 dark:text-amber-300 mt-2 bg-white/70 dark:bg-slate-800/80 p-1.5 rounded-lg">
                        {item.deadlineNote}
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {/* PWA Phone Install Banner */}
        <PWAInstallButton variant="banner" />

        {/* Features Highlights Row */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs text-right">
            <div className="w-12 h-12 rounded-xl bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-400 flex items-center justify-center mb-4">
              <Bookmark className="w-6 h-6" />
            </div>
            <h4 className="text-base font-bold text-slate-900 dark:text-white mb-2">تشغيل ومذاكرة بدون إنترنت</h4>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              احفظ أي محاضرة أو ملخص أو تكليف بنقرة واحدة لتشغيلها ومراجعتها في أي وقت وبأي مكان بدون اتصال بالإنترنت.
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs text-right">
            <div className="w-12 h-12 rounded-xl bg-indigo-100 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-400 flex items-center justify-center mb-4">
              <Sparkles className="w-6 h-6" />
            </div>
            <h4 className="text-base font-bold text-slate-900 dark:text-white mb-2">مساعد ذكاء اصطناعي أكاديمي</h4>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              تلخيص فوري للمحاضرات، عمل امتحانات تدريبية تفاعلية، والإجابة على الأسئلة، مع إمكانية الفتح في ChatGPT وGemini.
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs text-right">
            <div className="w-12 h-12 rounded-xl bg-purple-100 dark:bg-purple-950/60 text-purple-700 dark:text-purple-400 flex items-center justify-center mb-4">
              <Smartphone className="w-6 h-6" />
            </div>
            <h4 className="text-base font-bold text-slate-900 dark:text-white mb-2">تطبيق مثبت على الهاتف (PWA)</h4>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              ثبت المنصة على هاتفك الذكي (Android أو iPhone) واستمتع بتجربة تطبيق كامل وسريع بدون شريط المتصفح.
            </p>
          </div>
        </section>

      </div>

    </div>
  );
};
