import React from 'react';
import { Logo } from './Logo';
import { AcademicYearId, UserAccount } from '../types';
import { ShieldCheck, LogOut, Moon, Sun, Bookmark } from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';

interface NavbarProps {
  currentView: 'home' | AcademicYearId | 'admin';
  currentUser: UserAccount | null;
  currentTheme: 'light' | 'dark';
  offlineCount?: number;
  onToggleTheme: () => void;
  onNavigateHome: () => void;
  onNavigateYear: (yearId: AcademicYearId) => void;
  onNavigateAdmin: () => void;
  onOpenLoginModal: () => void;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  currentUser,
  currentTheme,
  offlineCount = 0,
  onToggleTheme,
  onNavigateHome,
  onNavigateYear,
  onNavigateAdmin,
  onOpenLoginModal,
  onLogout
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4 sm:gap-8 h-16">
          
          {/* Zone 1: Brand wordmark (single element) */}
          <button
            onClick={onNavigateHome}
            className="flex items-center text-right cursor-pointer hover:opacity-90 transition-opacity whitespace-nowrap shrink-0"
            title="الرئيسية - Online Courses"
          >
            <Logo size="md" />
          </button>

          {/* Zone 2: 4-5 concise single-line text navigation links */}
          <nav className="hidden lg:flex items-center gap-6 text-sm font-semibold text-slate-600 dark:text-slate-300">
            <button
              onClick={onNavigateHome}
              className={`hover:text-blue-600 dark:hover:text-blue-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                currentView === 'home' ? 'text-blue-600 dark:text-blue-400 font-bold border-b-2 border-blue-600 dark:border-blue-400 py-4 -mb-[2px]' : ''
              }`}
            >
              الرئيسية
            </button>
            <button
              onClick={() => onNavigateYear('year-1')}
              className={`hover:text-blue-600 dark:hover:text-blue-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                currentView === 'year-1' ? 'text-blue-600 dark:text-blue-400 font-bold border-b-2 border-blue-600 dark:border-blue-400 py-4 -mb-[2px]' : ''
              }`}
            >
              الفرقة الأولى
            </button>
            <button
              onClick={() => onNavigateYear('year-2')}
              className={`hover:text-blue-600 dark:hover:text-blue-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                currentView === 'year-2' ? 'text-blue-600 dark:text-blue-400 font-bold border-b-2 border-blue-600 dark:border-blue-400 py-4 -mb-[2px]' : ''
              }`}
            >
              الفرقة الثانية
            </button>
            <button
              onClick={() => onNavigateYear('year-3')}
              className={`hover:text-blue-600 dark:hover:text-blue-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                currentView === 'year-3' ? 'text-blue-600 dark:text-blue-400 font-bold border-b-2 border-blue-600 dark:border-blue-400 py-4 -mb-[2px]' : ''
              }`}
            >
              الفرقة الثالثة
            </button>
            <button
              onClick={() => onNavigateYear('year-4')}
              className={`hover:text-blue-600 dark:hover:text-blue-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                currentView === 'year-4' ? 'text-blue-600 dark:text-blue-400 font-bold border-b-2 border-blue-600 dark:border-blue-400 py-4 -mb-[2px]' : ''
              }`}
            >
              الفرقة الرابعة
            </button>
          </nav>

          {/* Zone 3: Actions (Theme Toggle, PWA Install, Offline Badge, and Admin if logged in) */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            
            {/* PWA Mobile Install Button */}
            <PWAInstallButton variant="navbar" />

            {/* Dark / Light Mode Toggle */}
            <button
              onClick={onToggleTheme}
              className="p-2 text-slate-600 dark:text-slate-300 hover:text-amber-500 dark:hover:text-amber-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all cursor-pointer border border-slate-200 dark:border-slate-700/60"
              title={currentTheme === 'dark' ? 'التحويل للوضع النهاري (Light Mode)' : 'التحويل للوضع الليلي (Dark Mode)'}
              aria-label="تبديل الوضع الليلي والنهاري"
            >
              {currentTheme === 'dark' ? (
                <Sun className="w-4 h-4 text-amber-400" />
              ) : (
                <Moon className="w-4 h-4 text-slate-700" />
              )}
            </button>

            {/* Offline Saved Indicator */}
            {offlineCount > 0 && (
              <div 
                className="hidden sm:flex items-center gap-1 px-2.5 py-1.5 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-xs font-bold rounded-xl border border-emerald-200 dark:border-emerald-800"
                title={`${offlineCount} مادة دراسية محفوظة للتشغيل بدون إنترنت`}
              >
                <Bookmark className="w-3.5 h-3.5" />
                <span>{offlineCount} أوفلاين</span>
              </div>
            )}

            {/* Primary Action (Admin/Supervisor if logged in) */}
            {currentUser && (
              <div className="flex items-center gap-2">
                <button
                  onClick={onNavigateAdmin}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl transition-colors whitespace-nowrap cursor-pointer ${
                    currentView === 'admin'
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'bg-slate-900 text-white hover:bg-slate-800 dark:bg-slate-800 dark:hover:bg-slate-700'
                  }`}
                  title="لوحة التحكم"
                >
                  <ShieldCheck className="w-4 h-4 text-blue-300" />
                  <span className="hidden sm:inline">لوحة التحكم ({currentUser.role === 'admin' ? 'المدير' : 'مشرف'})</span>
                  <span className="sm:hidden">الإدارة</span>
                </button>
                <button
                  onClick={onLogout}
                  className="p-1.5 text-slate-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30 rounded-xl transition-colors cursor-pointer"
                  title="تسجيل الخروج"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>

        </div>
      </div>
    </header>
  );
};
