import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  SkipForward, 
  Volume2, 
  VolumeX, 
  Clock, 
  Minimize2, 
  Maximize2, 
  Sparkles, 
  Coffee, 
  CheckCircle,
  X
} from 'lucide-react';

export type PomodoroMode = 'focus' | 'shortBreak' | 'longBreak';

interface PomodoroTimerProps {
  initialMode?: PomodoroMode;
  onSessionComplete?: (completedSessions: number) => void;
  isFloating?: boolean;
  onClose?: () => void;
  className?: string;
}

const MODE_CONFIG: Record<PomodoroMode, { title: string; durationMinutes: number; color: string; badge: string; quote: string }> = {
  focus: {
    title: 'جلسة تركيز ومذاكرة',
    durationMinutes: 25,
    color: 'from-blue-600 to-indigo-600',
    badge: 'bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800',
    quote: 'حافظ على تركيزك الكامل في المحاضرة، كل دقيقة تصنع فارقاً 🚀'
  },
  shortBreak: {
    title: 'استراحة قصيرة',
    durationMinutes: 5,
    color: 'from-emerald-600 to-teal-600',
    badge: 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
    quote: 'خذ نفساً عميقاً، اشرب ماء، وأرح عينيك من الشاشة ☕'
  },
  longBreak: {
    title: 'استراحة طويلة',
    durationMinutes: 15,
    color: 'from-purple-600 to-pink-600',
    badge: 'bg-purple-100 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border-purple-200 dark:border-purple-800',
    quote: 'إنجاز رائع! لقد أكملت 4 دورات تركيز، استمتع باستراحة مستحقة 🌴'
  }
};

// Play audio alert chime via Web Audio API (100% offline, cross-browser)
function playChimeSound() {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();

    const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6 (Major arpeggio)
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.12);

      gain.gain.setValueAtTime(0, ctx.currentTime + idx * 0.12);
      gain.gain.linearRampToValueAtTime(0.2, ctx.currentTime + idx * 0.12 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.12 + 0.4);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(ctx.currentTime + idx * 0.12);
      osc.stop(ctx.currentTime + idx * 0.12 + 0.45);
    });
  } catch {
    // Audio context may be restricted before user gesture
  }
}

export const PomodoroTimer: React.FC<PomodoroTimerProps> = ({
  initialMode = 'focus',
  onSessionComplete,
  isFloating = false,
  onClose,
  className = ''
}) => {
  const [mode, setMode] = useState<PomodoroMode>(initialMode);
  const [timeLeft, setTimeLeft] = useState<number>(MODE_CONFIG[initialMode].durationMinutes * 60);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [completedSessions, setCompletedSessions] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('online_courses_pomodoro_completed');
      return saved ? parseInt(saved, 10) : 0;
    } catch {
      return 0;
    }
  });
  const [isMinimized, setIsMinimized] = useState<boolean>(isFloating);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Switch mode helper
  const handleSwitchMode = (newMode: PomodoroMode) => {
    setIsRunning(false);
    setMode(newMode);
    setTimeLeft(MODE_CONFIG[newMode].durationMinutes * 60);
  };

  // Timer Tick effect
  useEffect(() => {
    if (isRunning) {
      timerRef.current = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            // Timer Finished
            if (soundEnabled) {
              playChimeSound();
            }

            if (mode === 'focus') {
              const newCount = completedSessions + 1;
              setCompletedSessions(newCount);
              try {
                localStorage.setItem('online_courses_pomodoro_completed', newCount.toString());
              } catch {
                // ignore
              }
              onSessionComplete?.(newCount);

              // Auto switch to short break or long break (every 4 sessions)
              const nextMode = newCount % 4 === 0 ? 'longBreak' : 'shortBreak';
              setMode(nextMode);
              return MODE_CONFIG[nextMode].durationMinutes * 60;
            } else {
              // Break finished -> back to focus
              setMode('focus');
              return MODE_CONFIG.focus.durationMinutes * 60;
            }
          }
          return prev - 1;
        });
      }, 1000);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning, mode, soundEnabled, completedSessions, onSessionComplete]);

  // Format MM:SS
  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const formattedTime = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

  const totalDuration = MODE_CONFIG[mode].durationMinutes * 60;
  const progressPercentage = ((totalDuration - timeLeft) / totalDuration) * 100;

  // Toggle play/pause
  const togglePlay = () => {
    setIsRunning(!isRunning);
  };

  // Reset timer
  const handleReset = () => {
    setIsRunning(false);
    setTimeLeft(MODE_CONFIG[mode].durationMinutes * 60);
  };

  // Skip current session
  const handleSkip = () => {
    setIsRunning(false);
    if (mode === 'focus') {
      const nextMode = (completedSessions + 1) % 4 === 0 ? 'longBreak' : 'shortBreak';
      handleSwitchMode(nextMode);
    } else {
      handleSwitchMode('focus');
    }
  };

  // --------------------------------------------------------------------------
  // MINIMIZED FLOATING BADGE (Non-intrusive while watching video or reading PDF)
  // --------------------------------------------------------------------------
  if (isMinimized) {
    return (
      <div className="fixed bottom-6 left-6 z-50 animate-in fade-in slide-in-from-bottom-4">
        <div className="bg-slate-900/95 dark:bg-slate-900 text-white rounded-2xl shadow-2xl border border-slate-700/80 p-3 flex items-center gap-3 backdrop-blur-md">
          <button
            onClick={togglePlay}
            className={`w-9 h-9 rounded-xl flex items-center justify-center text-white transition-transform active:scale-90 ${
              isRunning ? 'bg-amber-600 hover:bg-amber-700' : 'bg-blue-600 hover:bg-blue-700'
            }`}
            title={isRunning ? 'إيقاف مؤقت' : 'بدء التركيز'}
          >
            {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
          </button>

          <div className="text-right cursor-pointer" onClick={() => setIsMinimized(false)}>
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-bold text-slate-300">
                {mode === 'focus' ? '🎯 تركيز' : '☕ استراحة'}
              </span>
              <span className="text-xs font-black font-mono text-blue-400">
                {formattedTime}
              </span>
            </div>
            <div className="text-[10px] text-slate-400">
              🍅 {completedSessions} جلسات منجزة
            </div>
          </div>

          <button
            onClick={() => setIsMinimized(false)}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            title="تكبير أداة بومودورو"
          >
            <Maximize2 className="w-4 h-4" />
          </button>

          {onClose && (
            <button
              onClick={onClose}
              className="p-1 text-slate-500 hover:text-slate-300 rounded-lg hover:bg-slate-800"
              title="إغلاق"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    );
  }

  // --------------------------------------------------------------------------
  // FULL EXPANDED TIMER CARD
  // --------------------------------------------------------------------------
  return (
    <div className={`bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden transition-all text-right ${className}`}>
      {/* Top Header */}
      <div className={`px-5 py-3.5 bg-gradient-to-r ${MODE_CONFIG[mode].color} text-white flex items-center justify-between`}>
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-white/90 animate-pulse" />
          <h3 className="text-xs sm:text-sm font-black">
            مؤقت المذاكرة والتركيز (Pomodoro)
          </h3>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
            title={soundEnabled ? 'كتم التنبيه الصوتي' : 'تشغيل التنبيه الصوتي'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          <button
            onClick={() => setIsMinimized(true)}
            className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
            title="تصغير إلى ودجت عائم أثناء قراءة المحاضرة"
          >
            <Minimize2 className="w-4 h-4" />
          </button>

          {onClose && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
              title="إغلاق"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      <div className="p-5 sm:p-6">
        
        {/* Mode Selector Tabs */}
        <div className="grid grid-cols-3 gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl mb-6">
          <button
            onClick={() => handleSwitchMode('focus')}
            className={`py-2 px-2 text-xs font-bold rounded-xl transition-all cursor-pointer text-center ${
              mode === 'focus'
                ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            🎯 25 دقيقة تركيز
          </button>

          <button
            onClick={() => handleSwitchMode('shortBreak')}
            className={`py-2 px-2 text-xs font-bold rounded-xl transition-all cursor-pointer text-center ${
              mode === 'shortBreak'
                ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            ☕ 5 دقائق راحة
          </button>

          <button
            onClick={() => handleSwitchMode('longBreak')}
            className={`py-2 px-2 text-xs font-bold rounded-xl transition-all cursor-pointer text-center ${
              mode === 'longBreak'
                ? 'bg-white dark:bg-slate-900 text-purple-600 dark:text-purple-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            🌴 15 دقيقة راحة
          </button>
        </div>

        {/* Big Circular/Digital Clock Display */}
        <div className="flex flex-col items-center justify-center my-4">
          <div className="relative w-44 h-44 sm:w-52 sm:h-52 flex items-center justify-center">
            {/* SVG Progress Circle */}
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="50%"
                cy="50%"
                r="42%"
                className="stroke-slate-100 dark:stroke-slate-800 fill-transparent"
                strokeWidth="10"
              />
              <circle
                cx="50%"
                cy="50%"
                r="42%"
                className={`fill-transparent transition-all duration-500 ${
                  mode === 'focus' 
                    ? 'stroke-blue-600' 
                    : mode === 'shortBreak' 
                    ? 'stroke-emerald-600' 
                    : 'stroke-purple-600'
                }`}
                strokeWidth="10"
                strokeDasharray={`${2 * Math.PI * 88}`}
                strokeDashoffset={`${2 * Math.PI * 88 * (1 - progressPercentage / 100)}`}
                strokeLinecap="round"
              />
            </svg>

            {/* Inner Content */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="text-3xl sm:text-4xl font-black font-mono tracking-tight text-slate-900 dark:text-white">
                {formattedTime}
              </span>
              <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 mt-1">
                {MODE_CONFIG[mode].title}
              </span>
            </div>
          </div>

          {/* Motivational Quote */}
          <p className="text-[11px] text-slate-500 dark:text-slate-400 text-center max-w-xs mt-3 leading-relaxed">
            {MODE_CONFIG[mode].quote}
          </p>
        </div>

        {/* Controls Row */}
        <div className="flex items-center justify-center gap-3 my-4">
          
          <button
            onClick={handleReset}
            className="w-11 h-11 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 flex items-center justify-center transition-colors cursor-pointer"
            title="إعادة ضبط الوقت"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <button
            onClick={togglePlay}
            className={`px-8 py-3 rounded-2xl text-white font-bold text-sm shadow-lg flex items-center gap-2 transition-all transform active:scale-95 cursor-pointer ${
              isRunning
                ? 'bg-amber-600 hover:bg-amber-700 shadow-amber-500/20'
                : 'bg-blue-600 hover:bg-blue-700 shadow-blue-500/20'
            }`}
          >
            {isRunning ? (
              <>
                <Pause className="w-5 h-5" />
                <span>إيقاف مؤقت</span>
              </>
            ) : (
              <>
                <Play className="w-5 h-5 ml-1" />
                <span>ابدأ التركيز</span>
              </>
            )}
          </button>

          <button
            onClick={handleSkip}
            className="w-11 h-11 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 flex items-center justify-center transition-colors cursor-pointer"
            title="تخطي للجلسة التالية"
          >
            <SkipForward className="w-4 h-4" />
          </button>

        </div>

        {/* Footer: Session Counter & Target */}
        <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-1.5 font-bold text-slate-700 dark:text-slate-300">
            <span>🍅 جلسات اليوم المكتملة:</span>
            <span className="font-mono text-blue-600 dark:text-blue-400 text-sm">{completedSessions}</span>
          </div>

          <button
            onClick={() => setIsMinimized(true)}
            className="text-[11px] text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 cursor-pointer"
          >
            <span>تصغير وتصفح المحاضرة</span>
            <Minimize2 className="w-3 h-3" />
          </button>
        </div>

      </div>
    </div>
  );
};
