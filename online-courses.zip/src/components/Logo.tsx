import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showSubtitle?: boolean;
}

export const Logo: React.FC<LogoProps> = ({
  className = '',
  size = 'md',
  showSubtitle = true
}) => {
  const iconSizeClasses = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-12 h-12'
  };

  const titleSizeClasses = {
    sm: 'text-base font-bold',
    md: 'text-lg font-extrabold tracking-tight',
    lg: 'text-2xl font-black tracking-tight'
  };

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* Brand Icon Emblem */}
      <div className={`relative ${iconSizeClasses[size]} shrink-0 rounded-xl bg-gradient-to-br from-blue-600 via-indigo-600 to-blue-800 p-0.5 shadow-md shadow-blue-500/20`}>
        <div className="w-full h-full bg-slate-900 rounded-[10px] flex items-center justify-center p-1.5">
          <svg
            viewBox="0 0 40 40"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-full h-full text-blue-400"
          >
            {/* Graduation Cap / Academic Diamond */}
            <path
              d="M20 6L35 14L20 22L5 14L20 6Z"
              fill="currentColor"
              fillOpacity="0.2"
              stroke="currentColor"
              strokeWidth="2.5"
              strokeLinejoin="round"
            />
            {/* Tassel */}
            <path
              d="M32 16V26C32 27.1046 31.1046 28 30 28"
              stroke="#60A5FA"
              strokeWidth="2"
              strokeLinecap="round"
            />
            {/* Open Book Arch Base */}
            <path
              d="M11 20V27C11 28.5 15 31 20 31C25 31 29 28.5 29 27V20"
              stroke="#93C5FD"
              strokeWidth="2.2"
              strokeLinecap="round"
            />
            {/* Center Knowledge Beam */}
            <circle cx="20" cy="14" r="2" fill="#FFFFFF" />
          </svg>
        </div>
      </div>

      {/* Brand Text */}
      <div className="flex flex-col leading-none">
        <div className="flex items-center gap-1.5">
          <span className={`${titleSizeClasses[size]} text-slate-900 font-sans tracking-tight`}>
            Online
          </span>
          <span className={`${titleSizeClasses[size]} text-blue-600 font-sans font-black`}>
            Courses
          </span>
        </div>
        {showSubtitle && (
          <span className="text-[10px] font-medium text-slate-600 tracking-normal mt-0.5">
            المنصة الأكاديمية الشاملة
          </span>
        )}
      </div>
    </div>
  );
};
