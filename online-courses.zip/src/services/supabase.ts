import { createClient } from '@supabase/supabase-js';

// Sanitize URL by removing trailing /rest/v1 or trailing slashes
const RAW_URL = (import.meta.env.VITE_SUPABASE_URL || 'https://qqgynwvqazslfurtajsr.supabase.co').trim();
export const SUPABASE_URL = RAW_URL.replace(/\/rest\/v1\/?$/, '').replace(/\/+$/, '');
export const SUPABASE_ANON_KEY = (
  import.meta.env.VITE_SUPABASE_ANON_KEY || 
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFxZ3lud3ZxYXpzbGZ1cnRhanNyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTMxMTYyNjYsImV4cCI6MjEwODY5MjI2Nn0.87Gm4K_7x5w0vsoJjq02aGrVvhz9gZ9PCkjZYxagLRQ'
).trim();

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
export const BUCKET_NAME = 'course-files';

export interface SupabaseUploadResult {
  success: boolean;
  publicUrl?: string;
  filePath?: string;
  fileName?: string;
  fileSizeMb?: string;
  error?: string;
}

export interface SupabaseStorageStats {
  isConfigured: boolean;
  isConnected: boolean;
  bucketExists: boolean;
  totalFiles: number;
  usedBytes: number;
  usedMb: number;
  totalQuotaMb: number; // 1,000 MB (1GB free tier)
  remainingMb: number;
  percentUsed: number;
  error?: string;
}

export const SupabaseStorageService = {
  /**
   * Check connection and bucket readiness
   */
  async testConnection(): Promise<{ connected: boolean; bucketReady: boolean; message: string }> {
    try {
      const { data, error } = await supabase.storage.getBucket(BUCKET_NAME);
      if (error) {
        // If bucket is not found, connection is working but bucket needs to be created
        if (error.message?.toLowerCase().includes('not found')) {
          return {
            connected: true,
            bucketReady: false,
            message: `الاتصال بـ Supabase ناجح! يرجى التأكد من إنشاء مجلد (Bucket) باسم "${BUCKET_NAME}" في Supabase Storage وجعله Public.`
          };
        }
        return {
          connected: false,
          bucketReady: false,
          message: error.message
        };
      }
      return {
        connected: true,
        bucketReady: true,
        message: 'متصل بسحابة Supabase ومجلد الملفات جاهز للرفع بسعة 1000 ميجابايت!'
      };
    } catch (e: any) {
      return {
        connected: false,
        bucketReady: false,
        message: e?.message || 'فشل الاتصال بـ Supabase'
      };
    }
  },

  /**
   * Upload file directly to Supabase Cloud Storage
   */
  async uploadFile(file: File, folder: string = 'materials'): Promise<SupabaseUploadResult> {
    try {
      // Clean filename and create unique timestamped key
      const timestamp = Date.now();
      const sanitizedName = file.name
        .replace(/[^a-zA-Z0-9._-]/g, '_')
        .replace(/_{2,}/g, '_');
      const filePath = `${folder}/${timestamp}_${sanitizedName}`;

      const { data, error } = await supabase.storage
        .from(BUCKET_NAME)
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: true
        });

      if (error) {
        return {
          success: false,
          error: error.message
        };
      }

      // Retrieve public CDN URL
      const { data: publicData } = supabase.storage
        .from(BUCKET_NAME)
        .getPublicUrl(data.path);

      const sizeInMb = (file.size / (1024 * 1024)).toFixed(2);

      return {
        success: true,
        publicUrl: publicData.publicUrl,
        filePath: data.path,
        fileName: file.name,
        fileSizeMb: `${sizeInMb} ميجابايت`
      };
    } catch (err: any) {
      return {
        success: false,
        error: err?.message || 'حدث خطأ غير متوقع أثناء الرفع إلى Supabase'
      };
    }
  },

  /**
   * Delete file from Supabase Storage
   */
  async deleteFile(filePath: string): Promise<boolean> {
    try {
      const { error } = await supabase.storage.from(BUCKET_NAME).remove([filePath]);
      return !error;
    } catch {
      return false;
    }
  },

  /**
   * Calculate storage usage from Supabase Storage bucket
   */
  async getStorageStats(): Promise<SupabaseStorageStats> {
    const TOTAL_QUOTA_MB = 1000; // 1GB free tier limit on Supabase
    try {
      const { data, error } = await supabase.storage.from(BUCKET_NAME).list('materials', {
        limit: 100,
        offset: 0
      });

      if (error) {
        return {
          isConfigured: true,
          isConnected: true,
          bucketExists: false,
          totalFiles: 0,
          usedBytes: 0,
          usedMb: 0,
          totalQuotaMb: TOTAL_QUOTA_MB,
          remainingMb: TOTAL_QUOTA_MB,
          percentUsed: 0,
          error: error.message
        };
      }

      let totalBytes = 0;
      let totalFiles = 0;

      if (Array.isArray(data)) {
        data.forEach(item => {
          if (item.metadata?.size) {
            totalBytes += item.metadata.size;
            totalFiles += 1;
          }
        });
      }

      const usedMb = Number((totalBytes / (1024 * 1024)).toFixed(2));
      const remainingMb = Number(Math.max(0, TOTAL_QUOTA_MB - usedMb).toFixed(2));
      const percentUsed = Math.min(100, Math.max(0, Math.round((usedMb / TOTAL_QUOTA_MB) * 100)));

      return {
        isConfigured: true,
        isConnected: true,
        bucketExists: true,
        totalFiles,
        usedBytes: totalBytes,
        usedMb,
        totalQuotaMb: TOTAL_QUOTA_MB,
        remainingMb,
        percentUsed
      };
    } catch (e: any) {
      return {
        isConfigured: true,
        isConnected: false,
        bucketExists: false,
        totalFiles: 0,
        usedBytes: 0,
        usedMb: 0,
        totalQuotaMb: TOTAL_QUOTA_MB,
        remainingMb: TOTAL_QUOTA_MB,
        percentUsed: 0,
        error: e?.message
      };
    }
  }
};
