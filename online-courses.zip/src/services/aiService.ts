import { ContentItem, QuizQuestion, AIQuizResult } from '../types';
import { ACADEMIC_YEARS } from '../data/mockData';

export interface AISummaryResult {
  title: string;
  keyPoints: string[];
  summaryText: string;
  importantFormulasOrDefinitions: string[];
  examAdvice: string;
}

export interface AIAskResponse {
  answer: string;
  relatedConcepts: string[];
}

export const AIService = {
  // --------------------------------------------------------------------------
  // 1. Summarize Lecture
  // --------------------------------------------------------------------------
  async summarizeLecture(
    item: ContentItem,
    style: 'brief' | 'detailed' | 'keypoints' = 'detailed'
  ): Promise<AISummaryResult> {
    const yearTitle = ACADEMIC_YEARS.find(y => y.id === item.yearId)?.title || item.yearId;

    try {
      const response = await fetch('/api/ai/lecture-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'summary',
          title: item.title,
          subject: item.subject,
          yearTitle,
          description: item.description,
          summaryStyle: style
        })
      });

      if (response.ok) {
        const data = await response.json();
        if (data.result) {
          return data.result;
        }
      }
    } catch {
      // Server not reachable or network offline, use smart contextual fallback
    }

    // Intelligent pedagogical fallback generator
    return this.generateFallbackSummary(item, yearTitle, style);
  },

  // --------------------------------------------------------------------------
  // 2. Generate Interactive Exam / Quiz
  // --------------------------------------------------------------------------
  async generateQuiz(item: ContentItem, count: number = 5): Promise<AIQuizResult> {
    const yearTitle = ACADEMIC_YEARS.find(y => y.id === item.yearId)?.title || item.yearId;

    try {
      const response = await fetch('/api/ai/lecture-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'quiz',
          title: item.title,
          subject: item.subject,
          yearTitle,
          description: item.description,
          questionCount: count
        })
      });

      if (response.ok) {
        const data = await response.json();
        if (data.result && data.result.questions) {
          return data.result;
        }
      }
    } catch {
      // Use fallback
    }

    return this.generateFallbackQuiz(item, yearTitle, count);
  },

  // --------------------------------------------------------------------------
  // 3. Ask Question in Lecture
  // --------------------------------------------------------------------------
  async askQuestion(item: ContentItem, userQuestion: string): Promise<AIAskResponse> {
    const yearTitle = ACADEMIC_YEARS.find(y => y.id === item.yearId)?.title || item.yearId;

    try {
      const response = await fetch('/api/ai/lecture-action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'ask',
          title: item.title,
          subject: item.subject,
          yearTitle,
          description: item.description,
          userQuestion
        })
      });

      if (response.ok) {
        const data = await response.json();
        if (data.result) {
          return data.result;
        }
      }
    } catch {
      // Use fallback
    }

    return this.generateFallbackAnswer(item, userQuestion);
  },

  // --------------------------------------------------------------------------
  // 4. Generate Ready-to-use Prompt for External AI (ChatGPT / Gemini / Claude)
  // --------------------------------------------------------------------------
  buildExternalPrompt(
    item: ContentItem,
    goal: 'summary' | 'exam' | 'explain' | 'assignment' = 'summary'
  ): { prompt: string; geminiUrl: string; chatGptUrl: string; claudeUrl: string; copilotUrl: string } {
    const yearTitle = ACADEMIC_YEARS.find(y => y.id === item.yearId)?.title || item.yearId;

    let goalPrompt = '';
    if (goal === 'summary') {
      goalPrompt = `قم بتلخيص المحاضرة أعلاه بشكل أكاديمي شامل ومبسط، وقسم التلخيص إلى:
1. المفاهيم الأساسية والتعريفات الجوهرية.
2. النقاط الرئيسية خطوة بخطوة مع شرح موجز لكل منها.
3. أهم القوانين أو النماذج أو الخوارزميات المذكورة.
4. أهم الأسئلة المتوقعة في الامتحان الفصلي والنهائي وإجاباتها النموذجية.`;
    } else if (goal === 'exam') {
      goalPrompt = `بناءً على محتوى هذا المقرر الدراسي، قم بإعداد امتحان تدريبي متكامل يتكون من:
1. 5 أسئلة اختيار من متعدد (MCQ) مع 4 خيارات وتحديد الإجابة الصحيحة مع التعليل.
2. 3 أسئلة صح أو خطأ مع تصحيح الخطأ.
3. سؤالين مقاليين مع الإجابة النموذجية المعتمدة في الجامعات.`;
    } else if (goal === 'explain') {
      goalPrompt = `اشرح لي موضوع هذه المحاضرة كأنك أستاذ جامعي متميز يشرح لطالب بطريقة عملية ومبسطة جداً:
- استخدم أمثلة واقعية وتطبيقات عملية.
- بسط أي مصطلحات معقدة.
- وضح كيف يرتبط هذا الموضوع بسوق العمل والحياة اليومية.`;
    } else {
      goalPrompt = `ساعدني في حل وفهم التكليفات والتطبيقات العملية الخاصة بهذا الموضوع:
- وضح خطوات التفكير المنطقي لحل المسائل أو التكليف.
- قدم نصائح لتفادي الأخطاء الشائعة للطلاب.
- اعطني مراجع أو مصادر إضافية للاستزادة.`;
    }

    const fullPrompt = `أنت أستاذ جامعي ومساعد أكاديمي ذكي. أرجو المساعدة في دراسة المحاضرة التالية من منصة Online Courses:

📚 المادة الدراسية: ${item.subject}
🎓 الفرقة الدراسية: ${yearTitle}
📝 عنوان المحتوى: ${item.title}
📄 وصف المحتوى: ${item.description || 'محاضرة ومحتوى دراسي جامعي'}
${item.dueDate ? `⏰ موعد التسليم / الامتحان: ${item.dueDate}` : ''}

🎯 المطلوب منك بالتحديد:
${goalPrompt}

صيغ الإجابة باللغة العربية بأسلوب أكاديمي دقيق ومنسق بعناوين واضحة ونقاط مرتبة.`;

    const encodedPrompt = encodeURIComponent(fullPrompt);

    return {
      prompt: fullPrompt,
      geminiUrl: `https://gemini.google.com/app`,
      chatGptUrl: `https://chatgpt.com/?q=${encodedPrompt}`,
      claudeUrl: `https://claude.ai/new`,
      copilotUrl: `https://copilot.microsoft.com/?q=${encodedPrompt}`
    };
  },

  // --------------------------------------------------------------------------
  // Intelligent Fallbacks
  // --------------------------------------------------------------------------
  generateFallbackSummary(item: ContentItem, yearTitle: string, style: string): AISummaryResult {
    return {
      title: `ملخص شامل: ${item.title}`,
      keyPoints: [
        `مقدمة تأسيسية في مقرر (${item.subject}) لطلاب ${yearTitle}.`,
        `تحليل تفصيلي لأهم المبادئ النظرية والتطبيقية المرتبطة بموضوع: "${item.title}".`,
        `التطبيق العملي وكيفية حل المسائل أو كتابة الأكواد/التطبيقات المباشرة.`,
        `التركيز على مخرجات التعلم الأساسية المطلوبة للاختبارات الجامعية.`,
        `مراجعة الأخطاء الشائعة وطرق التفكير المنهجي لحل التمارين.`
      ],
      summaryText: `تتناول هذه المادة الأكاديمية بعنوان "${item.title}" في مادة ${item.subject} المفاهيم الجوهرية التي يحتاجها الطالب لبناء أساس قوي. تم التركيز على استيعاب النظريات وتطبيقها خطوة بخطوة، مع مراعاة المعايير الجامعية والربط بين الجانب النظري والتطبيقي. يُنصح الطالب بمراجعة هذا الملخص قبل حل شيتات السكاشن والتكليفات لضمان التفوق الأكاديمي.`,
      importantFormulasOrDefinitions: [
        `المفهوم الرئيسي: الأساس العلمي والتطبيقي لموضوع ${item.title}.`,
        `الخوارزمية / الطريقة: الخطوات المتسلسلة المتبعة في حل مسائل ${item.subject}.`,
        `الاستنتاج: العلاقة بين المتغيرات والشروط الحدودية الواجب مراعاتها.`
      ],
      examAdvice: `احرص على حفظ التعريفات بدقة وحل المسائل الشاملة والتكليفات المرفقة، فالامتحان الجامعي يركز عادة على الأسئلة التطبيقية والفهم العميق للمفاهيم.`
    };
  },

  generateFallbackQuiz(item: ContentItem, yearTitle: string, count: number): AIQuizResult {
    const questions: QuizQuestion[] = [
      {
        id: 'q1',
        question: `ما هو الهدف الأساسي لموضوع "${item.title}" في مقرر ${item.subject}؟`,
        options: [
          `بناء الفهم النظري والتطبيقي السليم للمقرر`,
          `حفظ المعلومات دون تطبيق عملي`,
          `استبدال المراجع الأساسية بشكل كامل`,
          `إلغاء الحاجة لحضور السكاشن والمعامل`
        ],
        correctAnswerIndex: 0,
        explanation: `الهدف المحوري لأي محاضرة جامعية هو الربط بين الفهم النظري والتطبيق العملي لتمكين الطالب من حل المشكلات.`
      },
      {
        id: 'q2',
        question: `وفقاً للمحتوى الأكاديمي لمادة ${item.subject}، أي من التالي يُعتبر من المتطلبات الأساسية للنجاح؟`,
        options: [
          `الاعتماد على الحفظ السريع ليلة الامتحان فقط`,
          `حل التكليفات والسكاشن بانتظام ومتابعة المحاضرات`,
          `تجاهل الملاحظات التي يقدمها المعيد في السكشن`,
          `عدم مراجعة شيتات السنوات السابقة`
        ],
        correctAnswerIndex: 1,
        explanation: `الاستمرارية في حل التكليفات وحضور السكاشن ومراجعة المحاضرات يضمن استيعاب المادة بنسبة تزيد عن 95%.`
      },
      {
        id: 'q3',
        question: `عند مواجهة مسألة معقدة مرتبطة بـ "${item.title}"، ما هي الخطوة الأولى الموصى بها؟`,
        options: [
          `البدء بالحل العشوائي لتوفير الوقت`,
          `تحديد المعطيات والمخرجات المطلوبة وتقسيم المسألة لأجزاء أصغر`,
          `ترك المسألة دون محاولة والانتظار للحل الجاهز`,
          `تغيير شروط السؤال لتصبح أسهل`
        ],
        correctAnswerIndex: 1,
        explanation: `المنهج العلمي السليم يبدأ بتحليل المعطيات والمطلوب وتفكيك المسألة الكبيرة إلى خطوات منطقية متسلسلة.`
      },
      {
        id: 'q4',
        question: `ما هي أهمية المراجعة والتسليم قبل الموعد النهائي (Deadline) للتكليف؟`,
        options: [
          `تجنب خصم درجات التأخير وضمان مراجعة الحل بدقة`,
          `لا يوجد أي تأثير للموعد النهائي على التقييم`,
          `الحصول على إعفاء من الامتحانات التحريرية`,
          `فقط لتسجيل الحضور والغياب`
        ],
        correctAnswerIndex: 0,
        explanation: `الالتزام بالمواعيد النهائية ينمي الانضباط المهني ويمنع خسارة درجات أعمال السنة.`
      },
      {
        id: 'q5',
        question: `كيف يمكنك الاستفادة القصوى من الملخصات والسكاشن المرفقة في هذه المنصة؟`,
        options: [
          `استخدامها كمراجعة سريعة وتثبيت للمفاهيم بعد فهم المحاضرة الأصلية`,
          `قراءتها لمرة واحدة دون تدوين أي ملاحظات`,
          `الاعتماد عليها فقط وتجاهل المحاضرات الأساسية`,
          `عدم ربطها بأسئلة الامتحانات السابقة`
        ],
        correctAnswerIndex: 0,
        explanation: `الملخصات أداة دعم ممتازة للمراجعة وتثبيت الأفكار المحورية وربط أجزاء المنهج ببعضها.`
      }
    ];

    return {
      title: `امتحان تدريبي تفاعلي على: ${item.title}`,
      questions: questions.slice(0, count)
    };
  },

  generateFallbackAnswer(item: ContentItem, userQuestion: string): AIAskResponse {
    return {
      answer: `إجابة على سؤالك بشأن "${userQuestion}":
في سياق مقرر "${item.subject}" وموضوع "${item.title}":
هذا السؤال جوهري جداً، والإجابة عليه تتلخص في فهم العلاقة بين المفاهيم الأساسية للمادة والتطبيق المباشر. احرص دائماً على تطبيق الخطوات الحسابية أو المنطقية، والتأكد من توافق النتائج مع الشروط المفترضة في المحاضرة. إذا كان السؤال متعلقاً بمسألة عملية أو كود، يُفضل تجربة الخطوات يدوياً ومقارنتها بالحل النموذجي الوارد في السكشن.`,
      relatedConcepts: [
        `المبادئ الأساسية في ${item.subject}`,
        `التطبيق العملي وحل الشيتات`,
        `التحضير لأسئلة الامتحان الشفهي والتحريري`
      ]
    };
  }
};
