import { 
  ContentItem, 
  UserAccount, 
  AcademicYearId, 
  CategoryId, 
  CategoryDefinition, 
  SubjectItem,
  SupervisorPermissions,
  DepartmentId,
  SemesterId,
  MaintenanceConfig,
  NotificationItem,
  ActivityLogItem,
  PlatformBackupData
} from '../types';
import { 
  INITIAL_ADMIN_USER, 
  INITIAL_SUPERVISORS, 
  DEFAULT_CATEGORIES
} from '../data/mockData';

const STORAGE_KEYS = {
  USERS: 'online_courses_users_v5',
  CONTENT: 'online_courses_content_v5',
  CURRENT_USER: 'online_courses_current_session_v5',
  CATEGORIES: 'online_courses_categories_v5',
  SUBJECTS: 'online_courses_subjects_v5',
  MAINTENANCE: 'online_courses_maintenance_v5',
  NOTIFICATIONS: 'online_courses_notifications_v5',
  ACTIVITY_LOGS: 'online_courses_activity_logs_v5',
  DELETED_CONTENT_IDS: 'online_courses_deleted_content_ids_v5',
  DELETED_SUBJECT_IDS: 'online_courses_deleted_subject_ids_v5',
  CLEAN_SLATE_DONE: 'online_courses_clean_slate_done_v5',
};

// Initial Clean Subjects: ZERO preloaded subjects (Clean Slate for admin to add real subjects)
export const getInitialSubjects = (): SubjectItem[] => {
  return [];
};

export const INITIAL_NOTIFICATIONS: NotificationItem[] = [];

// Helper to extract YouTube ID from diverse formats
export function extractYouTubeId(url: string): string | null {
  if (!url) return null;
  const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
  const match = url.match(regExp);
  return match && match[2].length === 11 ? match[2] : null;
}

export const StorageService = {
  // Permanent tombstones for deleted content and subjects
  getDeletedContentIds(): Set<string> {
    const set = new Set<string>();
    const keys = [
      'online_courses_deleted_content_ids',
      'online_courses_deleted_content_ids_v1',
      'online_courses_deleted_content_ids_v2',
      'online_courses_deleted_content_ids_v3',
      'online_courses_deleted_content_ids_v4',
      STORAGE_KEYS.DELETED_CONTENT_IDS
    ];
    keys.forEach(k => {
      try {
        const str = localStorage.getItem(k);
        if (str) {
          const arr = JSON.parse(str);
          if (Array.isArray(arr)) arr.forEach((id: string) => set.add(id));
        }
      } catch {
        // ignore
      }
    });
    return set;
  },

  getDeletedSubjectIds(): Set<string> {
    const set = new Set<string>();
    const keys = [
      'online_courses_deleted_subject_ids',
      'online_courses_deleted_subject_ids_v1',
      'online_courses_deleted_subject_ids_v2',
      'online_courses_deleted_subject_ids_v3',
      'online_courses_deleted_subject_ids_v4',
      STORAGE_KEYS.DELETED_SUBJECT_IDS
    ];
    keys.forEach(k => {
      try {
        const str = localStorage.getItem(k);
        if (str) {
          const arr = JSON.parse(str);
          if (Array.isArray(arr)) arr.forEach((id: string) => set.add(id));
        }
      } catch {
        // ignore
      }
    });
    return set;
  },

  // Calculate actual LocalStorage storage usage vs estimated 5MB browser limit
  getStorageStats(): {
    totalBytes: number;
    usedMb: number;
    totalMb: number;
    remainingMb: number;
    percentUsed: number;
    isNearLimit: boolean;
  } {
    let totalBytes = 0;
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k) {
          const v = localStorage.getItem(k) || '';
          totalBytes += (k.length + v.length) * 2; // UTF-16 character = 2 bytes
        }
      }
    } catch {
      totalBytes = 0;
    }
    const maxQuotaBytes = 5 * 1024 * 1024; // 5 MB standard browser quota
    const usedMb = Number((totalBytes / (1024 * 1024)).toFixed(2));
    const totalMb = 5.0;
    const remainingMb = Number(Math.max(0, totalMb - usedMb).toFixed(2));
    const percentUsed = Math.min(100, Math.max(1, Math.round((totalBytes / maxQuotaBytes) * 100)));
    return {
      totalBytes,
      usedMb,
      totalMb,
      remainingMb,
      percentUsed,
      isNearLimit: percentUsed > 80
    };
  },

  // Initialize storage if first run
  initStorage() {
    // 1. One-time clean slate migration: purge all mock subjects and mock content from all versions!
    if (!localStorage.getItem(STORAGE_KEYS.CLEAN_SLATE_DONE)) {
      // Clear out old mock content and subjects
      localStorage.setItem(STORAGE_KEYS.SUBJECTS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.CONTENT, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify([]));
      localStorage.setItem(STORAGE_KEYS.CLEAN_SLATE_DONE, 'true');

      // Remove legacy keys
      const legacyKeys = [
        'online_courses_content',
        'online_courses_content_v1',
        'online_courses_content_v2',
        'online_courses_content_v3',
        'online_courses_content_v4',
        'online_courses_subjects',
        'online_courses_subjects_v1',
        'online_courses_subjects_v2',
        'online_courses_subjects_v3',
        'online_courses_subjects_v4'
      ];
      legacyKeys.forEach(k => {
        try { localStorage.removeItem(k); } catch { /* ignore */ }
      });
    }

    if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
      let initialUsers = [INITIAL_ADMIN_USER, ...INITIAL_SUPERVISORS];
      try {
        const v4Users = localStorage.getItem('online_courses_users_v4');
        if (v4Users) {
          const parsed = JSON.parse(v4Users);
          if (Array.isArray(parsed) && parsed.length > 0) initialUsers = parsed;
        }
      } catch {
        // ignore
      }
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(initialUsers));
    }

    if (!localStorage.getItem(STORAGE_KEYS.CATEGORIES)) {
      localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(DEFAULT_CATEGORIES));
    }

    if (!localStorage.getItem(STORAGE_KEYS.SUBJECTS)) {
      localStorage.setItem(STORAGE_KEYS.SUBJECTS, JSON.stringify([]));
    }

    if (!localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS)) {
      localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify([]));
    }

    if (!localStorage.getItem(STORAGE_KEYS.MAINTENANCE)) {
      localStorage.setItem(STORAGE_KEYS.MAINTENANCE, JSON.stringify({ isEnabled: false }));
    }

    if (!localStorage.getItem(STORAGE_KEYS.CONTENT)) {
      localStorage.setItem(STORAGE_KEYS.CONTENT, JSON.stringify([]));
    }

    if (!localStorage.getItem(STORAGE_KEYS.ACTIVITY_LOGS)) {
      localStorage.setItem(STORAGE_KEYS.ACTIVITY_LOGS, JSON.stringify([]));
    }
  },

  // Notify all components in the app that data has changed
  notifyChange() {
    try {
      window.dispatchEvent(new CustomEvent('online_courses_data_changed'));
    } catch {
      // ignore
    }
  },

  // --------------------------------------------------------------------------
  // ACTIVITY LOGS SYSTEM (سجل الأنشطة والعمليات)
  // --------------------------------------------------------------------------
  getActivityLogs(): ActivityLogItem[] {
    this.initStorage();
    try {
      const str = localStorage.getItem(STORAGE_KEYS.ACTIVITY_LOGS);
      return str ? JSON.parse(str) : [];
    } catch {
      return [];
    }
  },

  logActivity(data: Omit<ActivityLogItem, 'id' | 'timestamp'>): ActivityLogItem {
    const logs = this.getActivityLogs();
    const newEntry: ActivityLogItem = {
      ...data,
      id: `act-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString()
    };
    logs.unshift(newEntry);
    try {
      localStorage.setItem(STORAGE_KEYS.ACTIVITY_LOGS, JSON.stringify(logs.slice(0, 300)));
    } catch {
      // ignore
    }
    this.notifyChange();
    return newEntry;
  },

  clearActivityLogs() {
    localStorage.setItem(STORAGE_KEYS.ACTIVITY_LOGS, JSON.stringify([]));
    this.notifyChange();
  },

  // --------------------------------------------------------------------------
  // BACKUP & RESTORE SYSTEM (تصدير واستيراد النسخ الاحتياطية JSON)
  // --------------------------------------------------------------------------
  exportBackup(currentUser?: UserAccount | null): PlatformBackupData {
    const content = this.getContent();
    const subjects = this.getSubjects();
    const categories = this.getCategories();
    const notifications = this.getNotifications();
    const maintenance = this.getMaintenanceMode();
    const activityLogs = this.getActivityLogs();

    const user = currentUser || this.getCurrentUser() || this.getAdminUser();

    const backupData: PlatformBackupData = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      exportedBy: {
        name: user.name,
        email: user.email,
        role: user.role
      },
      content,
      subjects,
      categories,
      notifications,
      maintenance,
      activityLogs,
      stats: {
        totalContent: content.length,
        totalSubjects: subjects.length,
        totalCategories: categories.length
      }
    };

    // Log the backup export
    this.logActivity({
      action: 'backup_export',
      userName: user.name,
      userEmail: user.email,
      userRole: user.role,
      targetTitle: `نسخة احتياطية (${content.length} محتوى، ${subjects.length} مادة)`,
      targetType: 'نسخة احتياطية',
      details: `تم إنشاء وتحميل ملف JSON احتياطي يحتوي على ${content.length} محتوى و ${subjects.length} مادة دراسية.`
    });

    return backupData;
  },

  downloadBackupFile(currentUser?: UserAccount | null) {
    const backup = this.exportBackup(currentUser);
    const jsonStr = JSON.stringify(backup, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const dateStr = new Date().toISOString().split('T')[0];
    const link = document.createElement('a');
    link.href = url;
    link.download = `online-courses-backup-${dateStr}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    return backup;
  },

  importBackup(backupData: any, currentUser?: UserAccount | null): { 
    success: boolean; 
    error?: string; 
    restoredCounts?: { content: number; subjects: number; categories: number } 
  } {
    try {
      if (!backupData || typeof backupData !== 'object') {
        return { success: false, error: 'ملف النسخة الاحتياطية غير صالح أو تالف' };
      }

      if (!Array.isArray(backupData.content) && !Array.isArray(backupData.subjects)) {
        return { success: false, error: 'الملف لا يحتوي على بيانات محتويات أو مواد صحيحة' };
      }

      const content: ContentItem[] = Array.isArray(backupData.content) ? backupData.content : [];
      const subjects: SubjectItem[] = Array.isArray(backupData.subjects) ? backupData.subjects : [];
      const categories: CategoryDefinition[] = Array.isArray(backupData.categories) && backupData.categories.length > 0
        ? backupData.categories 
        : this.getCategories();
      const notifications: NotificationItem[] = Array.isArray(backupData.notifications) ? backupData.notifications : [];
      const maintenance: MaintenanceConfig = backupData.maintenance && typeof backupData.maintenance === 'object'
        ? backupData.maintenance
        : { isEnabled: false };

      // Clear tombstones for any items being restored so they are not filtered out
      const deletedContent = this.getDeletedContentIds();
      content.forEach(c => deletedContent.delete(c.id));
      localStorage.setItem(STORAGE_KEYS.DELETED_CONTENT_IDS, JSON.stringify(Array.from(deletedContent)));

      const deletedSubs = this.getDeletedSubjectIds();
      subjects.forEach(s => deletedSubs.delete(s.id));
      localStorage.setItem(STORAGE_KEYS.DELETED_SUBJECT_IDS, JSON.stringify(Array.from(deletedSubs)));

      // Save restored data to LocalStorage
      localStorage.setItem(STORAGE_KEYS.CONTENT, JSON.stringify(content));
      localStorage.setItem(STORAGE_KEYS.SUBJECTS, JSON.stringify(subjects));
      localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
      localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifications));
      localStorage.setItem(STORAGE_KEYS.MAINTENANCE, JSON.stringify(maintenance));

      const user = currentUser || this.getCurrentUser() || this.getAdminUser();

      // Log the restore event
      this.logActivity({
        action: 'backup_restore',
        userName: user.name,
        userEmail: user.email,
        userRole: user.role,
        targetTitle: `استعادة نسخة احتياطية (${content.length} محتوى، ${subjects.length} مادة)`,
        targetType: 'نسخة احتياطية',
        details: `تمت استعادة ${content.length} محتوى، ${subjects.length} مادة دراسية، و ${categories.length} قسم بنجاح.`
      });

      this.notifyChange();

      return {
        success: true,
        restoredCounts: {
          content: content.length,
          subjects: subjects.length,
          categories: categories.length
        }
      };
    } catch (err: any) {
      return { success: false, error: err?.message || 'فشل استيراد النسخة الاحتياطية' };
    }
  },

  // --------------------------------------------------------------------------
  // RESET TO CLEAN SLATE (تفريغ المنصة بالكامل)
  // --------------------------------------------------------------------------
  clearAllPlatformData(currentUser?: UserAccount | null) {
    const user = currentUser || this.getCurrentUser() || this.getAdminUser();
    this.logActivity({
      action: 'clean_slate_reset',
      userName: user.name,
      userEmail: user.email,
      userRole: user.role,
      targetTitle: 'تفريغ المنصة والبدء من الصفر',
      targetType: 'نظام',
      details: 'تم مسح كافة المواد والمحتويات لتفريغ الموقع بالكامل.'
    });

    localStorage.setItem(STORAGE_KEYS.CONTENT, JSON.stringify([]));
    localStorage.setItem(STORAGE_KEYS.SUBJECTS, JSON.stringify([]));
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify([]));
    try {
      localStorage.removeItem('online_courses_offline_items_v1');
    } catch {
      // ignore
    }
    this.notifyChange();
  },

  // --------------------------------------------------------------------------
  // MAINTENANCE MODE (وضع الصيانة)
  // --------------------------------------------------------------------------
  getMaintenanceMode(): MaintenanceConfig {
    this.initStorage();
    try {
      const str = localStorage.getItem(STORAGE_KEYS.MAINTENANCE);
      return str ? JSON.parse(str) : { isEnabled: false };
    } catch {
      return { isEnabled: false };
    }
  },

  setMaintenanceMode(config: MaintenanceConfig, currentUser?: UserAccount | null) {
    localStorage.setItem(STORAGE_KEYS.MAINTENANCE, JSON.stringify(config));
    const user = currentUser || this.getCurrentUser() || this.getAdminUser();
    this.logActivity({
      action: 'maintenance_mode',
      userName: user.name,
      userEmail: user.email,
      userRole: user.role,
      targetTitle: config.isEnabled ? 'تفعيل وضع الصيانة ⚠️' : 'تعطيل وضع الصيانة ✅',
      targetType: 'نظام',
      details: config.isEnabled 
        ? `تم تشغيل وضع الصيانة: "${config.message || 'الموقع تحت الصيانة والتحديث'}"`
        : 'تم تعطيل وضع الصيانة وإتاحة المنصة للطلاب.'
    });
    this.notifyChange();
  },

  // --------------------------------------------------------------------------
  // NOTIFICATIONS SYSTEM (إشعارات الطلاب أعلى الشاشة)
  // --------------------------------------------------------------------------
  getNotifications(): NotificationItem[] {
    this.initStorage();
    try {
      const str = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
      return str ? JSON.parse(str) : [];
    } catch {
      return [];
    }
  },

  addNotification(item: Omit<NotificationItem, 'id' | 'createdAt'>): NotificationItem {
    const notifs = this.getNotifications();
    const newNotif: NotificationItem = {
      ...item,
      id: `notif-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      createdAt: new Date().toISOString(),
      isRead: false
    };
    notifs.unshift(newNotif);
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifs.slice(0, 50)));
    this.notifyChange();
    return newNotif;
  },

  markNotificationRead(id: string) {
    const notifs = this.getNotifications();
    const item = notifs.find(n => n.id === id);
    if (item) {
      item.isRead = true;
      localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifs));
      this.notifyChange();
    }
  },

  clearNotifications() {
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify([]));
    this.notifyChange();
  },

  // --------------------------------------------------------------------------
  // CATEGORIES MANAGEMENT (المحاضرات، السكاشن، التكليفات، الملخصات)
  // --------------------------------------------------------------------------
  getCategories(): CategoryDefinition[] {
    this.initStorage();
    try {
      const str = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
      return str ? JSON.parse(str) : DEFAULT_CATEGORIES;
    } catch {
      return DEFAULT_CATEGORIES;
    }
  },

  saveCategories(cats: CategoryDefinition[]) {
    localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(cats));
    this.notifyChange();
  },

  addCategory(data: {
    title: string;
    singular: string;
    description: string;
    iconName?: string;
  }): { success: boolean; category?: CategoryDefinition; error?: string } {
    const cats = this.getCategories();
    const cleanTitle = data.title.trim();
    if (!cleanTitle) return { success: false, error: 'يرجى إدخال اسم القسم' };

    if (cats.some(c => c.title.toLowerCase() === cleanTitle.toLowerCase())) {
      return { success: false, error: 'يوجد قسم بهذا الاسم بالفعل!' };
    }

    const newCat: CategoryDefinition = {
      id: `cat-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      title: cleanTitle,
      singular: data.singular.trim() || cleanTitle,
      description: data.description.trim() || 'قسم أكاديمي مخصص للمقررات',
      iconName: data.iconName || 'Folder',
      badgeColor: 'text-indigo-600 bg-indigo-50 border-indigo-200'
    };

    cats.push(newCat);
    this.saveCategories(cats);
    return { success: true, category: newCat };
  },

  updateCategory(id: string, updates: Partial<CategoryDefinition>): { success: boolean; error?: string } {
    const cats = this.getCategories();
    const idx = cats.findIndex(c => c.id === id);
    if (idx === -1) return { success: false, error: 'القسم غير موجود' };

    cats[idx] = { ...cats[idx], ...updates };
    this.saveCategories(cats);
    return { success: true };
  },

  deleteCategory(id: string): { success: boolean; error?: string } {
    const cats = this.getCategories();
    if (cats.length <= 1) {
      return { success: false, error: 'لا يمكن حذف كافة الأقسام! يجب إبقاء قسم واحد على الأقل.' };
    }

    const filtered = cats.filter(c => c.id !== id);
    this.saveCategories(filtered);
    return { success: true };
  },

  // --------------------------------------------------------------------------
  // SUBJECTS MANAGEMENT (المواد الدراسية: إضافة، تعديل اسم، حذف دائم)
  // --------------------------------------------------------------------------
  getSubjects(yearId?: AcademicYearId, departmentId?: DepartmentId, semesterId?: SemesterId): SubjectItem[] {
    this.initStorage();
    try {
      const str = localStorage.getItem(STORAGE_KEYS.SUBJECTS);
      const all: SubjectItem[] = str ? JSON.parse(str) : [];
      const deletedSubs = this.getDeletedSubjectIds();
      
      const cleanSubs = all.filter(s => !deletedSubs.has(s.id));
      if (cleanSubs.length !== all.length) {
        localStorage.setItem(STORAGE_KEYS.SUBJECTS, JSON.stringify(cleanSubs));
      }
      
      return cleanSubs
        .filter(s => {
          const matchYear = !yearId || s.yearId === yearId;
          const matchDept = !departmentId || departmentId === 'all' || !s.departmentId || s.departmentId === 'all' || s.departmentId === departmentId;
          const matchSem = !semesterId || semesterId === 'all' || !s.semesterId || s.semesterId === 'all' || s.semesterId === semesterId;
          return matchYear && matchDept && matchSem;
        });
    } catch {
      return [];
    }
  },

  saveSubjects(subs: SubjectItem[]) {
    const deletedSubs = this.getDeletedSubjectIds();
    const cleanSubs = subs.filter(s => !deletedSubs.has(s.id));
    localStorage.setItem(STORAGE_KEYS.SUBJECTS, JSON.stringify(cleanSubs));
    this.notifyChange();
  },

  addSubject(
    yearId: AcademicYearId, 
    name: string, 
    departmentId?: DepartmentId, 
    semesterId?: SemesterId
  ): { success: boolean; subject?: SubjectItem; error?: string } {
    const cleanName = name.trim();
    if (!cleanName) return { success: false, error: 'يرجى كتابة اسم المادة' };

    const subs = this.getSubjects();
    const existing = subs.find(s => 
      s.yearId === yearId && 
      s.name.toLowerCase() === cleanName.toLowerCase() &&
      (!departmentId || s.departmentId === departmentId)
    );
    if (existing) {
      return { success: false, error: 'هذه المادة مسجلة بالفعل في هذا التخصص!' };
    }

    const newSub: SubjectItem = {
      id: `subj-${yearId}-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      name: cleanName,
      yearId,
      departmentId: departmentId || 'all',
      semesterId: semesterId || 'all'
    };

    subs.push(newSub);
    this.saveSubjects(subs);

    // Activity Log
    const user = this.getCurrentUser() || this.getAdminUser();
    this.logActivity({
      action: 'add_subject',
      userName: user.name,
      userEmail: user.email,
      userRole: user.role,
      targetTitle: cleanName,
      targetType: 'مادة دراسية',
      details: `تمت إضافة مادة دراسية جديدة "${cleanName}" للفرقة.`,
      yearId,
      departmentId,
      semesterId
    });

    // Notify students
    this.addNotification({
      type: 'new_content',
      yearId,
      departmentId: departmentId || 'all',
      title: 'مادة دراسية جديدة',
      message: `تم تسجيل مادة جديدة: "${cleanName}".`
    });

    return { success: true, subject: newSub };
  },

  updateSubject(
    id: string, 
    newName: string, 
    departmentId?: DepartmentId, 
    semesterId?: SemesterId
  ): { success: boolean; error?: string } {
    const cleanName = newName.trim();
    if (!cleanName) return { success: false, error: 'اسم المادة لا يمكن أن يكون فارغاً' };

    const subs = this.getSubjects();
    const idx = subs.findIndex(s => s.id === id);
    if (idx === -1) return { success: false, error: 'المادة غير موجودة' };

    const oldName = subs[idx].name;
    const yearId = subs[idx].yearId;

    subs[idx].name = cleanName;
    if (departmentId) subs[idx].departmentId = departmentId;
    if (semesterId) subs[idx].semesterId = semesterId;
    this.saveSubjects(subs);

    // Auto-update all content items tagged with old subject name
    const content = this.getContent();
    let hasChanges = false;
    content.forEach(item => {
      if (item.yearId === yearId && item.subject === oldName) {
        item.subject = cleanName;
        if (departmentId) item.departmentId = departmentId;
        if (semesterId) item.semesterId = semesterId;
        hasChanges = true;
      }
    });
    if (hasChanges) {
      this.saveContent(content);
    }

    // Activity Log
    const user = this.getCurrentUser() || this.getAdminUser();
    this.logActivity({
      action: 'edit_subject',
      userName: user.name,
      userEmail: user.email,
      userRole: user.role,
      targetTitle: cleanName,
      targetType: 'مادة دراسية',
      details: `تم تعديل اسم المادة من "${oldName}" إلى "${cleanName}".`,
      yearId,
      departmentId,
      semesterId
    });

    return { success: true };
  },

  deleteSubject(id: string): { success: boolean; error?: string } {
    // 1. Record in permanent deleted Subject IDs tombstone set
    const deleted = this.getDeletedSubjectIds();
    deleted.add(id);
    const arr = Array.from(deleted);
    try {
      localStorage.setItem(STORAGE_KEYS.DELETED_SUBJECT_IDS, JSON.stringify(arr));
      localStorage.setItem('online_courses_deleted_subject_ids', JSON.stringify(arr));
    } catch {
      // ignore
    }

    // 2. Fetch and remove directly from stored array
    const subs = this.getSubjects();
    const target = subs.find(s => s.id === id);
    if (!target) return { success: false, error: 'المادة غير موجودة' };

    const filteredSubs = subs.filter(s => s.id !== id);
    localStorage.setItem(STORAGE_KEYS.SUBJECTS, JSON.stringify(filteredSubs));

    // 3. Remove all content items tagged with this deleted subject
    const content = this.getContent();
    const itemsToRemove = content.filter(item => item.yearId === target.yearId && item.subject === target.name);
    const deletedContentIds = this.getDeletedContentIds();
    itemsToRemove.forEach(i => deletedContentIds.add(i.id));
    try {
      localStorage.setItem(STORAGE_KEYS.DELETED_CONTENT_IDS, JSON.stringify(Array.from(deletedContentIds)));
    } catch {
      // ignore
    }
    const remainingContent = content.filter(item => !(item.yearId === target.yearId && item.subject === target.name));
    localStorage.setItem(STORAGE_KEYS.CONTENT, JSON.stringify(remainingContent));

    // Activity Log
    const user = this.getCurrentUser() || this.getAdminUser();
    this.logActivity({
      action: 'delete_subject',
      userName: user.name,
      userEmail: user.email,
      userRole: user.role,
      targetTitle: target.name,
      targetType: 'مادة دراسية',
      details: `تم حذف مادة "${target.name}" وكافة المحتويات المرتبطة بها (${itemsToRemove.length} محتوى).`,
      yearId: target.yearId,
      departmentId: target.departmentId,
      semesterId: target.semesterId
    });

    // 4. Fire notification so all components update immediately
    this.notifyChange();

    return { success: true };
  },

  // --------------------------------------------------------------------------
  // USERS & SUPERVISORS MANAGEMENT
  // --------------------------------------------------------------------------
  getUsers(): UserAccount[] {
    this.initStorage();
    try {
      const usersStr = localStorage.getItem(STORAGE_KEYS.USERS);
      return usersStr ? JSON.parse(usersStr) : [INITIAL_ADMIN_USER, ...INITIAL_SUPERVISORS];
    } catch {
      return [INITIAL_ADMIN_USER, ...INITIAL_SUPERVISORS];
    }
  },

  saveUsers(users: UserAccount[]) {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    this.notifyChange();
  },

  getAdminUser(): UserAccount {
    const users = this.getUsers();
    const admin = users.find(u => u.role === 'admin');
    return admin || INITIAL_ADMIN_USER;
  },

  getSupervisors(): UserAccount[] {
    const users = this.getUsers();
    return users.filter(u => u.role === 'supervisor');
  },

  addSupervisor(data: {
    name: string;
    email: string;
    password: string;
    assignedYears: AcademicYearId[];
    permissions?: Partial<SupervisorPermissions>;
    phone?: string;
  }): { success: boolean; error?: string; user?: UserAccount } {
    const users = this.getUsers();
    const cleanEmail = data.email.trim().toLowerCase();

    if (users.some(u => u.email.toLowerCase() === cleanEmail)) {
      return { success: false, error: 'البريد الإلكتروني مستخدم بالفعل!' };
    }

    const defaultPerms: SupervisorPermissions = {
      canUpload: true,
      canEdit: true,
      canDelete: false,
      canManageSubjects: false,
      ...data.permissions
    };

    const newSupervisor: UserAccount = {
      id: `usr-sup-${Date.now()}`,
      name: data.name.trim(),
      email: cleanEmail,
      password: data.password.trim(),
      role: 'supervisor',
      isActive: true,
      assignedYears: data.assignedYears,
      permissions: defaultPerms,
      createdAt: new Date().toISOString(),
      phone: data.phone?.trim()
    };

    users.push(newSupervisor);
    this.saveUsers(users);
    return { success: true, user: newSupervisor };
  },

  updateSupervisor(id: string, updates: Partial<UserAccount>): { success: boolean; error?: string } {
    const users = this.getUsers();
    const idx = users.findIndex(u => u.id === id);
    if (idx === -1) return { success: false, error: 'المشرف غير موجود' };

    users[idx] = { ...users[idx], ...updates };
    this.saveUsers(users);
    return { success: true };
  },

  deleteSupervisor(id: string): { success: boolean; error?: string } {
    const users = this.getUsers();
    const target = users.find(u => u.id === id);
    if (target?.role === 'admin') {
      return { success: false, error: 'لا يمكن حذف حساب الأدمن الأساسي!' };
    }

    const filtered = users.filter(u => u.id !== id);
    this.saveUsers(filtered);
    return { success: true };
  },

  updateAdminProfile(email: string, password?: string, name?: string): { success: boolean; error?: string } {
    const users = this.getUsers();
    const adminIdx = users.findIndex(u => u.role === 'admin');
    if (adminIdx === -1) return { success: false, error: 'لم يتم العثور على حساب الأدمن' };

    users[adminIdx].email = email.trim();
    if (name) users[adminIdx].name = name.trim();
    if (password && password.trim()) users[adminIdx].password = password.trim();

    this.saveUsers(users);
    return { success: true };
  },

  // --------------------------------------------------------------------------
  // AUTHENTICATION
  // --------------------------------------------------------------------------
  login(emailOrPhone: string, pass: string): { success: boolean; user?: UserAccount; error?: string } {
    const users = this.getUsers();
    const cleanInput = emailOrPhone.trim().toLowerCase();
    const cleanPass = pass.trim();

    const user = users.find(u => 
      (u.email.toLowerCase() === cleanInput || u.phone === cleanInput) && 
      u.password === cleanPass
    );

    if (!user) {
      return { success: false, error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة!' };
    }

    if (!user.isActive) {
      return { success: false, error: 'هذا الحساب تم تعطيله من قِبل إدارة المنصة.' };
    }

    user.lastLogin = new Date().toISOString();
    this.saveUsers(users);
    this.setCurrentUser(user);

    return { success: true, user };
  },

  authenticate(emailOrPhone: string, pass: string): { success: boolean; user?: UserAccount; error?: string } {
    return this.login(emailOrPhone, pass);
  },

  getCurrentUser(): UserAccount | null {
    try {
      const str = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
      return str ? JSON.parse(str) : null;
    } catch {
      return null;
    }
  },

  setCurrentUser(user: UserAccount | null) {
    if (user) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
    } else {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    }
    this.notifyChange();
  },

  logout() {
    this.setCurrentUser(null);
  },

  // --------------------------------------------------------------------------
  // CONTENT MANAGEMENT
  // --------------------------------------------------------------------------
  getContent(): ContentItem[] {
    this.initStorage();
    try {
      const itemsStr = localStorage.getItem(STORAGE_KEYS.CONTENT);
      const items: ContentItem[] = itemsStr ? JSON.parse(itemsStr) : [];
      const deletedIds = this.getDeletedContentIds();
      const valid = items.filter(i => !deletedIds.has(i.id));
      if (valid.length !== items.length) {
        localStorage.setItem(STORAGE_KEYS.CONTENT, JSON.stringify(valid));
      }
      return valid;
    } catch {
      return [];
    }
  },

  saveContent(items: ContentItem[]) {
    const deletedIds = this.getDeletedContentIds();
    const cleanItems = items.filter(i => !deletedIds.has(i.id));
    localStorage.setItem(STORAGE_KEYS.CONTENT, JSON.stringify(cleanItems));
    this.notifyChange();
  },

  addContentItem(item: Omit<ContentItem, 'id' | 'createdAt' | 'views' | 'downloads'>): ContentItem {
    const items = this.getContent();
    
    let ytId: string | undefined = undefined;
    if (item.contentType === 'youtube' && item.youtubeUrl) {
      ytId = extractYouTubeId(item.youtubeUrl) || undefined;
    }

    const newItem: ContentItem = {
      ...item,
      departmentId: item.departmentId || 'all',
      semesterId: item.semesterId || 'all',
      id: `content-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      createdAt: new Date().toISOString(),
      views: 0,
      downloads: 0,
      youtubeVideoId: ytId
    };

    items.unshift(newItem);
    this.saveContent(items);

    // Auto-register subject if not exists
    this.addSubject(item.yearId, item.subject, item.departmentId, item.semesterId);

    // Send automatic notification
    const categoryName = this.getCategories().find(c => c.id === item.categoryId)?.singular || 'محتوى';
    this.addNotification({
      type: item.dueDate ? 'deadline_updated' : 'new_content',
      yearId: item.yearId,
      departmentId: item.departmentId,
      title: item.dueDate ? `تكليف جديد مع موعد تسليم: ${item.title}` : `تمت إضافة ${categoryName} جديدة: ${item.title}`,
      message: `المادة: ${item.subject} | ${item.description.substring(0, 70)}...`,
      contentId: newItem.id,
      subject: item.subject,
      dueDate: item.dueDate
    });

    // Activity Log
    this.logActivity({
      action: 'upload_content',
      userName: item.uploaderName || 'مستخدم',
      userEmail: item.uploaderEmail || '',
      userRole: item.uploaderRole || 'admin',
      targetTitle: item.title,
      targetType: 'محتوى',
      details: `تم رفع ${categoryName} جديدة في مادة "${item.subject}".`,
      yearId: item.yearId,
      departmentId: item.departmentId,
      semesterId: item.semesterId
    });

    return newItem;
  },

  updateContentItem(id: string, updates: Partial<ContentItem>): { success: boolean; error?: string } {
    const items = this.getContent();
    const index = items.findIndex(i => i.id === id);
    if (index === -1) return { success: false, error: 'المحتوى غير موجود!' };

    const oldItem = items[index];

    if (updates.youtubeUrl) {
      updates.youtubeVideoId = extractYouTubeId(updates.youtubeUrl) || undefined;
    }

    items[index] = { ...items[index], ...updates };
    this.saveContent(items);

    // If deadline updated, notify students!
    if (updates.dueDate && updates.dueDate !== oldItem.dueDate) {
      this.addNotification({
        type: 'deadline_updated',
        yearId: items[index].yearId,
        departmentId: items[index].departmentId,
        title: `تحديث موعد التسليم: ${items[index].title}`,
        message: `الموعد الجديد: ${updates.dueDate} ${updates.deadlineNote ? `(${updates.deadlineNote})` : ''}`,
        contentId: id,
        subject: items[index].subject,
        dueDate: updates.dueDate
      });
    }

    if (updates.subject && updates.yearId) {
      this.addSubject(updates.yearId, updates.subject, updates.departmentId, updates.semesterId);
    }

    // Activity Log
    const user = this.getCurrentUser() || this.getAdminUser();
    this.logActivity({
      action: 'edit_content',
      userName: user.name,
      userEmail: user.email,
      userRole: user.role,
      targetTitle: items[index].title,
      targetType: 'محتوى',
      details: `تم تعديل بيانات المحتوى في مادة "${items[index].subject}".`,
      yearId: items[index].yearId,
      departmentId: items[index].departmentId,
      semesterId: items[index].semesterId
    });

    return { success: true };
  },

  deleteContentItem(id: string): { success: boolean; error?: string } {
    // 0. Find target item for logging before removing
    const targetItem = this.getContent().find(i => i.id === id);

    // 1. Permanently record in deleted IDs tombstone set (never resurrected on refresh)
    const deleted = this.getDeletedContentIds();
    deleted.add(id);
    const deletedArr = Array.from(deleted);
    try {
      localStorage.setItem(STORAGE_KEYS.DELETED_CONTENT_IDS, JSON.stringify(deletedArr));
      localStorage.setItem('online_courses_deleted_content_ids', JSON.stringify(deletedArr));
      localStorage.setItem('online_courses_deleted_content_ids_v1', JSON.stringify(deletedArr));
      localStorage.setItem('online_courses_deleted_content_ids_v2', JSON.stringify(deletedArr));
      localStorage.setItem('online_courses_deleted_content_ids_v3', JSON.stringify(deletedArr));
    } catch {
      // ignore
    }

    // 2. Remove directly from active content list in storage
    try {
      const itemsStr = localStorage.getItem(STORAGE_KEYS.CONTENT);
      const items: ContentItem[] = itemsStr ? JSON.parse(itemsStr) : [];
      const filtered = items.filter(i => i.id !== id && !deleted.has(i.id));
      localStorage.setItem(STORAGE_KEYS.CONTENT, JSON.stringify(filtered));
    } catch {
      // ignore
    }

    // 3. Remove from offline storage
    try {
      const offline = localStorage.getItem('online_courses_offline_items_v1');
      if (offline) {
        const offList = JSON.parse(offline);
        localStorage.setItem('online_courses_offline_items_v1', JSON.stringify(offList.filter((i: any) => i.id !== id)));
      }
    } catch {
      // ignore
    }

    // Activity Log
    if (targetItem) {
      const user = this.getCurrentUser() || this.getAdminUser();
      this.logActivity({
        action: 'delete_content',
        userName: user.name,
        userEmail: user.email,
        userRole: user.role,
        targetTitle: targetItem.title,
        targetType: 'محتوى',
        details: `تم حذف المحتوى نهائياً من مادة "${targetItem.subject}".`,
        yearId: targetItem.yearId,
        departmentId: targetItem.departmentId,
        semesterId: targetItem.semesterId
      });
    }

    // 4. Notify all components immediately
    this.notifyChange();

    return { success: true };
  },

  incrementView(id: string) {
    const items = this.getContent();
    const item = items.find(i => i.id === id);
    if (item) {
      item.views = (item.views || 0) + 1;
      this.saveContent(items);
    }
  },

  incrementDownload(id: string) {
    const items = this.getContent();
    const item = items.find(i => i.id === id);
    if (item) {
      item.downloads = (item.downloads || 0) + 1;
      this.saveContent(items);
    }
  }
};
