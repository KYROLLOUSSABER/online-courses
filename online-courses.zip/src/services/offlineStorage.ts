import { ContentItem } from '../types';

const OFFLINE_STORAGE_KEY = 'online_courses_offline_items_v1';

export const OfflineStorageService = {
  // Get all saved offline items
  getSavedItems(): ContentItem[] {
    try {
      const data = localStorage.getItem(OFFLINE_STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      console.error('Failed to parse offline items', e);
      return [];
    }
  },

  // Save an item for offline access
  saveItem(item: ContentItem): boolean {
    try {
      const items = this.getSavedItems();
      const existingIndex = items.findIndex(i => i.id === item.id);
      if (existingIndex >= 0) {
        items[existingIndex] = item;
      } else {
        items.unshift(item);
      }
      localStorage.setItem(OFFLINE_STORAGE_KEY, JSON.stringify(items));
      return true;
    } catch (e) {
      console.error('Failed to save item offline', e);
      return false;
    }
  },

  // Remove an item from offline storage
  removeItem(itemId: string): boolean {
    try {
      const items = this.getSavedItems();
      const filtered = items.filter(i => i.id !== itemId);
      localStorage.setItem(OFFLINE_STORAGE_KEY, JSON.stringify(filtered));
      return true;
    } catch (e) {
      console.error('Failed to remove offline item', e);
      return false;
    }
  },

  // Check if an item is currently saved offline
  isItemSaved(itemId: string): boolean {
    const items = this.getSavedItems();
    return items.some(i => i.id === itemId);
  },

  // Toggle offline saved status
  toggleSave(item: ContentItem): { isSaved: boolean; totalOffline: number } {
    if (this.isItemSaved(item.id)) {
      this.removeItem(item.id);
      return { isSaved: false, totalOffline: this.getSavedItems().length };
    } else {
      this.saveItem(item);
      return { isSaved: true, totalOffline: this.getSavedItems().length };
    }
  },

  // Get total offline count
  getCount(): number {
    return this.getSavedItems().length;
  }
};
