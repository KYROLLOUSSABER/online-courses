import { AcademicYearInfo, ContentItem, UserAccount, CategoryDefinition, DepartmentInfo, SemesterInfo } from '../types';

export const DEPARTMENTS: DepartmentInfo[] = [
  {
    id: 'cs',
    name: 'قسم علوم حاسب',
    shortName: 'علوم حاسب',
    description: 'القسم الأساسي لعلوم الحاسب والبرمجيات، الخوارزميات، ونظم التشغيل وهندسة النظم.',
    iconName: 'Laptop',
    badgeColor: 'blue',
    gradient: 'from-blue-600 to-indigo-700'
  },
  {
    id: 'ai',
    name: 'قسم ذكاء اصطناعي',
    shortName: 'ذكاء اصطناعي',
    description: 'تخصص الذكاء الاصطناعي، تعلم الآلة، الشبكات العصبية، ورؤية الحاسوب والتطبيقات الذكية.',
    iconName: 'Cpu',
    badgeColor: 'purple',
    gradient: 'from-purple-600 to-pink-600'
  },
  {
    id: 'cyber',
    name: 'قسم أمن سيبراني',
    shortName: 'أمن سيبراني',
    description: 'تخصص أمن المعلومات والأنظمة، التشفير، اختبار الاختراق، وحماية الشبكات والبنية التحتية.',
    iconName: 'ShieldAlert',
    badgeColor: 'emerald',
    gradient: 'from-emerald-600 to-teal-700'
  }
];

export const SEMESTERS: SemesterInfo[] = [
  {
    id: 'sem-1',
    name: 'الفصل الدراسي الأول (الترم الأول)',
    shortName: 'الترم الأول',
    description: 'مقررات ومحاضرات وتكليفات الترم الأول'
  },
  {
    id: 'sem-2',
    name: 'الفصل الدراسي الثاني (الترم الثاني)',
    shortName: 'الترم الثاني',
    description: 'مقررات ومحاضرات وتكليفات الترم الثاني'
  }
];

export const ACADEMIC_YEARS: AcademicYearInfo[] = [
  {
    id: 'year-1',
    title: 'الفرقة الأولى',
    shortTitle: 'السنة الأولى',
    orderNumber: 1,
    description: 'المقررات التأسيسية والمفاهيم المبدئية لعلوم الحاسب والذكاء الاصطناعي والأمن السيبراني.',
    iconName: 'GraduationCap',
    badgeColor: 'blue',
    accentBg: 'from-blue-600 to-indigo-700'
  },
  {
    id: 'year-2',
    title: 'الفرقة الثانية',
    shortTitle: 'السنة الثانية',
    orderNumber: 2,
    description: 'المقررات المتوسطة، هياكل البيانات، قواعد البيانات، وتطبيقات التحليل والتخصص.',
    iconName: 'BookOpen',
    badgeColor: 'emerald',
    accentBg: 'from-emerald-600 to-teal-700'
  },
  {
    id: 'year-3',
    title: 'الفرقة الثالثة',
    shortTitle: 'السنة الثالثة',
    orderNumber: 3,
    description: 'المقررات المتقدمة التخصصية في علوم الحاسب، الذكاء الاصطناعي، والأمن السيبراني.',
    iconName: 'Layers',
    badgeColor: 'amber',
    accentBg: 'from-amber-600 to-orange-700'
  },
  {
    id: 'year-4',
    title: 'الفرقة الرابعة',
    shortTitle: 'سنة التخرج',
    orderNumber: 4,
    description: 'المقررات الدقيقة، مشاريع التخرج المتقدمة، وتطبيقات سوق العمل والمشاريع التطبيقية.',
    iconName: 'Award',
    badgeColor: 'purple',
    accentBg: 'from-purple-600 to-indigo-900'
  }
];

export const DEFAULT_CATEGORIES: CategoryDefinition[] = [
  {
    id: 'lectures',
    title: 'المحاضرات',
    singular: 'محاضرة',
    description: 'المحاضرات النظرية والتسجيلات والشروحات الرسمية للأساتذة',
    iconName: 'Video',
    badgeColor: 'text-blue-600 bg-blue-50 border-blue-200'
  },
  {
    id: 'sections',
    title: 'السكاشن',
    singular: 'سكشن',
    description: 'السكاشن العملية وتطبيقات المعامل وحل التمارين والشيتات',
    iconName: 'Code',
    badgeColor: 'text-emerald-600 bg-emerald-50 border-emerald-200'
  },
  {
    id: 'assignments',
    title: 'التكليفات',
    singular: 'تكليف',
    description: 'الواجبات والتكليفات والمشاريع المطلوبة مع مواعيد التسليم',
    iconName: 'FileCheck',
    badgeColor: 'text-amber-600 bg-amber-50 border-amber-200'
  },
  {
    id: 'summaries',
    title: 'الملخصات',
    singular: 'ملخص',
    description: 'الملخصات المكتوبة، أسئلة الامتحانات السابقة، ونماذج الإجابة',
    iconName: 'BookMarked',
    badgeColor: 'text-purple-600 bg-purple-50 border-purple-200'
  }
];

export const CATEGORY_INFO: Record<string, CategoryDefinition> = {
  lectures: DEFAULT_CATEGORIES[0],
  sections: DEFAULT_CATEGORIES[1],
  assignments: DEFAULT_CATEGORIES[2],
  summaries: DEFAULT_CATEGORIES[3]
};

// Minimal sample PDF data URI (Valid standard single page PDF)
export const SAMPLE_ACADEMIC_PDF_DATA_URI =
  'data:application/pdf;base64,JVBERi0xLjQKJcTl8uXrCjEgMCBvYmogCjw8Ci9UeXBlIC9DYXRhbG9nCi9QYWdlcyAyIDAgUgo+PgplbmRvYmoKMiAwIG9iago8PAovVHlwZSAvUGFnZXMKL0tpZHMgWzMgMCBSXQovQ291bnQgMQo+PgplbmRvYmoKMyAwIG9iago8PAovVHlwZSAvUGFnZQovUGFyZW50IDIgMCBSCi9NZWRpYUJveCBbMCAwIDYxMiA3OTJdCi9Db250ZW50cyA0IDAgUgovUmVzb3VyY2VzIDw8Ci9Gb250IDw8Ci9GMSA1IDAgUgo+Pgo+Pgo+PgplbmRvYmoKNCAwIG9iago8PAovTGVuZ3RoIDE3NAo+PgpzdHJlYW0KQlQKL0YxIDI0IFRmCjcwIDcyMCBUZApbKE9ubGluZSBDb3Vyc2VzIC0gVW5pdmVyc2l0eSBNYXRlcmlhbCkiXSBUSgovRjEgMTQgVGYKMCAtNDAgVGRKClsobGVjdHVyZSBhbmQgU3R1ZHkgR3VpZGUgRG9jdW1lbnQpXSBUSgowIC0zMCBUZApbKEhpZ2gtcXVhbGl0eSBhY2FkZW1pYyByZXNvdXJjZSBmb3Igc3R1ZGVudHMuKV0gVEoKRVQKZW5kc3RyZWFtCmVuZG9iago1IDAgb2JqCjw8Ci9UeXBlIC9Gb250Ci9TdWJ0eXBlIC9UeXBlMQovQmFzZUZvbnQgL0hlbHZldGljYQo+PgplbmRvYmoKeHJlZgowIDYKMDAwMDAwMDAwMCA2NTUzNSBmIAowMDAwMDAwMDE1IDAwMDAwIG4gCjAwMDAwMDAwNjggMDAwMDAgbiAKMDAwMDAwMDEyNSAwMDAwMCBuIAowMDAwMDAwMjQ5IDAwMDAwIG4gCjAwMDAwMDA0NzUgMDAwMDAgbiAKdHJhaWxlcgo8PAovU2l6ZSA2Ci9Sb290IDEgMCBSCj4+CnN0YXJ0eHJlZgo1NzMKJStPRUY=';

export const INITIAL_ADMIN_USER: UserAccount = {
  id: 'usr-admin-kyrollous',
  name: 'كيرلس صابر (المدير العام)',
  email: 'kyrolloussaber@gmail.com',
  password: '01225620061',
  role: 'admin',
  isActive: true,
  assignedYears: ['year-1', 'year-2', 'year-3', 'year-4'],
  permissions: {
    canUpload: true,
    canEdit: true,
    canDelete: true,
    canManageSubjects: true
  },
  createdAt: '2026-10-12T10:00:00Z',
  phone: '01225620061'
};

export const INITIAL_SUPERVISORS: UserAccount[] = [
  {
    id: 'usr-sup-ahmed',
    name: 'م. أحمد حسن',
    email: 'ahmed.supervisor@courses.edu',
    password: 'pass123456',
    role: 'supervisor',
    isActive: true,
    assignedYears: ['year-1', 'year-2'],
    permissions: {
      canUpload: true,
      canEdit: true,
      canDelete: false,
      canManageSubjects: true
    },
    createdAt: '2026-10-10T14:30:00Z',
    phone: '01012345678'
  },
  {
    id: 'usr-sup-mariam',
    name: 'د. مريم عادل',
    email: 'mariam.moderator@courses.edu',
    password: 'pass654321',
    role: 'supervisor',
    isActive: true,
    assignedYears: ['year-3', 'year-4'],
    permissions: {
      canUpload: true,
      canEdit: true,
      canDelete: true,
      canManageSubjects: false
    },
    createdAt: '2026-10-11T09:15:00Z',
    phone: '01123456789'
  }
];

export const INITIAL_CONTENT_ITEMS: ContentItem[] = [];
const DEPRECATED_ITEMS: any[] = [
  {
    yearId: 'year-1',
    categoryId: 'lectures',
    subject: 'مقدمة في علوم الحاسب',
    title: 'المحاضرة 1: مدخل إلى أساسيات الحاسوب والخوارزميات',
    description: 'شرح مفصل حول مكونات الحاسب الآلي المعمارية وكيفية تدفق البيانات وطرق حل المشكلات البرمجية.',
    contentType: 'youtube',
    youtubeUrl: 'https://www.youtube.com/watch?v=zOjov-2OZ0E',
    youtubeVideoId: 'zOjov-2OZ0E',
    uploaderName: 'كيرلس صابر (المدير العام)',
    uploaderEmail: 'kyrolloussaber@gmail.com',
    uploaderRole: 'admin',
    createdAt: '2026-10-08T11:00:00Z',
    views: 342,
    downloads: 128
  },
  {
    id: 'item-y1-sec-1',
    yearId: 'year-1',
    categoryId: 'sections',
    subject: 'مقدمة في علوم الحاسب',
    title: 'سكشن 1: كتابة أول برنامج بلغة C++ وتتبع المتغيرات',
    description: 'التطبيق العملي في المعمل: تثبيت بيئة التطوير، كتابة دوال الإدخال والإخراج، وحل مسائل الشيت الأول.',
    contentType: 'file',
    fileName: 'Section_01_Cpp_Basics.pdf',
    fileSize: '2.4 ميجابايت',
    fileType: 'application/pdf',
    fileData: SAMPLE_ACADEMIC_PDF_DATA_URI,
    uploaderName: 'م. أحمد حسن',
    uploaderEmail: 'ahmed.supervisor@courses.edu',
    uploaderRole: 'supervisor',
    createdAt: '2026-10-09T14:30:00Z',
    views: 215,
    downloads: 184
  },
  {
    id: 'item-y1-ass-1',
    yearId: 'year-1',
    categoryId: 'assignments',
    subject: 'رياضيات 1',
    title: 'التكليف الأول: مسائل التفاضل والنهايات ومصفوفات الجبر',
    description: 'يرجى حل التمارين المرفقة في ملف الـ PDF وتسليمها بصيغة رقمية أو ورقية قبل انتهاء الموعد المحدد.',
    contentType: 'file',
    fileName: 'Math1_Assignment_01_Limits.pdf',
    fileSize: '1.8 ميجابايت',
    fileType: 'application/pdf',
    fileData: SAMPLE_ACADEMIC_PDF_DATA_URI,
    dueDate: '2026-10-25',
    uploaderName: 'كيرلس صابر (المدير العام)',
    uploaderEmail: 'kyrolloussaber@gmail.com',
    uploaderRole: 'admin',
    createdAt: '2026-10-10T16:00:00Z',
    views: 189,
    downloads: 142
  },
  {
    id: 'item-y1-sum-1',
    yearId: 'year-1',
    categoryId: 'summaries',
    subject: 'فيزياء عامة',
    title: 'ملخص القوانين الكامل: الميكانيكا الكلاسيكية والديناميكا الحرارية',
    description: 'ملخص شامل لأهم القوانين والوحدات الفيزيائية مع مسائل محلولة من امتحانات السنوات السابقة.',
    contentType: 'link',
    externalUrl: 'https://drive.google.com',
    externalUrlTitle: 'مجلد ملخصات الفيزياء على Google Drive',
    uploaderName: 'م. أحمد حسن',
    uploaderEmail: 'ahmed.supervisor@courses.edu',
    uploaderRole: 'supervisor',
    createdAt: '2026-10-11T12:00:00Z',
    views: 290,
    downloads: 95
  },

  // --- الفرقة الثانية ---
  {
    id: 'item-y2-lec-1',
    yearId: 'year-2',
    categoryId: 'lectures',
    subject: 'هياكل البيانات والخوارزميات',
    title: 'المحاضرة 3: القوائم المتصلة (Linked Lists) والتعقيد الزمني Big-O',
    description: 'شرح مفهوم Singly and Doubly Linked Lists والمقارنة بين المصفوفات والقوائم مع كود تطبيقي كامل.',
    contentType: 'youtube',
    youtubeUrl: 'https://www.youtube.com/watch?v=RBSGKlAnoiM',
    youtubeVideoId: 'RBSGKlAnoiM',
    uploaderName: 'كيرلس صابر (المدير العام)',
    uploaderEmail: 'kyrolloussaber@gmail.com',
    uploaderRole: 'admin',
    createdAt: '2026-10-07T10:00:00Z',
    views: 412,
    downloads: 210
  },
  {
    id: 'item-y2-sec-1',
    yearId: 'year-2',
    categoryId: 'sections',
    subject: 'قواعد البيانات',
    title: 'سكشن 2: كتابة استعلامات SQL المتقدمة والربط بين الجداول JOINs',
    description: 'كتابة استعلامات استخراج البيانات، الفهارس، ومفاهيم المفاتيح الأساسية والخارجية في PostgreSQL و MySQL.',
    contentType: 'file',
    fileName: 'SQL_Joins_Practice_Lab.pdf',
    fileSize: '3.1 ميجابايت',
    fileType: 'application/pdf',
    fileData: SAMPLE_ACADEMIC_PDF_DATA_URI,
    uploaderName: 'م. أحمد حسن',
    uploaderEmail: 'ahmed.supervisor@courses.edu',
    uploaderRole: 'supervisor',
    createdAt: '2026-10-09T11:20:00Z',
    views: 198,
    downloads: 165
  },
  {
    id: 'item-y2-ass-1',
    yearId: 'year-2',
    categoryId: 'assignments',
    subject: 'برمجة كائنية (OOP)',
    title: 'تكليف عملي: تصميم نظام إدارة بنكي بأسلوب الوراثة وتعدد الأشكال',
    description: 'تصميم فئات الحساب البنكي، السحب والإيداع، واستخدام المفاهيم الأربعة الأساسية لـ OOP.',
    contentType: 'file',
    fileName: 'OOP_Banking_System_Assignment.pdf',
    fileSize: '1.2 ميجابايت',
    fileType: 'application/pdf',
    fileData: SAMPLE_ACADEMIC_PDF_DATA_URI,
    dueDate: '2026-10-28',
    uploaderName: 'م. أحمد حسن',
    uploaderEmail: 'ahmed.supervisor@courses.edu',
    uploaderRole: 'supervisor',
    createdAt: '2026-10-10T13:45:00Z',
    views: 260,
    downloads: 198
  },
  {
    id: 'item-y2-sum-1',
    yearId: 'year-2',
    categoryId: 'summaries',
    subject: 'هياكل البيانات والخوارزميات',
    title: 'كبسولة مراجعة الميدتيرم: الخوارزميات وهياكل البيانات في 15 صفحة',
    description: 'مراجعة سريعة لأهم الأفكار البرمجية الشائعة في الامتحانات وأكواد الخوارزميات الأساسية.',
    contentType: 'file',
    fileName: 'DataStructures_Midterm_Revision.pdf',
    fileSize: '4.5 ميجابايت',
    fileType: 'application/pdf',
    fileData: SAMPLE_ACADEMIC_PDF_DATA_URI,
    uploaderName: 'كيرلس صابر (المدير العام)',
    uploaderEmail: 'kyrolloussaber@gmail.com',
    uploaderRole: 'admin',
    createdAt: '2026-10-11T18:00:00Z',
    views: 520,
    downloads: 380
  },

  // --- الفرقة الثالثة ---
  {
    id: 'item-y3-lec-1',
    yearId: 'year-3',
    categoryId: 'lectures',
    subject: 'شبكات الحاسب',
    title: 'المحاضرة 4: طبقة النقل TCP vs UDP وتقسيم الشبكات الفرعية Subnetting',
    description: 'شرح معمارية OSI Model و TCP/IP مع تحليل الباكتات وطريقة حساب عناوين الشبكات وأقنعة الشبكة.',
    contentType: 'youtube',
    youtubeUrl: 'https://www.youtube.com/watch?v=IPvYjXCsTg8',
    youtubeVideoId: 'IPvYjXCsTg8',
    uploaderName: 'د. مريم عادل',
    uploaderEmail: 'mariam.moderator@courses.edu',
    uploaderRole: 'supervisor',
    createdAt: '2026-10-06T09:00:00Z',
    views: 310,
    downloads: 145
  },
  {
    id: 'item-y3-sec-1',
    yearId: 'year-3',
    categoryId: 'sections',
    subject: 'نظم التشغيل',
    title: 'سكشن 3: محاكاة جدولة المعالج CPU Scheduling بالأكواد',
    description: 'تطبيق خوارزميات FCFS, SJF, Round Robin باستخدام لغة برمجية وحساب متوسط زمن الانتظار والتنفيذ.',
    contentType: 'file',
    fileName: 'OS_Scheduling_Algorithms_Code.pdf',
    fileSize: '2.8 ميجابايت',
    fileType: 'application/pdf',
    fileData: SAMPLE_ACADEMIC_PDF_DATA_URI,
    uploaderName: 'د. مريم عادل',
    uploaderEmail: 'mariam.moderator@courses.edu',
    uploaderRole: 'supervisor',
    createdAt: '2026-10-08T15:20:00Z',
    views: 245,
    downloads: 178
  },
  {
    id: 'item-y3-ass-1',
    yearId: 'year-3',
    categoryId: 'assignments',
    subject: 'هندسة البرمجيات',
    title: 'مشروع تسليم التكليف: رسم مخططات UML ومواصفات المتطلبات SRS',
    description: 'إعداد وثيقة SRS لنظام إلكتروني متكامل ورسم Use Case, Class Diagram, و Sequence Diagram.',
    contentType: 'link',
    externalUrl: 'https://t.me',
    externalUrlTitle: 'قناة مناقشة تكليفات هندسة البرمجيات',
    dueDate: '2026-11-02',
    uploaderName: 'كيرلس صابر (المدير العام)',
    uploaderEmail: 'kyrolloussaber@gmail.com',
    uploaderRole: 'admin',
    createdAt: '2026-10-09T17:10:00Z',
    views: 180,
    downloads: 82
  },
  {
    id: 'item-y3-sum-1',
    yearId: 'year-3',
    categoryId: 'summaries',
    subject: 'ذكاء اصطناعي',
    title: 'ملخص خوارزميات البحث الذكي: A* Search, Minimax, و Heuristics',
    description: 'مراجعة خوارزميات البحث غير الموجه والموجه، مسائل التخمين، ولعبة الشطرنج/إكس أو بالـ Minimax.',
    contentType: 'file',
    fileName: 'AI_Search_Algorithms_Summary.pdf',
    fileSize: '3.6 ميجابايت',
    fileType: 'application/pdf',
    fileData: SAMPLE_ACADEMIC_PDF_DATA_URI,
    uploaderName: 'د. مريم عادل',
    uploaderEmail: 'mariam.moderator@courses.edu',
    uploaderRole: 'supervisor',
    createdAt: '2026-10-11T16:40:00Z',
    views: 390,
    downloads: 270
  },

  // --- الفرقة الرابعة ---
  {
    id: 'item-y4-lec-1',
    yearId: 'year-4',
    categoryId: 'lectures',
    subject: 'أمن المعلومات والسيبراني',
    title: 'المحاضرة 5: التشفير المتماثل وغير المتماثل RSA و AES وشهادات SSL',
    description: 'شرح مفصل لآليات التشفير الحديثة، توقيع الشهادات الرقمية، وتبادل المفاتيح ببروتوكول Diffie-Hellman.',
    contentType: 'youtube',
    youtubeUrl: 'https://www.youtube.com/watch?v=ERp8420ucGs',
    youtubeVideoId: 'ERp8420ucGs',
    uploaderName: 'كيرلس صابر (المدير العام)',
    uploaderEmail: 'kyrolloussaber@gmail.com',
    uploaderRole: 'admin',
    createdAt: '2026-10-05T12:00:00Z',
    views: 520,
    downloads: 310
  },
  {
    id: 'item-y4-sec-1',
    yearId: 'year-4',
    categoryId: 'sections',
    subject: 'الحوسبة السحابية',
    title: 'سكشن 4: إطلاق الخوادم ونشر الحاويات عبر Docker و Kubernetes',
    description: 'بناء Dockerfile، إدارة الشبكات داخل Docker Compose، ومفاهيم Pods و Services في Kubernetes.',
    contentType: 'file',
    fileName: 'Cloud_Docker_K8s_Lab.pdf',
    fileSize: '3.9 ميجابايت',
    fileType: 'application/pdf',
    fileData: SAMPLE_ACADEMIC_PDF_DATA_URI,
    uploaderName: 'د. مريم عادل',
    uploaderEmail: 'mariam.moderator@courses.edu',
    uploaderRole: 'supervisor',
    createdAt: '2026-10-07T13:10:00Z',
    views: 330,
    downloads: 240
  },
  {
    id: 'item-y4-ass-1',
    yearId: 'year-4',
    categoryId: 'assignments',
    subject: 'مشروع التخرج',
    title: 'تسليم المسودة الأولى: Proposal وخطة عمل مشروع التخرج لعام 2026',
    description: 'تسليم وثيقة المقترح البحثي متضمنة أهداف المشروع، دراسة الجدوى، والتقنيات المستخدمة وجدول العمل.',
    contentType: 'file',
    fileName: 'Graduation_Project_Proposal_Template.pdf',
    fileSize: '1.5 ميجابايت',
    fileType: 'application/pdf',
    fileData: SAMPLE_ACADEMIC_PDF_DATA_URI,
    dueDate: '2026-11-15',
    uploaderName: 'كيرلس صابر (المدير العام)',
    uploaderEmail: 'kyrolloussaber@gmail.com',
    uploaderRole: 'admin',
    createdAt: '2026-10-10T10:00:00Z',
    views: 450,
    downloads: 380
  },
  {
    id: 'item-y4-sum-1',
    yearId: 'year-4',
    categoryId: 'summaries',
    subject: 'تعلم الآلة العميق',
    title: 'ملخص شامل: الشبكات العصبية الالتفافية CNN ونماذج المحولات Transformers',
    description: 'شرح معادلات Backpropagation، دوال التنشيط، طبقات Pooling، وآلية الانتباه الذاتي Self-Attention.',
    contentType: 'link',
    externalUrl: 'https://github.com',
    externalUrlTitle: 'مستودع الأكواد والمذكرات على GitHub',
    uploaderName: 'د. مريم عادل',
    uploaderEmail: 'mariam.moderator@courses.edu',
    uploaderRole: 'supervisor',
    createdAt: '2026-10-11T14:30:00Z',
    views: 410,
    downloads: 195
  }
];
